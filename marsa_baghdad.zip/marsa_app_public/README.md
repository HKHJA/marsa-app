# مرسى بغداد | Marsa Baghdad — Travel App

A simple, bilingual (Arabic-first) Flutter app for **Marsa Baghdad Travel &
Tourism**. Customers pick a route/city and dates, see prices **with your profit
margin already added**, and tap **"احجز عبر واتساب"** to send the booking
request straight to the agency's WhatsApp.

Built to run **instantly with realistic demo data**, and flip to **live prices
(Amadeus)** by changing one line.

---

## What it does

- ✈️ Flight search (Baghdad, Basra, Erbil + popular destinations)
- 🏨 Hotel search (Dubai, Istanbul, Cairo, Makkah…)
- 💰 Automatic markup — the price shown = supplier price + your profit
- 💬 One-tap booking via WhatsApp with a pre-filled message
- 🌙 Arabic UI with RTL layout, navy + gold branding

---

## Quick start (5 minutes)

You need Flutter installed: https://docs.flutter.dev/get-started/install

```bash
cd marsa_baghdad
flutter create .        # generates android/ ios/ (does NOT touch lib/)
flutter pub get
flutter run             # runs on a connected phone or emulator
```

It works immediately using demo data. Now personalize it.

---

## The only file you edit: `lib/config/app_config.dart`

| What | Where | Notes |
|------|-------|-------|
| **WhatsApp number** | `whatsappNumber` | Her number, format `9647XXXXXXXXX` (no `+`). **Required.** |
| **Profit margin** | `flightMarkupPercent`, `flightMarkupFixed`, `hotelMarkupPercent` | e.g. 8% + $15 per flight |
| **Demo vs live** | `useMockData` | `true` = demo, `false` = live Duffel prices |
| **App name / colors** | `appNameAr`, `brandPrimary`, `brandAccent` | Already set to Marsa Baghdad |
| **Routes / cities** | `airports`, `hotelCities` | Add or remove options |

Change the number and margin, and the app is ready as a gift.

---

## Going live with real prices (Duffel)

Amadeus shut down its free self-service API in 2026, so live flight prices come
from **Duffel** instead. We only read offers to show a price — booking still
happens over WhatsApp, so no ticketing/accreditation is needed.

1. Create a **free** account: https://duffel.com → **Settings → Access tokens**.
2. Copy a **test** token (starts with `duffel_test_`).
3. In `app_config.dart`:
   ```dart
   static const bool useMockData = false;
   static const String duffelToken = 'duffel_test_xxxxxxxx';
   ```
4. The test token returns realistic sample flights for free. When ready for real
   sales, generate a **live** token in Duffel and paste it instead.

> Hotels currently use built-in sample data. To make hotel prices live too, add
> Duffel Stays in `lib/services/duffel_service.dart` + `travel_service.dart`
> (mirrors the flight code).

> Security note: for a small gift app, keys in the config are fine. If this
> grows into a real business, move the Amadeus calls behind a small backend so
> the keys aren't shipped inside the app.

---

## How the markup works

`lib/services/pricing.dart` takes the supplier price and applies the numbers
from `app_config.dart`:

```
flight final = supplier × (1 + 8%) + $15   → rounded up
hotel  final = (per-night × nights) × (1 + 12%) → rounded up
```

The customer only ever sees the final price. Your margin is invisible to them.

---

## Publishing to Google Play — step by step

**Cost:** $25, one-time, forever (no yearly fee).

1. **Register:** https://play.google.com/console → pay $25. Register as an
   **Organization** (the agency) rather than personal — looks legitimate and
   avoids some new-account friction.
2. **Build the release file:**
   ```bash
   flutter build appbundle
   ```
   Output: `build/app/outputs/bundle/release/app-release.aab`
   (You'll set up an upload key first — Flutter's guide:
   https://docs.flutter.dev/deployment/android#signing-the-app)
3. **Create the app** in Play Console → fill store listing (name, short
   description, screenshots, a 512×512 icon, a feature graphic).
4. **New-account testing rule (2026):** new developer accounts must run a
   **closed test with at least 12 testers for 14 consecutive days** before you
   can apply for production. Add 12 friends' emails as testers, share the test
   link, wait 14 days.
5. **Apply for production** → submit for review → published (review usually a
   few days). **Plan ~2–4 weeks total** from signup to public launch.

> Because of the 14-day rule, if the birthday is soon, install it directly on
> her phone as a gift first (`flutter build apk` → send her the `.apk`), and let
> the Play Store version go live a couple weeks later.

---

## Project structure

```
lib/
├── config/app_config.dart      ← edit this (brand, WhatsApp, markup, keys)
├── models/                      ← flight & hotel data shapes
├── services/
│   ├── travel_service.dart      ← picks mock vs live
│   ├── amadeus_service.dart     ← live flight + hotel API
│   ├── mock_data.dart           ← demo data
│   ├── pricing.dart             ← markup engine
│   └── whatsapp_service.dart    ← WhatsApp deep link
├── screens/                     ← home + results
├── widgets/brand.dart           ← reusable UI
└── main.dart                    ← theme + RTL
```

---

## Notes / honest limits

- This is a **lead/quote app**, not a payment checkout. The customer's request
  goes to WhatsApp and the agency confirms + collects payment as usual. This is
  deliberate — it avoids payment-gateway, licensing, and merchant-of-record
  complexity, and matches how Iraqi agencies already close bookings.
- Amadeus test data is for demonstration; real availability needs production
  access.
- iOS: the code is cross-platform. To publish on the App Store you need an Apple
  Developer account ($99/year) — Android-only is fine to start.
```
