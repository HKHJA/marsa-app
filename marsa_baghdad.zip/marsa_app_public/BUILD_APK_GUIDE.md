# Get the installable APK — no software to install

You (github.com/**HKHJA**) let GitHub build the APK in the cloud for free, then
download it and send it to the phone. ~10 minutes, most of it waiting.

## Steps

1. **Create a repo:** go to https://github.com/new
   - Repository name: `marsa-baghdad-app`
   - Private ✔ → **Create repository**.

2. **Upload the project:**
   - On the new repo page click **“uploading an existing file”**.
   - Unzip `marsa_baghdad.zip`, then **drag ALL its contents** (the `lib`
     folder, `pubspec.yaml`, the `.github` folder, `patch_manifest.py`,
     `assets`, etc.) into the browser.
   - ⚠️ Make sure hidden files are shown so the **`.github`** folder is
     included — that folder is what tells GitHub to build the APK.
     (Mac: press `Cmd+Shift+.` in Finder to show hidden files before dragging.)
   - Click **Commit changes**.

3. **Wait for the build:**
   - Open the **Actions** tab → you’ll see “Build APK” running (yellow dot).
   - It takes ~5–8 minutes → turns into a green ✔.

4. **Download the APK:**
   - Click the finished run → scroll to **Artifacts** →
     **`marsa-baghdad-apk`** → download it.
   - It downloads as a `.zip`; unzip to get **`app-release.apk`**.

5. **Send to the phone & install:**
   - Send `app-release.apk` to the phone (see WhatsApp note below).
   - On the phone, open it → allow “Install from unknown sources” → Install.

## Re-building later (e.g. after adding Amadeus keys or changing markup)

Edit `lib/config/app_config.dart` **directly on GitHub** (open the file → pencil
icon → change the value → Commit). The build re-runs automatically and a fresh
APK appears in Actions. No re-upload needed.

## Sending an APK over WhatsApp

WhatsApp sometimes refuses to send `.apk` files as documents. If it does:
- Send it as a document anyway (works in many versions), **or**
- Put it on Google Drive and share the link over WhatsApp, **or**
- Send via Telegram / email — all install the same way.

## Notes

- The APK is **release-built but debug-signed**, which is perfect for installing
  directly on a phone (sideloading). For the Google **Play Store** you’ll add a
  real signing key later — see `README.md`.
- App package id is the default `com.example.marsa_baghdad`. Fine for a phone;
  change it before Play Store (README covers this).
