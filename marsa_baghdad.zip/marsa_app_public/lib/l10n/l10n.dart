import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Lightweight localization: Arabic (ar), English (en), Kurdish Sorani (ckb).
/// Arabic and Sorani are RTL; English is LTR. The chosen language is saved so
/// it persists across app restarts.
class L10n {
  static final ValueNotifier<String> locale = ValueNotifier<String>('ar');

  static const List<String> supported = ['ar', 'en', 'ckb'];
  static bool get isRtl => locale.value != 'en';

  static String nameOf(String code) {
    switch (code) {
      case 'en':
        return 'English';
      case 'ckb':
        return 'کوردی';
      default:
        return 'العربية';
    }
  }

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final v = p.getString('lang');
      if (v != null && supported.contains(v)) locale.value = v;
    } catch (_) {}
  }

  static Future<void> set(String code) async {
    locale.value = code;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('lang', code);
    } catch (_) {}
  }
}

/// Translate a key for the current language (falls back to Arabic, then key).
String tr(String key) {
  final m = _s[key];
  if (m == null) return key;
  return m[L10n.locale.value] ?? m['ar'] ?? key;
}

/// key : { ar, en, ckb }
const Map<String, Map<String, String>> _s = {
  // Brand
  'appName': {'ar': 'مرسى بغداد', 'en': 'Marsa Baghdad', 'ckb': 'مەرسا بەغداد'},
  'tagline': {'ar': 'للسفر والسياحة', 'en': 'Travel & Tourism', 'ckb': 'گەشت و گەشتیاری'},

  // Bottom nav
  'nav_home': {'ar': 'الرئيسية', 'en': 'Home', 'ckb': 'سەرەکی'},
  'nav_bookings': {'ar': 'حجوزاتي', 'en': 'My Bookings', 'ckb': 'حجزەکانم'},

  // Category tiles
  'cat_flights': {'ar': 'طيران', 'en': 'Flights', 'ckb': 'فڕین'},
  'cat_hotels': {'ar': 'فنادق', 'en': 'Hotels', 'ckb': 'ھۆتێل'},
  'cat_offers': {'ar': 'عروض وباقات', 'en': 'Offers & Packages', 'ckb': 'پێشکەشکراو و پاکێج'},
  'cat_visa': {'ar': 'فيزا', 'en': 'Visa', 'ckb': 'ڤیزا'},
  'cat_status': {'ar': 'حالة الرحلة', 'en': 'Flight Status', 'ckb': 'دۆخی فڕین'},
  'cat_services': {'ar': 'خدمات', 'en': 'Services', 'ckb': 'خزمەتگوزاری'},

  // Home sections
  'sec_offers': {'ar': 'عروض مميزة', 'en': 'Special Offers', 'ckb': 'پێشکەشکراوی تایبەت'},
  'sec_reviews': {'ar': 'آراء عملائنا', 'en': 'Customer Reviews', 'ckb': 'بۆچوونی کڕیارەکانمان'},
  'discover_title': {'ar': 'اكتشف العالم مع مرسى بغداد', 'en': 'Explore the world with Marsa Baghdad', 'ckb': 'جیهان بگەڕێ لەگەڵ مەرسا بەغداد'},
  'discover_sub': {'ar': 'باقات سياحية وعروض مميزة — اضغط للتفاصيل', 'en': 'Tour packages & special offers — tap for details', 'ckb': 'پاکێجی گەشتیاری و پێشکەشکراوی تایبەت — بۆ وردەکاری کلیک بکە'},

  // Push banner
  'push_enable_msg': {'ar': 'فعّل الإشعارات ليصلك كل جديد من العروض', 'en': 'Enable notifications to get our latest offers', 'ckb': 'ئاگادارییەکان چالاک بکە بۆ نوێترین پێشکەشکراوەکان'},
  'push_enable_btn': {'ar': 'تفعيل', 'en': 'Enable', 'ckb': 'چالاککردن'},

  // Common buttons
  'book': {'ar': 'احجز', 'en': 'Book', 'ckb': 'حجز بکە'},
  'book_whatsapp': {'ar': 'احجز عبر واتساب', 'en': 'Book via WhatsApp', 'ckb': 'حجز بکە لە ڕێی واتساپ'},
  'search_flights': {'ar': 'بحث عن رحلات', 'en': 'Search Flights', 'ckb': 'گەڕان بۆ فڕینەکان'},
  'starts_from': {'ar': 'يبدأ من', 'en': 'from', 'ckb': 'دەستپێدەکات لە'},

  // Drawer
  'login': {'ar': 'تسجيل الدخول', 'en': 'Login', 'ckb': 'چوونەژوورەوە'},
  'app_settings': {'ar': 'إعدادات التطبيق', 'en': 'App Settings', 'ckb': 'ڕێکخستنی ئەپ'},
  'currency': {'ar': 'العملة', 'en': 'Currency', 'ckb': 'دراو'},
  'language': {'ar': 'اللغة', 'en': 'Language', 'ckb': 'زمان'},
  'general': {'ar': 'عام', 'en': 'General', 'ckb': 'گشتی'},
  'about': {'ar': 'من نحن', 'en': 'About Us', 'ckb': 'دەربارەی ئێمە'},
  'contact': {'ar': 'اتصل بنا', 'en': 'Contact Us', 'ckb': 'پەیوەندیمان پێوە بکە'},
  'terms': {'ar': 'الشروط والأحكام', 'en': 'Terms & Conditions', 'ckb': 'مەرج و ڕێساکان'},
  'privacy': {'ar': 'سياسة الخصوصية', 'en': 'Privacy Policy', 'ckb': 'سیاسەتی تایبەتمەندی'},
  'follow_us': {'ar': 'تابعنا', 'en': 'Follow Us', 'ckb': 'شوێنمان بکەوە'},
  'facebook': {'ar': 'فيسبوك', 'en': 'Facebook', 'ckb': 'فەیسبووک'},
  'instagram': {'ar': 'إنستغرام', 'en': 'Instagram', 'ckb': 'ئینستاگرام'},
  'choose_currency': {'ar': 'اختر العملة', 'en': 'Choose currency', 'ckb': 'دراو هەڵبژێرە'},
  'usd': {'ar': 'دولار أمريكي (USD)', 'en': 'US Dollar (USD)', 'ckb': 'دۆلاری ئەمریکی (USD)'},
  'iqd': {'ar': 'دينار عراقي (IQD)', 'en': 'Iraqi Dinar (IQD)', 'ckb': 'دیناری عێراقی (IQD)'},
  'choose_language': {'ar': 'اختر اللغة', 'en': 'Choose language', 'ckb': 'زمان هەڵبژێرە'},

  // Services screen
  'our_services': {'ar': 'خدماتنا', 'en': 'Our Services', 'ckb': 'خزمەتگوزارییەکانمان'},

  // Bookings tab
  'bookings_title': {'ar': 'حجوزاتك معنا', 'en': 'Your bookings with us', 'ckb': 'حجزەکانت لەلای ئێمە'},
  'bookings_body': {'ar': 'يتم تأكيد الحجوزات وإرسال التذاكر عبر واتساب مباشرة مع فريق مرسى بغداد. تواصل معنا لمتابعة حجزك أو لعمل حجز جديد.', 'en': 'Bookings are confirmed and tickets are sent over WhatsApp directly with the Marsa Baghdad team. Contact us to follow up on a booking or make a new one.', 'ckb': 'حجزەکان پەسەند دەکرێن و بلیتەکان لە ڕێی واتساپەوە دەنێردرێن ڕاستەوخۆ لەگەڵ تیمی مەرسا بەغداد. پەیوەندیمان پێوە بکە بۆ بەدواداچوونی حجز یان حجزی نوێ.'},
  'contact_whatsapp': {'ar': 'تواصل معنا على واتساب', 'en': 'Contact us on WhatsApp', 'ckb': 'پەیوەندیمان پێوە بکە لە واتساپ'},

  // Offers screen
  'offers_title': {'ar': 'عروض وباقات', 'en': 'Offers & Packages', 'ckb': 'پێشکەشکراو و پاکێج'},
  'our_packages': {'ar': 'باقاتنا', 'en': 'Our Packages', 'ckb': 'پاکێجەکانمان'},
  'no_offers': {'ar': 'لا توجد عروض حالياً — تابعنا قريباً', 'en': 'No offers right now — check back soon', 'ckb': 'ئێستا هیچ پێشکەشکراوێک نییە — بەمزوانە بمانبینەوە'},

  // Info pages
  'about_body': {'ar': 'مرسى بغداد للسفر والسياحة — وكالتكم لحجز تذاكر الطيران والفنادق حول العالم، الفيزا، الباقات السياحية، العمرة والحج، والمزيد. نوفّر أفضل الأسعار وخدمة سريعة عبر واتساب.', 'en': 'Marsa Baghdad Travel & Tourism — your agency for booking flights and hotels worldwide, visas, tour packages, Umrah & Hajj, and more. We offer the best prices and fast service over WhatsApp.', 'ckb': 'مەرسا بەغداد بۆ گەشت و گەشتیاری — ئاژانسەکەتان بۆ حجزی بلیتی فڕۆکە و ھۆتێل لە سەرانسەری جیهان، ڤیزا، پاکێجی گەشتیاری، عومرە و حەج، و زیاتر. باشترین نرخ و خزمەتی خێرا لە ڕێی واتساپ دەدەین.'},
  'terms_body': {'ar': 'يعمل تطبيق مرسى بغداد كوسيط لعرض الأسعار وتسهيل الحجز. يتم تأكيد الحجز والدفع عبر التواصل المباشر مع الوكالة على واتساب. الأسعار المعروضة استرشادية وقد تتغير حسب التوفر وقت التأكيد.', 'en': 'The Marsa Baghdad app acts as an intermediary to display prices and facilitate booking. Booking and payment are confirmed by contacting the agency directly on WhatsApp. Displayed prices are indicative and may change based on availability at confirmation time.', 'ckb': 'ئەپی مەرسا بەغداد وەک ناوەندێک کار دەکات بۆ پیشاندانی نرخەکان و ئاسانکاری حجز. حجز و پارەدان لە ڕێی پەیوەندی ڕاستەوخۆ لەگەڵ ئاژانس لە واتساپ پەسەند دەکرێن. نرخە پیشاندراوەکان ڕێنماییکەرن و لەوانەیە بگۆڕێن بەپێی بەردەستبوون لە کاتی پەسەندکردن.'},
  'privacy_body': {'ar': 'نحترم خصوصيتك. لا يجمع التطبيق بياناتك الشخصية إلا ما تشاركه معنا عند طلب الحجز. تُستخدم الإشعارات لإعلامك بالعروض الجديدة، ويمكنك إيقافها من إعدادات هاتفك في أي وقت.', 'en': 'We respect your privacy. The app does not collect your personal data except what you share with us when requesting a booking. Notifications are used to inform you of new offers, and you can turn them off from your phone settings at any time.', 'ckb': 'ڕێز لە تایبەتمەندیت دەگرین. ئەپەکە داتای کەسیت کۆناکاتەوە جگە لەوەی خۆت لە کاتی داواکردنی حجز لەگەڵمان بەشی دەکەیت. ئاگادارییەکان بۆ ئاگادارکردنەوەت لە پێشکەشکراوە نوێیەکان بەکاردێن، و دەتوانیت لە ڕێکخستنی مۆبایلەکەت هەر کاتێک بیانکوژێنیتەوە.'},

  // Flight search
  'fs_title': {'ar': 'حجز طيران', 'en': 'Book a Flight', 'ckb': 'حجزی فڕین'},
  'f_from': {'ar': 'من', 'en': 'From', 'ckb': 'لە'},
  'f_to': {'ar': 'إلى', 'en': 'To', 'ckb': 'بۆ'},
  'f_depart_date': {'ar': 'تاريخ المغادرة', 'en': 'Departure date', 'ckb': 'بەرواری ڕۆیشتن'},
  'f_passengers': {'ar': 'المسافرون', 'en': 'Passengers', 'ckb': 'گەشتیارەکان'},
  'f_search_flights': {'ar': 'ابحث عن الرحلات', 'en': 'Search flights', 'ckb': 'گەڕان بۆ فڕینەکان'},
  'f_diff_cities': {'ar': 'اختر مدينتين مختلفتين', 'en': 'Choose two different cities', 'ckb': 'دوو شاری جیاواز هەڵبژێرە'},
  'per_person': {'ar': 'للفرد', 'en': 'per person', 'ckb': 'بۆ هەر کەس'},
  'fr_no_direct': {'ar': 'لا توجد أسعار مباشرة لهذا المسار حالياً', 'en': 'No direct prices for this route right now', 'ckb': 'ئێستا نرخی ڕاستەوخۆ نییە بۆ ئەم ڕێڕەوە'},
  'fr_contact': {'ar': 'تواصل معنا وسنزوّدك بأفضل سعر متاح.', 'en': "Contact us and we'll get you the best available price.", 'ckb': 'پەیوەندیمان پێوە بکە، باشترین نرخی بەردەستت پێدەدەین.'},
  'fr_ask_whatsapp': {'ar': 'اطلب السعر عبر واتساب', 'en': 'Ask for a price via WhatsApp', 'ckb': 'داوای نرخ بکە لە واتساپ'},
  'fetch_fail': {'ar': 'تعذّر جلب الأسعار', 'en': "Couldn't load prices", 'ckb': 'نەتوانرا نرخەکان بهێنرێن'},
  'book_whatsapp_full': {'ar': 'احجز عبر واتساب', 'en': 'Book via WhatsApp', 'ckb': 'حجز بکە لە ڕێی واتساپ'},

  // Hotel search / results
  'hs_title': {'ar': 'حجز فنادق', 'en': 'Book a Hotel', 'ckb': 'حجزی ھۆتێل'},
  'h_city': {'ar': 'المدينة', 'en': 'City', 'ckb': 'شار'},
  'h_checkin': {'ar': 'تاريخ الوصول', 'en': 'Check-in date', 'ckb': 'بەرواری چوونەژوورەوە'},
  'h_nights': {'ar': 'عدد الليالي', 'en': 'Nights', 'ckb': 'ژمارەی شەوان'},
  'h_guests': {'ar': 'عدد الضيوف', 'en': 'Guests', 'ckb': 'ژمارەی میوانان'},
  'h_search_hotels': {'ar': 'ابحث عن الفنادق', 'en': 'Search hotels', 'ckb': 'گەڕان بۆ ھۆتێلەکان'},
  'h_hotels_in': {'ar': 'فنادق', 'en': 'Hotels in', 'ckb': 'ھۆتێلەکانی'},
  'h_none': {'ar': 'لا توجد فنادق متاحة', 'en': 'No hotels available', 'ckb': 'هیچ ھۆتێلێک بەردەست نییە'},
  'nights_word': {'ar': 'ليالٍ', 'en': 'nights', 'ckb': 'شەو'},
  'total': {'ar': 'الإجمالي', 'en': 'Total', 'ckb': 'کۆی گشتی'},

  // Service request
  'choose': {'ar': 'اختر', 'en': 'Choose', 'ckb': 'هەڵبژێرە'},
  'sr_details_label': {'ar': 'تفاصيل إضافية (اختياري)', 'en': 'Additional details (optional)', 'ckb': 'وردەکاری زیاتر (ئارەزوومەندانە)'},
  'sr_details_hint': {'ar': 'اكتب أي تفاصيل تساعدنا في خدمتك...', 'en': 'Write any details that help us serve you...', 'ckb': 'هەر وردەکارییەک بنووسە کە یارمەتیمان بدات...'},
  'sr_send': {'ar': 'إرسال الطلب عبر واتساب', 'en': 'Send request via WhatsApp', 'ckb': 'ناردنی داواکاری لە واتساپ'},
  'sr_followup': {'ar': 'سيتواصل معك فريقنا بأفضل عرض', 'en': 'Our team will contact you with the best offer', 'ckb': 'تیمەکەمان بە باشترین پێشکەشکراو پەیوەندیت پێوە دەکات'},

  // Birthday / welcome
  'start_journey': {'ar': 'ابدأ رحلتك ✨', 'en': 'Start your journey ✨', 'ckb': 'گەشتەکەت دەست پێبکە ✨'},
  'iqd_suffix': {'ar': 'د.ع', 'en': 'IQD', 'ckb': 'د.ع'},

  // Badges & field labels
  'badge_top': {'ar': 'الأكثر طلباً', 'en': 'Most requested', 'ckb': 'زۆرترین داواکراو'},
  'badge_new': {'ar': 'جديد', 'en': 'New', 'ckb': 'نوێ'},
  'fl_country': {'ar': 'الدولة المطلوبة', 'en': 'Required country', 'ckb': 'وڵاتی داواکراو'},
  'fl_destination': {'ar': 'الوجهة', 'en': 'Destination', 'ckb': 'شوێن'},

  // Service catalog: titles (t) / subtitles (s) / hints (h)
  'svc_flights_t': {'ar': 'حجز طيران', 'en': 'Flight Booking', 'ckb': 'حجزی فڕین'},
  'svc_flights_s': {'ar': 'أفضل الأسعار', 'en': 'Best prices', 'ckb': 'باشترین نرخ'},
  'svc_hotels_t': {'ar': 'حجز فنادق', 'en': 'Hotel Booking', 'ckb': 'حجزی ھۆتێل'},
  'svc_hotels_s': {'ar': 'حول العالم', 'en': 'Worldwide', 'ckb': 'لە سەرانسەری جیهان'},
  'svc_flightstatus_t': {'ar': 'حالة الرحلة', 'en': 'Flight Status', 'ckb': 'دۆخی فڕین'},
  'svc_flightstatus_s': {'ar': 'تتبّع رحلتك مباشرة', 'en': 'Track your flight live', 'ckb': 'فڕینەکەت ڕاستەوخۆ بەدواداچوون بکە'},
  'svc_visa_t': {'ar': 'تأشيرات (فيزا)', 'en': 'Visas', 'ckb': 'ڤیزا'},
  'svc_visa_s': {'ar': 'لمختلف الدول', 'en': 'For various countries', 'ckb': 'بۆ وڵاتانی جیاواز'},
  'svc_visa_h': {'ar': 'أرسل لنا الدولة وسنبلغك بالأوراق المطلوبة والرسوم ومدة الإنجاز.', 'en': "Send us the country and we'll tell you the required documents, fees, and processing time.", 'ckb': 'وڵاتەکەمان بۆ بنێرە، بەڵگە پێویستەکان و کرێ و ماوەی جێبەجێکردنت پێدەڵێین.'},
  'svc_idp_t': {'ar': 'إجازة سوق دولية', 'en': 'International Driving Permit', 'ckb': 'مۆڵەتی لێخوڕینی نێودەوڵەتی'},
  'svc_idp_s': {'ar': 'إصدار وتجديد', 'en': 'Issue & renew', 'ckb': 'دەرکردن و نوێکردنەوە'},
  'svc_idp_h': {'ar': 'إجازة السوق الدولية تُستخرج للقيادة خارج العراق. أرسل طلبك وسنزوّدك بالتفاصيل.', 'en': 'The international driving permit is issued for driving outside Iraq. Send your request and we\'ll provide the details.', 'ckb': 'مۆڵەتی لێخوڕینی نێودەوڵەتی بۆ لێخوڕین لە دەرەوەی عێراق دەردەچێت. داواکارییەکەت بنێرە وردەکاریت پێدەدەین.'},
  'svc_ins_t': {'ar': 'تأمين سفر وصحي', 'en': 'Travel & Health Insurance', 'ckb': 'دڵنیایی گەشت و تەندروستی'},
  'svc_ins_s': {'ar': 'لكل الوجهات', 'en': 'For all destinations', 'ckb': 'بۆ هەموو شوێنەکان'},
  'svc_ins_h': {'ar': 'تأمين يغطي الحالات الطارئة أثناء السفر ومطلوب لبعض الفيزا (مثل شنغن).', 'en': 'Insurance that covers emergencies while traveling and is required for some visas (like Schengen).', 'ckb': 'دڵنیاییەک کە حاڵەتی لەناکاو لە کاتی گەشت دەگرێتەوە و بۆ هەندێک ڤیزا پێویستە (وەک شەنگن).'},
  'svc_umrah_t': {'ar': 'عمرة وحج', 'en': 'Umrah & Hajj', 'ckb': 'عومرە و حەج'},
  'svc_umrah_s': {'ar': 'باقات كاملة', 'en': 'Complete packages', 'ckb': 'پاکێجی تەواو'},
  'svc_umrah_h': {'ar': 'باقات عمرة وحج تشمل التذاكر والفنادق والتنقلات. حدد التاريخ وعدد الأشخاص.', 'en': 'Umrah & Hajj packages include tickets, hotels, and transport. Specify the date and number of people.', 'ckb': 'پاکێجی عومرە و حەج بلیت و ھۆتێل و گواستنەوە دەگرێتەوە. بەروار و ژمارەی کەسان دیاری بکە.'},
  'svc_tours_t': {'ar': 'باقات سياحية', 'en': 'Tour Packages', 'ckb': 'پاکێجی گەشتیاری'},
  'svc_tours_s': {'ar': 'رحلات منظمة', 'en': 'Organized trips', 'ckb': 'گەشتی ڕێکخراو'},
  'svc_transfer_t': {'ar': 'استقبال بالمطار', 'en': 'Airport Pickup', 'ckb': 'پێشوازی فڕۆکەخانە'},
  'svc_transfer_s': {'ar': 'توصيل ونقل', 'en': 'Transfer & transport', 'ckb': 'گواستنەوە و گەیاندن'},
  'svc_car_t': {'ar': 'تأجير سيارات', 'en': 'Car Rental', 'ckb': 'کرێی ئۆتۆمبێل'},
  'svc_car_s': {'ar': 'داخل وخارج العراق', 'en': 'Inside & outside Iraq', 'ckb': 'ناوخۆ و دەرەوەی عێراق'},
  'svc_esim_t': {'ar': 'شريحة إنترنت eSIM', 'en': 'eSIM Internet', 'ckb': 'ئینتەرنێتی eSIM'},
  'svc_esim_s': {'ar': 'نت أثناء السفر', 'en': 'Internet while traveling', 'ckb': 'ئینتەرنێت لە کاتی گەشت'},
  'svc_docs_t': {'ar': 'ترجمة وتصديق', 'en': 'Translation & Attestation', 'ckb': 'وەرگێڕان و پەسەندکردن'},
  'svc_docs_s': {'ar': 'وثائق ومستندات', 'en': 'Documents', 'ckb': 'بەڵگەنامەکان'},
  'svc_contact_t': {'ar': 'استفسار عام', 'en': 'General Inquiry', 'ckb': 'پرسیاری گشتی'},
  'svc_contact_s': {'ar': 'تواصل معنا', 'en': 'Contact us', 'ckb': 'پەیوەندیمان پێوە بکە'},
  // Flight status screen
  'fst_title': {'ar': 'حالة الرحلة', 'en': 'Flight Status', 'ckb': 'دۆخی فڕین'},
  'fst_flight_no': {'ar': 'رقم الرحلة', 'en': 'Flight number', 'ckb': 'ژمارەی فڕین'},
  'fst_example': {'ar': 'مثال: FZ215', 'en': 'e.g. FZ215', 'ckb': 'نموونە: FZ215'},
  'fst_help': {'ar': 'أدخل رمز شركة الطيران ورقم الرحلة معاً بدون مسافة.', 'en': 'Enter the airline code and flight number together with no space.', 'ckb': 'کۆدی کۆمپانیای فڕین و ژمارەی فڕین پێکەوە بەبێ بۆشایی بنووسە.'},
  'fst_track': {'ar': 'تتبّع الرحلة', 'en': 'Track flight', 'ckb': 'بەدواداچوونی فڕین'},
  'fst_departure': {'ar': 'المغادرة', 'en': 'Departure', 'ckb': 'ڕۆیشتن'},
  'fst_arrival': {'ar': 'الوصول', 'en': 'Arrival', 'ckb': 'گەیشتن'},
  'fst_delayed': {'ar': 'تأخير حوالي', 'en': 'Delayed about', 'ckb': 'دواکەوتن نزیکەی'},
  'fst_minutes': {'ar': 'دقيقة', 'en': 'min', 'ckb': 'خولەک'},
  'fst_actual': {'ar': 'الفعلي', 'en': 'Actual', 'ckb': 'ڕاستەقینە'},
  'fst_terminal': {'ar': 'صالة', 'en': 'Terminal', 'ckb': 'هۆڵ'},
  'fst_gate': {'ar': 'بوابة', 'en': 'Gate', 'ckb': 'دەروازە'},
  'fst_disclaimer': {'ar': 'المعلومات إرشادية ومصدرها بيانات الطيران المباشرة. للتأكيد النهائي راجع شركة الطيران أو المطار.', 'en': 'Info is indicative, sourced from live flight data. For final confirmation, check with the airline or airport.', 'ckb': 'زانیارییەکان ڕێنمایین و لە داتای فڕینی ڕاستەوخۆوەن. بۆ دڵنیایی کۆتایی لەگەڵ کۆمپانیای فڕین یان فڕۆکەخانە بپشکنە.'},
  // AirLabs service messages
  'al_enter_flight': {'ar': 'أدخل رقم الرحلة (مثال: FZ215).', 'en': 'Enter the flight number (e.g. FZ215).', 'ckb': 'ژمارەی فڕین بنووسە (نموونە: FZ215).'},
  'al_soon': {'ar': 'ميزة تتبّع الرحلات ستُفعّل قريباً.', 'en': 'Flight tracking will be enabled soon.', 'ckb': 'تایبەتمەندی بەدواداچوونی فڕین بەم زووانە چالاک دەکرێت.'},
  'al_fetch_fail': {'ar': 'تعذّر جلب حالة الرحلة، حاول لاحقاً.', 'en': 'Couldn\'t fetch flight status, try later.', 'ckb': 'نەتوانرا دۆخی فڕین بهێنرێت، دواتر هەوڵ بدە.'},
  'al_no_data': {'ar': 'لا توجد بيانات لهذه الرحلة حالياً.', 'en': 'No data for this flight right now.', 'ckb': 'ئێستا هیچ داتایەک نییە بۆ ئەم فڕینە.'},
  'al_no_live': {'ar': 'لا توجد بيانات مباشرة لهذه الرحلة الآن. تأكد من رقم الرحلة أو جرّب قرب موعد الإقلاع.', 'en': 'No live data for this flight now. Check the flight number or try near departure time.', 'ckb': 'ئێستا داتای ڕاستەوخۆ نییە بۆ ئەم فڕینە. ژمارەی فڕین بپشکنە یان نزیک کاتی هەستان هەوڵ بدە.'},
  'al_conn_fail': {'ar': 'تعذّر الاتصال، تحقّق من الإنترنت.', 'en': 'Connection failed, check your internet.', 'ckb': 'پەیوەندی سەرکەوتوو نەبوو، ئینتەرنێتەکەت بپشکنە.'},
  'al_airline': {'ar': 'شركة الطيران', 'en': 'Airline', 'ckb': 'کۆمپانیای فڕین'},
  // Flight status labels
  'st_scheduled': {'ar': 'مجدولة', 'en': 'Scheduled', 'ckb': 'خشتەکراو'},
  'st_enroute': {'ar': 'في الجو', 'en': 'In air', 'ckb': 'لە ئاسمان'},
  'st_landed': {'ar': 'هبطت', 'en': 'Landed', 'ckb': 'نیشتەوە'},
  'st_cancelled': {'ar': 'ملغاة', 'en': 'Cancelled', 'ckb': 'هەڵوەشێنراوە'},
  'st_incident': {'ar': 'حالة طارئة', 'en': 'Incident', 'ckb': 'حاڵەتی لەناکاو'},
  'st_diverted': {'ar': 'محوّلة', 'en': 'Diverted', 'ckb': 'گۆڕدراو'},
  'st_unknown': {'ar': 'غير معروف', 'en': 'Unknown', 'ckb': 'نەزانراو'},
  // Stage 2 — search UI
  'trip_oneway': {'ar': 'ذهاب فقط', 'en': 'One-way', 'ckb': 'تەنها چوون'},
  'trip_round': {'ar': 'ذهاب وعودة', 'en': 'Round-trip', 'ckb': 'چوون و گەڕانەوە'},
  'f_return_date': {'ar': 'تاريخ العودة', 'en': 'Return date', 'ckb': 'بەرواری گەڕانەوە'},
  'swap': {'ar': 'تبديل', 'en': 'Swap', 'ckb': 'گۆڕین'},
  'sort_cheapest': {'ar': 'الأرخص', 'en': 'Cheapest', 'ckb': 'هەرزانترین'},
  'sort_fastest': {'ar': 'الأسرع', 'en': 'Fastest', 'ckb': 'خێراترین'},
  'sort_direct': {'ar': 'مباشر', 'en': 'Direct', 'ckb': 'ڕاستەوخۆ'},
  'sort_toprated': {'ar': 'الأعلى تقييماً', 'en': 'Top rated', 'ckb': 'باشترین هەڵسەنگاندن'},
  'sort_label': {'ar': 'ترتيب', 'en': 'Sort', 'ckb': 'ڕیزکردن'},
  'fs_hero_sub': {'ar': 'أفضل الأسعار لكل الوجهات', 'en': 'Best fares to every destination', 'ckb': 'باشترین نرخ بۆ هەموو شوێنێک'},
  'hs_hero_sub': {'ar': 'فنادق حول العالم بأسعار مناسبة', 'en': 'Hotels worldwide at great prices', 'ckb': 'ھۆتێل لە سەرانسەری جیهان بە نرخی گونجاو'},
  'results_count': {'ar': 'نتيجة', 'en': 'results', 'ckb': 'ئەنجام'},
  'per_night': {'ar': 'لليلة', 'en': 'per night', 'ckb': 'بۆ هەر شەو'},
};

/// Country / destination display names. Dropdown values stay Arabic (so the
/// WhatsApp message to the agency is Arabic); only the label shown is localized.
const Map<String, Map<String, String>> _co = {
  'تركيا': {'en': 'Turkey', 'ckb': 'تورکیا'},
  'الإمارات': {'en': 'UAE', 'ckb': 'ئیمارات'},
  'دول شنغن (أوروبا)': {'en': 'Schengen (Europe)', 'ckb': 'شەنگن (ئەورووپا)'},
  'مصر': {'en': 'Egypt', 'ckb': 'میسر'},
  'جورجيا': {'en': 'Georgia', 'ckb': 'گورجستان'},
  'أذربيجان': {'en': 'Azerbaijan', 'ckb': 'ئازەربایجان'},
  'ماليزيا': {'en': 'Malaysia', 'ckb': 'مالیزیا'},
  'تايلاند': {'en': 'Thailand', 'ckb': 'تایلەند'},
  'بريطانيا': {'en': 'Britain', 'ckb': 'بەریتانیا'},
  'أمريكا': {'en': 'USA', 'ckb': 'ئەمریکا'},
  'كندا': {'en': 'Canada', 'ckb': 'کەنەدا'},
  'أرمينيا': {'en': 'Armenia', 'ckb': 'ئەرمینیا'},
  'دبي': {'en': 'Dubai', 'ckb': 'دووبەی'},
  'المالديف': {'en': 'Maldives', 'ckb': 'مالدیڤ'},
};

/// Localized label for a dropdown whose stored value is Arabic. Falls back to ar.
String coName(String ar) {
  final lang = L10n.locale.value;
  if (lang == 'ar') return ar;
  return _co[ar]?[lang] ?? ar;
}
