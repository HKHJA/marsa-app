import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';

/// Stage 2 — shared professional search UI (travel-app style).
/// Gradient hero header, overlapping white form card, location cards with a
/// swap button, pill fields, segmented tabs, sort pills and a gradient button.

/// Scaffold with a gradient hero header and a white form card overlapping it.
class SearchHero extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Widget> children;
  const SearchHero({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.bg,
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          // Gradient hero
          Container(
            padding: EdgeInsets.fromLTRB(
                20, MediaQuery.of(context).padding.top + 16, 20, 54),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppConfig.navy, AppConfig.brandPrimary],
              ),
            ),
            child: Row(
              children: [
                const BackButton(color: Colors.white),
                const SizedBox(width: 4),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 3),
                      Text(subtitle,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ),
                Icon(icon, color: Colors.white.withOpacity(0.9), size: 34),
              ],
            ),
          ),
          // Overlapping form card
          Transform.translate(
            offset: const Offset(0, -34),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppConfig.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppConfig.line),
              ),
              child: Column(children: children),
            ),
          ),
        ],
      ),
    );
  }
}

/// Two-option segmented control (e.g. one-way / round-trip).
class SegmentTabs extends StatelessWidget {
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onChanged;
  const SegmentTabs({
    super.key,
    required this.labels,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: AppConfig.tintCyan,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: List.generate(labels.length, (i) {
          final on = i == selected;
          return Expanded(
            child: GestureDetector(
              onTap: () => onChanged(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                padding: const EdgeInsets.symmetric(vertical: 10),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: on ? AppConfig.navy : Colors.transparent,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Text(labels[i],
                    style: TextStyle(
                        color: on ? Colors.white : AppConfig.inkMuted,
                        fontWeight: FontWeight.bold,
                        fontSize: 13.5)),
              ),
            ),
          );
        }),
      ),
    );
  }
}

/// A tappable location card (From / To) with an icon.
class LocationCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final VoidCallback onTap;
  const LocationCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: AppConfig.bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppConfig.line),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppConfig.brandPrimary, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                          fontSize: 11.5, color: AppConfig.inkMuted)),
                  const SizedBox(height: 2),
                  Text(value,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: AppConfig.ink)),
                ],
              ),
            ),
            const Icon(Icons.keyboard_arrow_down, color: AppConfig.inkMuted),
          ],
        ),
      ),
    );
  }
}

/// From/To pair with a circular swap button between them.
class FromToSwap extends StatelessWidget {
  final Widget from;
  final Widget to;
  final VoidCallback onSwap;
  const FromToSwap({
    super.key,
    required this.from,
    required this.to,
    required this.onSwap,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.centerLeft,
      children: [
        Column(
          children: [
            from,
            const SizedBox(height: 10),
            to,
          ],
        ),
        Positioned(
          left: 0,
          right: 0,
          child: Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 24),
              child: Material(
                color: AppConfig.navy,
                shape: const CircleBorder(),
                elevation: 0,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: onSwap,
                  child: const Padding(
                    padding: EdgeInsets.all(9),
                    child: Icon(Icons.swap_vert, color: Colors.white, size: 22),
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// A compact pill-style field (date or counter), used in a row.
class PillField extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final VoidCallback? onTap;
  final Widget? trailing;
  const PillField({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.onTap,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: AppConfig.bg,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppConfig.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 15, color: AppConfig.brandPrimary),
                const SizedBox(width: 5),
                Text(label,
                    style: const TextStyle(
                        fontSize: 11.5, color: AppConfig.inkMuted)),
              ],
            ),
            const SizedBox(height: 6),
            trailing ??
                Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppConfig.ink)),
          ],
        ),
      ),
    );
  }
}

/// Big gradient primary action button.
class GradientButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  const GradientButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null;
    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppConfig.navy, AppConfig.brandPrimary],
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(15),
            onTap: onPressed,
            child: Container(
              height: 54,
              alignment: Alignment.center,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  Text(label,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Horizontal row of sort/filter pills. [selected] is the active index.
class SortPills extends StatelessWidget {
  final List<String> labels;
  final int selected;
  final ValueChanged<int> onChanged;
  const SortPills({
    super.key,
    required this.labels,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: labels.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final on = i == selected;
          return GestureDetector(
            onTap: () => onChanged(i),
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: on ? AppConfig.navy : AppConfig.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: on ? AppConfig.navy : AppConfig.line),
              ),
              child: Text(labels[i],
                  style: TextStyle(
                      color: on ? Colors.white : AppConfig.ink,
                      fontWeight: FontWeight.w600,
                      fontSize: 13)),
            ),
          );
        },
      ),
    );
  }
}

/// Shared date-picker helper returning the chosen date (or null).
Future<DateTime?> pickDate(BuildContext context, DateTime initial,
    {DateTime? first}) {
  return showDatePicker(
    context: context,
    initialDate: initial,
    firstDate: first ?? DateTime.now(),
    lastDate: DateTime.now().add(const Duration(days: 330)),
  );
}

String shortDate(DateTime d) => DateFormat('EEE, dd MMM').format(d);

/// A small +/- stepper used inside a bottom sheet or inline.
class MiniStepper extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  final int min;
  final int max;
  const MiniStepper({
    super.key,
    required this.value,
    required this.onChanged,
    this.min = 1,
    this.max = 9,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _btn(Icons.remove, value > min ? () => onChanged(value - 1) : null),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text('$value',
              style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w700)),
        ),
        _btn(Icons.add, value < max ? () => onChanged(value + 1) : null),
      ],
    );
  }

  Widget _btn(IconData i, VoidCallback? onTap) {
    final on = onTap != null;
    return InkWell(
      onTap: onTap,
      customBorder: const CircleBorder(),
      child: Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: on ? AppConfig.tintCyan : AppConfig.bg,
        ),
        child: Icon(i,
            size: 18,
            color: on ? AppConfig.brandPrimary : AppConfig.inkMuted),
      ),
    );
  }
}
