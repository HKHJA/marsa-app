import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_config.dart';

/// Shared form field builders used by the search and request screens.

Widget fieldShell(String label, Widget child) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label,
          style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppConfig.inkMuted)),
      const SizedBox(height: 6),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppConfig.line),
        ),
        child: child,
      ),
    ],
  );
}

Widget dropdownField(
    String label, String value, List<DropdownMenuItem<String>> items,
    ValueChanged<String> onCh) {
  return fieldShell(
    label,
    DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        isExpanded: true,
        value: value,
        items: items,
        onChanged: (v) => v == null ? null : onCh(v),
      ),
    ),
  );
}

Widget dateField(String label, DateTime value, ValueChanged<DateTime> onCh) {
  return Builder(
    builder: (context) => fieldShell(
      label,
      InkWell(
        onTap: () async {
          final picked = await showDatePicker(
            context: context,
            initialDate: value,
            firstDate: DateTime.now(),
            lastDate: DateTime.now().add(const Duration(days: 330)),
          );
          if (picked != null) onCh(picked);
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Row(
            children: [
              const Icon(Icons.calendar_today,
                  size: 18, color: AppConfig.brandPrimary),
              const SizedBox(width: 10),
              Text(DateFormat('EEE, dd MMM yyyy').format(value)),
            ],
          ),
        ),
      ),
    ),
  );
}

Widget counterField(String label, int value, ValueChanged<int> onCh,
    {int min = 1}) {
  return fieldShell(
    label,
    Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('$value',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          Row(
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                onPressed: value > min ? () => onCh(value - 1) : null,
              ),
              IconButton(
                icon: const Icon(Icons.add_circle,
                    color: AppConfig.brandPrimary),
                onPressed: value < 9 ? () => onCh(value + 1) : null,
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

Widget searchButton(String label, VoidCallback? onPressed) {
  return FilledButton.icon(
    icon: const Icon(Icons.search),
    label: Text(label,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
    onPressed: onPressed,
  );
}
