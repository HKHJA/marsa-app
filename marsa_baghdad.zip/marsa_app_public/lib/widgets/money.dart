import 'package:flutter/foundation.dart';
import '../config/app_config.dart';
import '../services/supabase_service.dart';

/// App-wide currency display. Prices are stored in USD; this formats them in
/// USD or IQD based on the toggle, using the exchange rate the owner sets in
/// the dashboard.
class Money {
  /// true = show Iraqi Dinar, false = US Dollar
  static final ValueNotifier<bool> useIqd = ValueNotifier<bool>(false);

  static double get rate {
    final r = SupabaseCatalog.usdToIqd;
    return r > 0 ? r : 1310; // sensible default if unset
  }

  static String fmt(double usd) {
    if (useIqd.value) {
      final iqd = (usd * rate).round();
      return '${_grouped(iqd)} د.ع';
    }
    return '${AppConfig.currencySymbol}${usd.round()}';
  }

  static String _grouped(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}
