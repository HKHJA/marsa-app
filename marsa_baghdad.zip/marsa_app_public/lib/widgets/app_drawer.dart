import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../screens/info_screen.dart';
import '../screens/services_screen.dart';
import '../services/whatsapp_service.dart';
import 'money.dart';

/// Side navigation drawer. Direction follows the selected language.
class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext c, Widget page) {
    Navigator.pop(c);
    Navigator.push(c, MaterialPageRoute(builder: (_) => page));
  }

  Future<void> _openUrl(BuildContext c, String url) async {
    Navigator.pop(c);
    try {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  void _pickCurrency(BuildContext c) {
    showModalBottomSheet(
      context: c,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Text(tr('choose_currency'),
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            RadioListTile<bool>(
              value: false,
              groupValue: Money.useIqd.value,
              onChanged: (_) {
                Money.useIqd.value = false;
                Navigator.pop(c);
              },
              title: Text(tr('usd')),
            ),
            RadioListTile<bool>(
              value: true,
              groupValue: Money.useIqd.value,
              onChanged: (_) {
                Money.useIqd.value = true;
                Navigator.pop(c);
              },
              title: Text(tr('iqd')),
            ),
          ],
        ),
      ),
    );
  }

  void _pickLanguage(BuildContext c) {
    Widget opt(String code, String label) => RadioListTile<String>(
          value: code,
          groupValue: L10n.locale.value,
          onChanged: (_) {
            L10n.set(code);
            Navigator.pop(c); // close sheet
            Navigator.of(c).maybePop(); // close drawer if open
          },
          title: Text(label),
        );
    showModalBottomSheet(
      context: c,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            Text(tr('choose_language'),
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            opt('ar', 'العربية'),
            opt('en', 'English'),
            opt('ckb', 'کوردی'),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppConfig.bg,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(18, 44, 18, 24),
            decoration: const BoxDecoration(
              color: AppConfig.navy,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(26),
                bottomRight: Radius.circular(26),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CircleAvatar(
                  radius: 27,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, color: AppConfig.navy, size: 30),
                ),
                const SizedBox(height: 10),
                Text(tr('appName'),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                Text(tr('tagline'),
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _section(tr('app_settings')),
          _item(
            icon: Icons.currency_exchange,
            color: AppConfig.tGreen,
            label: tr('currency'),
            trailing: ValueListenableBuilder<bool>(
              valueListenable: Money.useIqd,
              builder: (_, iqd, __) => Text(iqd ? 'IQD' : 'USD',
                  style: const TextStyle(color: AppConfig.inkMuted)),
            ),
            onTap: () => _pickCurrency(context),
          ),
          _item(
            icon: Icons.language,
            color: AppConfig.tCrimson,
            label: tr('language'),
            trailing: Text(L10n.nameOf(L10n.locale.value),
                style: const TextStyle(color: AppConfig.inkMuted)),
            onTap: () => _pickLanguage(context),
          ),
          _section(tr('general')),
          _item(
            icon: Icons.info_outline,
            color: AppConfig.tBlue,
            label: tr('about'),
            onTap: () => _go(context,
                InfoScreen(title: tr('about'), body: tr('about_body'))),
          ),
          _item(
            icon: Icons.headset_mic_outlined,
            color: AppConfig.navy2,
            label: tr('contact'),
            onTap: () {
              Navigator.pop(context);
              WhatsAppService.custom(
                  'مرحبًا ${AppConfig.appNameAr} 👋\nلدي استفسار، الرجاء التواصل معي. شكرًا.');
            },
          ),
          _item(
            icon: Icons.grid_view_rounded,
            color: AppConfig.tPurple,
            label: tr('cat_services'),
            onTap: () => _go(context, const ServicesScreen()),
          ),
          _item(
            icon: Icons.description_outlined,
            color: AppConfig.tOrange,
            label: tr('terms'),
            onTap: () => _go(context,
                InfoScreen(title: tr('terms'), body: tr('terms_body'))),
          ),
          _item(
            icon: Icons.shield_outlined,
            color: AppConfig.tCyan,
            label: tr('privacy'),
            onTap: () => _go(context,
                InfoScreen(title: tr('privacy'), body: tr('privacy_body'))),
          ),
          if (AppConfig.facebookUrl.isNotEmpty ||
              AppConfig.instagramUrl.isNotEmpty) ...[
            _section(tr('follow_us')),
            if (AppConfig.facebookUrl.isNotEmpty)
              _item(
                icon: Icons.facebook,
                color: const Color(0xFF1877F2),
                label: tr('facebook'),
                onTap: () => _openUrl(context, AppConfig.facebookUrl),
              ),
            if (AppConfig.instagramUrl.isNotEmpty)
              _item(
                icon: Icons.camera_alt,
                color: const Color(0xFFE1306C),
                label: tr('instagram'),
                onTap: () => _openUrl(context, AppConfig.instagramUrl),
              ),
          ],
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        child: Text(t,
            style: const TextStyle(
                color: AppConfig.inkMuted,
                fontSize: 12,
                fontWeight: FontWeight.w700)),
      );

  Widget _item({
    required IconData icon,
    required Color color,
    required String label,
    required VoidCallback onTap,
    Widget? trailing,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 34,
        height: 34,
        decoration:
            BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: Colors.white, size: 18),
      ),
      title: Text(label,
          style: const TextStyle(
              fontWeight: FontWeight.w600, color: AppConfig.ink, fontSize: 14)),
      trailing: trailing ??
          const Icon(Icons.chevron_left, color: AppConfig.inkMuted),
    );
  }
}
