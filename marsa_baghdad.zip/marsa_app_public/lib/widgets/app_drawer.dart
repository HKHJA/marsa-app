import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../screens/info_screen.dart';
import '../screens/services_screen.dart';
import '../services/whatsapp_service.dart';
import 'money.dart';

/// Side navigation drawer (opens from the right in RTL).
class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _go(BuildContext c, Widget page) {
    Navigator.pop(c); // close drawer
    Navigator.push(c, MaterialPageRoute(builder: (_) => page));
  }

  void _pickCurrency(BuildContext c) {
    showModalBottomSheet(
      context: c,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 8),
            const Text('اختر العملة',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            RadioListTile<bool>(
              value: false,
              groupValue: Money.useIqd.value,
              onChanged: (_) {
                Money.useIqd.value = false;
                Navigator.pop(c);
              },
              title: const Text('دولار أمريكي (USD)'),
            ),
            RadioListTile<bool>(
              value: true,
              groupValue: Money.useIqd.value,
              onChanged: (_) {
                Money.useIqd.value = true;
                Navigator.pop(c);
              },
              title: const Text('دينار عراقي (IQD)'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppConfig.bg,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          // header
          Container(
            padding: const EdgeInsets.fromLTRB(18, 44, 18, 24),
            decoration: const BoxDecoration(
              color: AppConfig.navy,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(26),
                bottomRight: Radius.circular(26),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CircleAvatar(
                  radius: 27,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, color: AppConfig.navy, size: 30),
                ),
                const SizedBox(height: 10),
                Text(AppConfig.appNameAr,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                const Text('للسفر والسياحة',
                    style: TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _section('إعدادات التطبيق'),
          _item(
            icon: Icons.currency_exchange,
            color: AppConfig.tGreen,
            label: 'العملة',
            trailing: ValueListenableBuilder<bool>(
              valueListenable: Money.useIqd,
              builder: (_, iqd, __) => Text(iqd ? 'IQD' : 'USD',
                  style: const TextStyle(color: AppConfig.inkMuted)),
            ),
            onTap: () => _pickCurrency(context),
          ),
          _item(
            icon: Icons.language,
            color: AppConfig.tCrimson,
            label: 'اللغة',
            trailing: const Text('العربية',
                style: TextStyle(color: AppConfig.inkMuted)),
            onTap: () {},
          ),
          _section('عام'),
          _item(
            icon: Icons.info_outline,
            color: AppConfig.tBlue,
            label: 'من نحن',
            onTap: () => _go(
                context,
                const InfoScreen(
                  title: 'من نحن',
                  body:
                      'مرسى بغداد للسفر والسياحة — وكالتكم لحجز تذاكر الطيران والفنادق حول العالم، الفيزا، الباقات السياحية، العمرة والحج، والمزيد. نوفّر أفضل الأسعار وخدمة سريعة عبر واتساب.',
                )),
          ),
          _item(
            icon: Icons.headset_mic_outlined,
            color: AppConfig.navy2,
            label: 'اتصل بنا',
            onTap: () {
              Navigator.pop(context);
              WhatsAppService.custom(
                  'مرحبًا ${AppConfig.appNameAr} 👋\nلدي استفسار، الرجاء التواصل معي. شكرًا.');
            },
          ),
          _item(
            icon: Icons.grid_view_rounded,
            color: AppConfig.tPurple,
            label: 'الخدمات',
            onTap: () => _go(context, const ServicesScreen()),
          ),
          _item(
            icon: Icons.description_outlined,
            color: AppConfig.tOrange,
            label: 'الشروط والأحكام',
            onTap: () => _go(
                context,
                const InfoScreen(
                  title: 'الشروط والأحكام',
                  body:
                      'يعمل تطبيق مرسى بغداد كوسيط لعرض الأسعار وتسهيل الحجز. يتم تأكيد الحجز والدفع عبر التواصل المباشر مع الوكالة على واتساب. الأسعار المعروضة استرشادية وقد تتغير حسب التوفر وقت التأكيد.',
                )),
          ),
          _item(
            icon: Icons.shield_outlined,
            color: AppConfig.tCyan,
            label: 'سياسة الخصوصية',
            onTap: () => _go(
                context,
                const InfoScreen(
                  title: 'سياسة الخصوصية',
                  body:
                      'نحترم خصوصيتك. لا يجمع التطبيق بياناتك الشخصية إلا ما تشاركه معنا عند طلب الحجز. تُستخدم الإشعارات لإعلامك بالعروض الجديدة، ويمكنك إيقافها من إعدادات هاتفك في أي وقت.',
                )),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        child: Text(t,
            style: const TextStyle(
                color: AppConfig.inkMuted,
                fontSize: 12,
                fontWeight: FontWeight.w700)),
      );

  Widget _item({
    required IconData icon,
    required Color color,
    required String label,
    required VoidCallback onTap,
    Widget? trailing,
  }) {
    return ListTile(
      onTap: onTap,
      leading: Container(
        width: 34,
        height: 34,
        decoration:
            BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: Colors.white, size: 18),
      ),
      title: Text(label,
          style: const TextStyle(
              fontWeight: FontWeight.w600, color: AppConfig.ink, fontSize: 14)),
      trailing: trailing ??
          const Icon(Icons.chevron_left, color: AppConfig.inkMuted),
    );
  }
}
