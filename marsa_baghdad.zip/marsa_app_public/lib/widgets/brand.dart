import 'package:flutter/material.dart';
import '../config/app_config.dart';

/// Small reusable brand pieces so screens stay tidy.

class BrandHeader extends StatelessWidget {
  final String subtitle;
  const BrandHeader({super.key, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      // Flat solid header (no gradient) for the modern look.
      decoration: const BoxDecoration(color: AppConfig.brandDark),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            'assets/logo_white.png',
            height: 96,
            fit: BoxFit.contain,
            errorBuilder: (_, __, ___) => Text(
              AppConfig.appNameAr,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ],
      ),
    );
  }
}

class RatingStars extends StatelessWidget {
  final double rating;
  const RatingStars({super.key, required this.rating});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (i) {
        return Icon(
          i < rating ? Icons.star : Icons.star_border,
          size: 16,
          color: AppConfig.brandAccent,
        );
      }),
    );
  }
}

class PriceTag extends StatelessWidget {
  final String price;
  final String? note;
  const PriceTag({super.key, required this.price, this.note});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          price,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: AppConfig.brandPrimary,
          ),
        ),
        if (note != null)
          Text(note!, style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ],
    );
  }
}
