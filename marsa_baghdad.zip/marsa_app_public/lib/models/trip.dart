/// A tracked booking/request the customer made from the app.
/// Stored locally (and optionally mirrored to the backend later).
class Trip {
  final String id;
  final String type; // flight | hotel | service | deal | visa
  final String title;
  final String subtitle;
  final String price; // pre-formatted display string, may be empty
  String status; // sent | confirmed | done | cancelled
  final int createdAt; // millisecondsSinceEpoch

  Trip({
    required this.id,
    required this.type,
    required this.title,
    required this.subtitle,
    required this.price,
    required this.status,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'subtitle': subtitle,
        'price': price,
        'status': status,
        'createdAt': createdAt,
      };

  factory Trip.fromJson(Map<String, dynamic> j) => Trip(
        id: '${j['id'] ?? ''}',
        type: '${j['type'] ?? 'service'}',
        title: '${j['title'] ?? ''}',
        subtitle: '${j['subtitle'] ?? ''}',
        price: '${j['price'] ?? ''}',
        status: '${j['status'] ?? 'sent'}',
        createdAt: j['createdAt'] is int
            ? j['createdAt']
            : int.tryParse('${j['createdAt']}') ?? 0,
      );
}
