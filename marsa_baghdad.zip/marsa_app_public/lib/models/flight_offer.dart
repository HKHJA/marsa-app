/// A single flight offer, already normalized from either mock data or Amadeus.
class FlightOffer {
  final String id;
  final String airline; // e.g. "Iraqi Airways"
  final String airlineCode; // e.g. "IA"
  final String origin; // IATA e.g. BGW
  final String destination; // IATA e.g. DXB
  final DateTime departure;
  final DateTime arrival;
  final int stops;
  final String durationLabel; // e.g. "2h 45m"
  final double basePrice; // supplier price (before markup)
  final double finalPrice; // price shown to customer (after markup)
  final String currency;
  final String cabin; // ECONOMY / BUSINESS

  const FlightOffer({
    required this.id,
    required this.airline,
    required this.airlineCode,
    required this.origin,
    required this.destination,
    required this.departure,
    required this.arrival,
    required this.stops,
    required this.durationLabel,
    required this.basePrice,
    required this.finalPrice,
    required this.currency,
    this.cabin = 'ECONOMY',
  });

  String get stopsLabel => stops == 0 ? 'Direct' : '$stops stop';
}
