import '../l10n/l10n.dart';

/// A service shown on the home grid.
/// type: 'flights' | 'hotels' | 'request'
class ServiceItem {
  final String id;
  final String emoji;
  final String titleAr;
  final String subAr;
  final String type;
  final String? badge;
  final String? fieldLabel; // e.g. "الدولة المطلوبة"
  final List<String>? fieldOptions; // e.g. countries
  final String? hint;

  const ServiceItem({
    required this.id,
    required this.emoji,
    required this.titleAr,
    required this.subAr,
    required this.type,
    this.badge,
    this.fieldLabel,
    this.fieldOptions,
    this.hint,
  });

  // Localized text (falls back to the Arabic value if no key exists).
  String get title {
    final v = tr('svc_${id}_t');
    return v == 'svc_${id}_t' ? titleAr : v;
  }

  String get sub {
    final v = tr('svc_${id}_s');
    return v == 'svc_${id}_s' ? subAr : v;
  }

  String? get hintTr {
    if (hint == null) return null;
    final v = tr('svc_${id}_h');
    return v == 'svc_${id}_h' ? hint : v;
  }

  String? get badgeTr {
    if (badge == null) return null;
    if (badge == 'جديد') return tr('badge_new');
    if (badge == 'الأكثر طلباً') return tr('badge_top');
    return badge;
  }

  String get fieldLabelTr {
    if (fieldLabel == 'الدولة المطلوبة') return tr('fl_country');
    if (fieldLabel == 'الوجهة') return tr('fl_destination');
    return fieldLabel ?? tr('choose');
  }
}
