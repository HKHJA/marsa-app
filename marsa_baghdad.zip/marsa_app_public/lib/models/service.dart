/// A service shown on the home grid.
/// type: 'flights' | 'hotels' | 'request'
class ServiceItem {
  final String id;
  final String emoji;
  final String titleAr;
  final String subAr;
  final String type;
  final String? badge;
  final String? fieldLabel; // e.g. "الدولة المطلوبة"
  final List<String>? fieldOptions; // e.g. countries
  final String? hint;

  const ServiceItem({
    required this.id,
    required this.emoji,
    required this.titleAr,
    required this.subAr,
    required this.type,
    this.badge,
    this.fieldLabel,
    this.fieldOptions,
    this.hint,
  });
}
