/// A single hotel offer, normalized from either mock data or Amadeus.
class HotelOffer {
  final String id;
  final String name;
  final String city;
  final double rating; // 0..5
  final int nights;
  final double basePricePerNight; // supplier price per night (before markup)
  final double finalTotal; // total for all nights, shown to customer (markup in)
  final String currency;
  final String board; // e.g. "Breakfast included"
  final String? thumbnail; // optional image url

  const HotelOffer({
    required this.id,
    required this.name,
    required this.city,
    required this.rating,
    required this.nights,
    required this.basePricePerNight,
    required this.finalTotal,
    required this.currency,
    this.board = 'Room only',
    this.thumbnail,
  });

  double get finalPerNight => nights == 0 ? finalTotal : finalTotal / nights;
}
