import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'config/app_config.dart';
import 'l10n/l10n.dart';
import 'services/trip_store.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await L10n.load();
  await TripStore.load();
  _initPush();
  runApp(const MarsaApp());
}

/// Register the device with OneSignal and ask for notification permission so
/// the dashboard "send notification" button reaches this phone. Wrapped in
/// try/catch so a push hiccup never blocks the app from opening.
void _initPush() {
  if (!AppConfig.oneSignalEnabled) return;
  try {
    OneSignal.initialize(AppConfig.oneSignalAppId);
    // NOTE: permission is requested from HomeScreen AFTER the first frame (and
    // after the welcome screen), because Android silently drops a notification
    // permission dialog requested before the first Activity is resumed.
  } catch (_) {}
}

class MarsaApp extends StatelessWidget {
  const MarsaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: L10n.locale,
      builder: (context, lang, __) => _app(context, lang),
    );
  }

  Widget _app(BuildContext context, String lang) {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppConfig.brandPrimary,
        primary: AppConfig.brandPrimary,
        secondary: AppConfig.brandAccent,
        surface: AppConfig.surface,
      ),
      scaffoldBackgroundColor: AppConfig.bg,
    );

    return MaterialApp(
      key: ValueKey('app_$lang'),
      title: AppConfig.appNameEn,
      debugShowCheckedModeBanner: false,
      theme: base.copyWith(
        // Modern geometric Arabic/Latin font.
        textTheme: GoogleFonts.tajawalTextTheme(base.textTheme)
            .apply(bodyColor: AppConfig.ink, displayColor: AppConfig.ink),
        // Flat app bar — solid navy, zero elevation, no scroll tint.
        appBarTheme: const AppBarTheme(
          backgroundColor: AppConfig.navy,
          foregroundColor: Colors.white,
          elevation: 0,
          scrolledUnderElevation: 0,
          surfaceTintColor: Colors.transparent,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 19,
            fontWeight: FontWeight.w800,
          ),
        ),
        // Flat filled buttons: solid navy, no elevation.
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: AppConfig.navy,
            foregroundColor: Colors.white,
            elevation: 0,
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.white,
          selectedItemColor: AppConfig.navy,
          unselectedItemColor: AppConfig.inkMuted,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
        ),
        dividerTheme: const DividerThemeData(
          color: AppConfig.line,
          thickness: 1,
          space: 1,
        ),
      ),
      // Material widgets use Arabic locale data for both ar & Kurdish (RTL),
      // English for en. Our own strings are translated via tr().
      locale: Locale(lang == 'en' ? 'en' : 'ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(
        textDirection: L10n.isRtl ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
      home: const HomeScreen(),
    );
  }
}
