import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/trip.dart';

/// Local, on-device history of the customer's bookings & requests ("My Trips").
/// No account needed — persists via SharedPreferences and surfaces reactively.
class TripStore {
  static const _key = 'trips_v1';
  static final ValueNotifier<List<Trip>> trips = ValueNotifier<List<Trip>>([]);

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_key);
    if (raw == null || raw.isEmpty) {
      trips.value = [];
      return;
    }
    try {
      final list = (jsonDecode(raw) as List)
          .map((e) => Trip.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      trips.value = list;
    } catch (_) {
      trips.value = [];
    }
  }

  static Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _key, jsonEncode(trips.value.map((t) => t.toJson()).toList()));
  }

  /// Record a new trip at the top of the list.
  static Future<void> add({
    required String type,
    required String title,
    required String subtitle,
    String price = '',
  }) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final t = Trip(
      id: '$now',
      type: type,
      title: title,
      subtitle: subtitle,
      price: price,
      status: 'sent',
      createdAt: now,
    );
    trips.value = [t, ...trips.value];
    await _persist();
  }

  static Future<void> setStatus(String id, String status) async {
    trips.value = [
      for (final t in trips.value)
        if (t.id == id)
          (Trip(
            id: t.id,
            type: t.type,
            title: t.title,
            subtitle: t.subtitle,
            price: t.price,
            status: status,
            createdAt: t.createdAt,
          ))
        else
          t
    ];
    await _persist();
  }

  static Future<void> remove(String id) async {
    trips.value = trips.value.where((t) => t.id != id).toList();
    await _persist();
  }
}
