import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import '../config/app_config.dart';
import '../models/flight_offer.dart';
import '../models/hotel_offer.dart';
import '../models/service.dart';
import 'pricing.dart';
import 'supabase_service.dart';

/// Builds a pre-filled WhatsApp message and opens it so the customer's booking
/// request lands directly in the agency's WhatsApp inbox.
class WhatsAppService {
  static final _d = DateFormat('EEE, dd MMM yyyy');

  static Future<void> bookFlight(FlightOffer f, {DateTime? returnDate}) async {
    final ret = returnDate != null ? '\n🔁 العودة: ${_d.format(returnDate)}' : '';
    final msg = '''
مرحبًا ${AppConfig.appNameAr} 👋
أرغب بحجز هذه الرحلة:

✈️ ${f.airline}
${f.origin} → ${f.destination}
📅 ${_d.format(f.departure)}$ret
🎫 ${f.cabin} • ${f.stopsLabel}
💵 السعر: ${Pricing.format(f.finalPrice)}

الرجاء تأكيد التوفر. شكرًا.''';
    await _send(msg);
  }

  static Future<void> bookHotel(HotelOffer h) async {
    final msg = '''
مرحبًا ${AppConfig.appNameAr} 👋
أرغب بحجز هذا الفندق:

🏨 ${h.name}
📍 ${h.city}
🌙 ${h.nights} ليالٍ • ${h.board}
💵 الإجمالي: ${Pricing.format(h.finalTotal)}

الرجاء تأكيد التوفر. شكرًا.''';
    await _send(msg);
  }

  static Future<void> requestService(ServiceItem s,
      {String? choice, String? details}) async {
    final b = StringBuffer();
    b.writeln('مرحبًا ${AppConfig.appNameAr} 👋');
    b.writeln('أرغب بخدمة: ${s.titleAr}');
    if (choice != null && s.fieldLabel != null) {
      b.writeln('${s.fieldLabel}: $choice');
    }
    if (details != null && details.trim().isNotEmpty) {
      b.writeln('التفاصيل: ${details.trim()}');
    }
    b.writeln();
    b.write('الرجاء تزويدي بالعرض والتفاصيل. شكرًا.');
    await _send(b.toString());
  }

  /// Open WhatsApp with a custom pre-filled message (used by deal cards, etc.).
  static Future<void> custom(String message) => _send(message);

  static Future<void> _send(String message) async {
    final uri = Uri.parse(
      'https://wa.me/${SupabaseCatalog.whatsapp}?text=${Uri.encodeComponent(message)}',
    );
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not open WhatsApp');
    }
  }
}
