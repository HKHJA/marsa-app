import '../config/app_config.dart';
import '../models/flight_offer.dart';
import '../models/hotel_offer.dart';
import 'duffel_service.dart';
import 'liteapi_service.dart';
import 'supabase_service.dart';
import 'travelpayouts_service.dart';

/// Single entry point the UI talks to.
/// Flights  = local Iraqi carriers (from the owner's dashboard) + international
///            (Travelpayouts cached prices). Hotels = dashboard + LiteAPI.
/// Returns only REAL results — never fabricated demo prices. If nothing is
/// found the UI shows an honest "contact us on WhatsApp" message.
class TravelService {
  static Future<List<FlightOffer>> searchFlights({
    required String origin,
    required String destination,
    required DateTime date,
    int adults = 1,
  }) async {
    await SupabaseCatalog.load();

    // Local airlines (Iraqi Airways, Fly Baghdad...) from the dashboard.
    final local = SupabaseCatalog.flightsFor(origin, destination, date);

    final intl = <FlightOffer>[];

    // International flights from Travelpayouts (cached/indicative prices).
    if (AppConfig.travelpayoutsEnabled) {
      try {
        intl.addAll(await TravelpayoutsService.searchFlights(
          origin: origin,
          destination: destination,
          date: date,
        ));
      } catch (_) {
        // ignore; still show local results
      }
    }

    // Duffel (dormant — only if a real token is ever set).
    if (AppConfig.duffelToken != 'YOUR_DUFFEL_TEST_TOKEN') {
      try {
        intl.addAll(await DuffelService.searchFlights(
          origin: origin,
          destination: destination,
          date: date,
          adults: adults,
        ));
      } catch (_) {}
    }

    // Real results only (owner's local flights + live international fares).
    // No fabricated fallback: an empty list makes the UI show a WhatsApp prompt.
    final all = [...local, ...intl];
    all.sort((a, b) => a.finalPrice.compareTo(b.finalPrice));
    return all;
  }

  static Future<List<HotelOffer>> searchHotels({
    required String cityCode,
    required DateTime checkIn,
    required int nights,
    int adults = 1,
  }) async {
    await SupabaseCatalog.load();
    var list = SupabaseCatalog.hotelsFor(cityCode, nights);

    // International hotels from LiteAPI (live prices; replaces the closed
    // Hotellook feed). Merged with the owner's dashboard hotels.
    if (AppConfig.liteApiEnabled) {
      try {
        list = [
          ...list,
          ...await LiteApiService.searchHotels(
            cityCode: cityCode,
            cityName: _cityName(cityCode),
            checkIn: checkIn,
            nights: nights,
            adults: adults,
          ),
        ];
      } catch (_) {}
    }

    // Real results only — no fabricated hotel fallback.
    list.sort((a, b) => a.finalTotal.compareTo(b.finalTotal));
    return list;
  }

  /// English city name for a code, so the hotel API can look it up by name.
  static String _cityName(String code) {
    for (final c in AppConfig.hotelCities) {
      if (c['code'] == code) return c['city'] ?? code;
    }
    for (final a in AppConfig.airports) {
      if (a['code'] == code) return a['city'] ?? code;
    }
    return code;
  }
}
