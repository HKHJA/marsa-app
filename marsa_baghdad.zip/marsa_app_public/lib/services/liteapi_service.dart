import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../models/hotel_offer.dart';
import 'supabase_service.dart';

/// International hotel prices from LiteAPI (Nuitée) — the replacement for the
/// closed Hotellook feed. Two-step, as the API is designed:
///   1) GET /data/hotels  → hotel ids + names + stars + photo for a city
///   2) POST /hotels/rates → live cheapest price per hotel id
/// We join them and apply the dashboard markup. Prices are indicative; the
/// customer confirms and books over WhatsApp. Returns [] on any problem so the
/// app quietly falls back to the owner's dashboard hotels.
class LiteApiService {
  static const _host = 'https://api.liteapi.travel/v3.0';

  /// City code (as used in the app) → ISO-2 country code for LiteAPI.
  static const Map<String, String> _country = {
    'DXB': 'AE', 'AUH': 'AE', 'SHJ': 'AE',
    'IST': 'TR', 'SAW': 'TR', 'AYT': 'TR',
    'CAI': 'EG', 'BEY': 'LB', 'AMM': 'JO',
    'MKC': 'SA', 'JED': 'SA', 'RUH': 'SA', 'MED': 'SA',
    'DOH': 'QA', 'KWI': 'KW', 'BAH': 'BH', 'MCT': 'OM',
    'BGW': 'IQ', 'BSR': 'IQ', 'EBL': 'IQ', 'NJF': 'IQ',
    'LHR': 'GB', 'TBS': 'GE', 'GYD': 'AZ', 'KUL': 'MY', 'BKK': 'TH',
  };

  static Future<List<HotelOffer>> searchHotels({
    required String cityCode,
    required String cityName,
    required DateTime checkIn,
    required int nights,
    int adults = 2,
    String currency = 'USD',
  }) async {
    if (!AppConfig.liteApiEnabled) return [];
    final country = _country[cityCode.toUpperCase()];
    if (country == null || cityName.isEmpty) return [];

    final headers = {
      'X-API-Key': AppConfig.liteApiKey,
      'accept': 'application/json',
    };

    try {
      // Step 1 — hotels in the city (id → name/stars/photo).
      final listUri = Uri.parse('$_host/data/hotels').replace(queryParameters: {
        'countryCode': country,
        'cityName': cityName,
        'limit': '25',
      });
      final listRes =
          await http.get(listUri, headers: headers).timeout(const Duration(seconds: 12));
      if (listRes.statusCode != 200) return [];
      final listBody = jsonDecode(listRes.body);
      final hotels = (listBody is Map && listBody['data'] is List)
          ? listBody['data'] as List
          : const [];
      if (hotels.isEmpty) return [];

      final meta = <String, Map<String, dynamic>>{};
      final ids = <String>[];
      for (final h in hotels) {
        if (h is! Map) continue;
        // LiteAPI has used a few id field names across versions — accept any.
        final id = '${h['id'] ?? h['hotelId'] ?? h['code'] ?? ''}';
        if (id.isEmpty) continue;
        ids.add(id);
        var thumb =
            '${h['thumbnail'] ?? h['main_photo'] ?? h['mainPhoto'] ?? ''}';
        if (thumb.isEmpty &&
            h['hotelImages'] is List &&
            (h['hotelImages'] as List).isNotEmpty) {
          final first = (h['hotelImages'] as List).first;
          if (first is Map) thumb = '${first['url'] ?? first['urlHd'] ?? ''}';
        }
        meta[id] = {
          'name': '${h['name'] ?? 'Hotel'}',
          'stars': _num(h['stars'] ?? h['starRating'] ?? h['rating']),
          'thumb': thumb,
        };
      }
      if (ids.isEmpty) return [];

      // Step 2 — live cheapest rate per hotel.
      final rateRes = await http
          .post(
            Uri.parse('$_host/hotels/rates'),
            headers: {...headers, 'content-type': 'application/json'},
            body: jsonEncode({
              'hotelIds': ids,
              'checkin': _fmt(checkIn),
              'checkout': _fmt(checkIn.add(Duration(days: nights))),
              'currency': currency,
              'guestNationality': 'IQ',
              'occupancies': [
                {'adults': adults < 1 ? 1 : adults}
              ],
            }),
          )
          .timeout(const Duration(seconds: 15));
      if (rateRes.statusCode != 200) return [];
      final rateBody = jsonDecode(rateRes.body);
      final data = (rateBody is Map && rateBody['data'] is List)
          ? rateBody['data'] as List
          : const [];

      final out = <HotelOffer>[];
      for (final entry in data) {
        if (entry is! Map) continue;
        final id = '${entry['hotelId'] ?? entry['id'] ?? ''}';
        final m = meta[id];
        if (m == null) continue;

        final cheapest = _cheapest(entry['roomTypes']);
        if (cheapest == null || cheapest.total <= 0) continue;

        out.add(HotelOffer(
          id: 'LITE-$id',
          name: '${m['name']}',
          city: cityCode,
          rating: (m['stars'] as double?) ?? 0,
          nights: nights,
          basePricePerNight: nights > 0 ? cheapest.total / nights : cheapest.total,
          finalTotal: SupabaseCatalog.markupHotelTotal(cheapest.total),
          currency: currency.toUpperCase(),
          board: cheapest.board.isEmpty ? 'Room only' : cheapest.board,
          thumbnail: '${m['thumb']}'.isEmpty ? null : '${m['thumb']}',
        ));
      }
      out.sort((a, b) => a.finalTotal.compareTo(b.finalTotal));
      return out;
    } catch (_) {
      return [];
    }
  }

  /// Cheapest rate (total across the stay) inside a hotel's roomTypes list.
  static _Rate? _cheapest(dynamic roomTypes) {
    if (roomTypes is! List) return null;
    _Rate? best;
    for (final rt in roomTypes) {
      if (rt is! Map) continue;
      final rates = rt['rates'];
      if (rates is! List) continue;
      for (final r in rates) {
        if (r is! Map) continue;
        final total = _totalAmount(r['retailRate']);
        if (total <= 0) continue;
        if (best == null || total < best.total) {
          best = _Rate(
              total,
              '${r['boardName'] ?? r['board'] ?? r['boardType'] ?? ''}');
        }
      }
    }
    return best;
  }

  static double _totalAmount(dynamic retailRate) {
    if (retailRate is! Map) return 0;
    final total = retailRate['total'];
    // Common shape: total is an array of {amount, currency}.
    if (total is List && total.isNotEmpty && total.first is Map) {
      return _num((total.first as Map)['amount']);
    }
    // Fallbacks seen across versions: scalar total, or amount/price fields.
    if (total is num) return total.toDouble();
    for (final k in ['amount', 'price', 'suggestedSellingPrice']) {
      final v = retailRate[k];
      if (v is num) return v.toDouble();
      if (v is Map && v['amount'] is num) return (v['amount'] as num).toDouble();
    }
    return 0;
  }

  static String _fmt(DateTime d) => '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  static double _num(dynamic v) =>
      v == null ? 0 : (v is num ? v.toDouble() : double.tryParse('$v') ?? 0);
}

class _Rate {
  final double total;
  final String board;
  const _Rate(this.total, this.board);
}
