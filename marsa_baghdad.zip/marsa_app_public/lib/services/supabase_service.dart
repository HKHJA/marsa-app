import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../models/flight_offer.dart';
import '../models/hotel_offer.dart';

/// Reads the shared catalog (local flight prices, hotels, services, settings)
/// that the admin dashboard writes to Supabase. This is what makes the owner's
/// price edits appear in the app automatically — no rebuild needed.
///
/// Uses the Supabase REST endpoint with the public (publishable) key; writes
/// are blocked by row-level security, reads are public.
class SupabaseCatalog {
  static Map<String, dynamic>? _cache;

  static bool get configured =>
      AppConfig.supabaseUrl.startsWith('https://') &&
      !AppConfig.supabaseKey.startsWith('YOUR_');

  /// Load the single catalog row. Cached after first fetch.
  static Future<Map<String, dynamic>> load({bool force = false}) async {
    if (_cache != null && !force) return _cache!;
    if (!configured) return _cache = {};
    try {
      final res = await http.get(
        Uri.parse(
            '${AppConfig.supabaseUrl}/rest/v1/catalog?id=eq.data&select=data'),
        headers: {
          'apikey': AppConfig.supabaseKey,
          'Authorization': 'Bearer ${AppConfig.supabaseKey}',
        },
      ).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        if (list.isNotEmpty && list.first['data'] is Map) {
          return _cache = (list.first['data'] as Map).cast<String, dynamic>();
        }
      }
    } catch (_) {
      // network / parse issues → treated as empty, caller falls back to demo
    }
    return _cache = {};
  }

  static Map<String, dynamic> get settings =>
      (_cache?['settings'] as Map?)?.cast<String, dynamic>() ?? {};

  static double get usdToIqd => _num(settings['usdToIqd'], 0);

  static Map<String, dynamic> get _announcement =>
      (settings['announcement'] as Map?)?.cast<String, dynamic>() ?? {};
  static bool get announcementEnabled => _announcement['enabled'] == true;
  static String get announcementText => '${_announcement['text'] ?? ''}';

  /// Promotional deal cards managed from the dashboard.
  static List<Map<String, dynamic>> get deals =>
      ((_cache?['deals'] as List?) ?? [])
          .whereType<Map>()
          .map((e) => e.cast<String, dynamic>())
          .toList();

  /// Customer reviews / testimonials managed from the dashboard.
  static List<Map<String, dynamic>> get reviews =>
      ((_cache?['reviews'] as List?) ?? [])
          .whereType<Map>()
          .map((e) => e.cast<String, dynamic>())
          .toList();

  // Read from settings.birthday (where the dashboard writes it) first, then
  // fall back to a top-level birthday key for older data. Robust either way.
  static Map<String, dynamic> get _birthday {
    final inSettings = (settings['birthday'] as Map?)?.cast<String, dynamic>();
    if (inSettings != null && inSettings.isNotEmpty) return inSettings;
    return (_cache?['birthday'] as Map?)?.cast<String, dynamic>() ?? {};
  }
  static bool get birthdayEnabled => _birthday['enabled'] == true;
  static String get birthdayTitle =>
      '${_birthday['title'] ?? '🎉 كل عام وأنتِ بخير'}';
  static String get birthdayMessage => '${_birthday['message'] ?? ''}';

  static double _num(dynamic v, double d) =>
      v == null ? d : (v is num ? v.toDouble() : double.tryParse('$v') ?? d);

  static double _flightFinal(double base) {
    final pct = _num(settings['flightPct'], AppConfig.flightMarkupPercent);
    final fix = _num(settings['flightFixed'], AppConfig.flightMarkupFixed);
    return (base * (1 + pct / 100) + fix).ceilToDouble();
  }

  static double _hotelFinal(double perNight, int nights) {
    final pct = _num(settings['hotelPct'], AppConfig.hotelMarkupPercent);
    return (perNight * nights * (1 + pct / 100)).ceilToDouble();
  }

  /// Public markup helpers so other price sources (Travelpayouts) apply the
  /// exact same dashboard-controlled margin as the local flights/hotels.
  static double markupFlight(double base) => _flightFinal(base);
  static double markupHotelTotal(double total) {
    final pct = _num(settings['hotelPct'], AppConfig.hotelMarkupPercent);
    return (total * (1 + pct / 100)).ceilToDouble();
  }

  /// Local flights for a route, converted to FlightOffer with markup applied.
  static List<FlightOffer> flightsFor(
      String origin, String destination, DateTime date) {
    final raw = (_cache?['flights'] as List?) ?? [];
    final out = <FlightOffer>[];
    for (var i = 0; i < raw.length; i++) {
      final f = (raw[i] as Map).cast<String, dynamic>();
      if ('${f['from']}'.toUpperCase() != origin.toUpperCase()) continue;
      if ('${f['to']}'.toUpperCase() != destination.toUpperCase()) continue;
      final base = _num(f['price'], 0);
      final dur = _num(f['dur'], 180).toInt();
      final dep = DateTime(date.year, date.month, date.day, 8, 0);
      out.add(FlightOffer(
        id: 'LOCAL-$i',
        airline: '${f['airline'] ?? 'Airline'}',
        airlineCode: '',
        origin: origin,
        destination: destination,
        departure: dep,
        arrival: dep.add(Duration(minutes: dur)),
        stops: _num(f['stops'], 0).toInt(),
        durationLabel: '${dur ~/ 60}h ${dur % 60}m',
        basePrice: base,
        finalPrice: _flightFinal(base),
        currency: '${settings['currency'] ?? 'USD'}',
      ));
    }
    return out;
  }

  /// Hotels for a city, converted to HotelOffer with markup applied.
  static List<HotelOffer> hotelsFor(String cityCode, int nights) {
    final raw = (_cache?['hotels'] as List?) ?? [];
    final out = <HotelOffer>[];
    for (var i = 0; i < raw.length; i++) {
      final h = (raw[i] as Map).cast<String, dynamic>();
      if ('${h['city']}'.toUpperCase() != cityCode.toUpperCase()) continue;
      final per = _num(h['price'], 0);
      out.add(HotelOffer(
        id: 'LOCALH-$i',
        name: '${h['name'] ?? ''}',
        city: cityCode,
        rating: _num(h['stars'], 0),
        nights: nights,
        basePricePerNight: per,
        finalTotal: _hotelFinal(per, nights),
        currency: '${settings['currency'] ?? 'USD'}',
        board: '${h['board'] ?? ''}',
      ));
    }
    return out;
  }

  /// Whether a service id is enabled (defaults to true if not configured).
  static bool serviceEnabled(String id) {
    final raw = (_cache?['services'] as List?) ?? [];
    for (final s in raw) {
      if (s is Map && s['id'] == id) return s['enabled'] != false;
    }
    return true;
  }

  /// Optional "from" price for a service, or null.
  static String? servicePrice(String id) {
    final raw = (_cache?['services'] as List?) ?? [];
    for (final s in raw) {
      if (s is Map && s['id'] == id) {
        final p = s['fromPrice'];
        if (p != null && '$p'.trim().isNotEmpty) return '$p';
      }
    }
    return null;
  }

  /// WhatsApp number from settings, falling back to AppConfig.
  static String get whatsapp {
    final w = '${settings['whatsapp'] ?? ''}'.trim();
    return w.isNotEmpty ? w : AppConfig.whatsappNumber;
  }
}
