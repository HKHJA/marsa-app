import '../models/flight_offer.dart';
import '../models/hotel_offer.dart';
import 'pricing.dart';

/// Deterministic, realistic demo data so the app looks and feels complete
/// without any API keys. Prices already run through the markup engine, exactly
/// like live data will.
class MockData {
  static List<FlightOffer> flights({
    required String origin,
    required String destination,
    required DateTime date,
  }) {
    final seeds = <Map<String, dynamic>>[
      {'a': 'Iraqi Airways', 'c': 'IA', 'base': 210.0, 'stops': 0, 'dur': 210, 'dep': 7},
      {'a': 'Fly Baghdad', 'c': 'IF', 'base': 189.0, 'stops': 0, 'dur': 205, 'dep': 10},
      {'a': 'Turkish Airlines', 'c': 'TK', 'base': 255.0, 'stops': 1, 'dur': 430, 'dep': 13},
      {'a': 'Emirates', 'c': 'EK', 'base': 298.0, 'stops': 0, 'dur': 195, 'dep': 16},
      {'a': 'Royal Jordanian', 'c': 'RJ', 'base': 232.0, 'stops': 1, 'dur': 380, 'dep': 20},
    ];

    return List.generate(seeds.length, (i) {
      final s = seeds[i];
      final dep = DateTime(date.year, date.month, date.day, s['dep'] as int, 0);
      final arr = dep.add(Duration(minutes: s['dur'] as int));
      final base = s['base'] as double;
      return FlightOffer(
        id: 'MOCK-F-$i',
        airline: s['a'] as String,
        airlineCode: s['c'] as String,
        origin: origin,
        destination: destination,
        departure: dep,
        arrival: arr,
        stops: s['stops'] as int,
        durationLabel: _dur(s['dur'] as int),
        basePrice: base,
        finalPrice: Pricing.flightPrice(base),
        currency: 'USD',
      );
    });
  }

  static List<HotelOffer> hotels({
    required String city,
    required int nights,
  }) {
    final seeds = <Map<String, dynamic>>[
      {'n': 'Grand Millennium', 'r': 5.0, 'base': 120.0, 'b': 'Breakfast included'},
      {'n': 'Marina Bay Hotel', 'r': 4.0, 'base': 85.0, 'b': 'Room only'},
      {'n': 'Rose Boutique Hotel', 'r': 4.0, 'base': 72.0, 'b': 'Breakfast included'},
      {'n': 'City Center Suites', 'r': 3.0, 'base': 54.0, 'b': 'Room only'},
      {'n': 'Palm Residence', 'r': 5.0, 'base': 149.0, 'b': 'Half board'},
    ];

    return List.generate(seeds.length, (i) {
      final s = seeds[i];
      final base = s['base'] as double;
      return HotelOffer(
        id: 'MOCK-H-$i',
        name: s['n'] as String,
        city: city,
        rating: s['r'] as double,
        nights: nights,
        basePricePerNight: base,
        finalTotal: Pricing.hotelTotal(base, nights),
        currency: 'USD',
        board: s['b'] as String,
      );
    });
  }

  static String _dur(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    return '${h}h ${m}m';
  }
}
