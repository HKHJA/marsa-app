import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../models/flight_offer.dart';
import '../models/hotel_offer.dart';
import 'supabase_service.dart';

/// International flight & hotel prices from Travelpayouts (Aviasales data API +
/// Hotellook). Prices are CACHED / indicative — the customer confirms the final
/// price and books over WhatsApp. Local Iraqi carriers stay on dashboard prices;
/// this fills international routes and hotels. Markup is applied with the same
/// dashboard-controlled margin used everywhere else.
class TravelpayoutsService {
  static const _flightBase =
      'https://api.travelpayouts.com/aviasales/v3/prices_for_dates';

  // Common carriers so we show a name instead of a 2-letter code.
  static const Map<String, String> _airlineNames = {
    'FZ': 'flydubai', 'EK': 'Emirates', 'TK': 'Turkish Airlines',
    'QR': 'Qatar Airways', 'GF': 'Gulf Air', 'MS': 'EgyptAir',
    'RJ': 'Royal Jordanian', 'ME': 'MEA', 'W6': 'Wizz Air', 'PC': 'Pegasus',
    'IA': 'Iraqi Airways', 'IF': 'Fly Baghdad', 'SV': 'Saudia', 'XY': 'flynas',
    'J9': 'Jazeera Airways', 'KU': 'Kuwait Airways', 'WY': 'Oman Air',
    'G9': 'Air Arabia', 'EY': 'Etihad', '6E': 'IndiGo', 'AH': 'Air Algérie',
    'LH': 'Lufthansa', 'BA': 'British Airways', 'AF': 'Air France',
  };

  static Future<List<FlightOffer>> searchFlights({
    required String origin,
    required String destination,
    required DateTime date,
    String currency = 'usd',
  }) async {
    if (!AppConfig.travelpayoutsEnabled) return [];
    // Query the whole MONTH, not a single day. The cached-price endpoint stores
    // very few fares per exact date (often just one for thin markets like
    // Baghdad), but returns the cheapest fare for many days across a month — so
    // this turns "one result" into a real list. Each fare keeps its own date.
    final uri = Uri.parse(_flightBase).replace(queryParameters: {
      'origin': origin,
      'destination': destination,
      'departure_at': _month(date),
      'currency': currency,
      'one_way': 'true',
      'sorting': 'price',
      'direct': 'false',
      'limit': '30',
      'token': AppConfig.travelpayoutsToken,
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode != 200) return [];
      final body = jsonDecode(res.body);
      final list =
          (body is Map && body['data'] is List) ? body['data'] as List : const [];
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final out = <FlightOffer>[];
      for (var i = 0; i < list.length; i++) {
        final f = (list[i] as Map).cast<String, dynamic>();
        final base = _num(f['price']);
        if (base <= 0) continue;
        final dep = DateTime.tryParse('${f['departure_at'] ?? ''}') ?? date;
        if (dep.isBefore(today)) continue; // never show past fares
        final dur = _num(f['duration']).toInt();
        final code = '${f['airline'] ?? ''}';
        // Use the ACTUAL airports the fare is for (avoids labelling e.g. a
        // Sharjah fare as Dubai).
        final org = '${f['origin_airport'] ?? ''}';
        final dst = '${f['destination_airport'] ?? ''}';
        out.add(FlightOffer(
          id: 'TP-$i',
          airline: _airlineNames[code] ?? (code.isEmpty ? 'Airline' : code),
          airlineCode: code,
          origin: org.isEmpty ? origin : org,
          destination: dst.isEmpty ? destination : dst,
          departure: dep,
          arrival: dep.add(Duration(minutes: dur > 0 ? dur : 180)),
          stops: _num(f['transfers']).toInt(),
          durationLabel: dur > 0 ? '${dur ~/ 60}h ${dur % 60}m' : '',
          basePrice: base,
          finalPrice: SupabaseCatalog.markupFlight(base),
          currency: currency.toUpperCase(),
        ));
      }
      out.sort((a, b) => a.departure.compareTo(b.departure));
      return out;
    } catch (_) {
      return [];
    }
  }

  static Future<List<HotelOffer>> searchHotels({
    required String cityCode,
    required String cityName,
    required DateTime checkIn,
    required int nights,
    String currency = 'usd',
  }) async {
    // Hotellook (Travelpayouts' hotel data API) was permanently shut down on
    // 2025-10-20 and has no replacement, so we never call it. Hotels are served
    // from the owner's dashboard list instead. Kept as a no-op so the merge
    // logic in TravelService stays unchanged if a hotel API returns later.
    return const [];
  }

  static String _month(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}';
  static double _num(dynamic v) =>
      v == null ? 0 : (v is num ? v.toDouble() : double.tryParse('$v') ?? 0);
}
