import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../config/app_config.dart';
import '../models/flight_offer.dart';
import 'pricing.dart';

/// Live flight prices from Duffel (https://duffel.com).
/// Only used when AppConfig.useMockData == false.
///
/// We only READ offers (to show a price); booking happens over WhatsApp, so no
/// ticketing/accreditation is needed. If you later want in-app checkout, Duffel
/// can act as merchant of record — that would be a separate build.
class DuffelService {
  static Map<String, String> get _headers => {
        'Authorization': 'Bearer ${AppConfig.duffelToken}',
        'Duffel-Version': AppConfig.duffelVersion,
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  /// POST /air/offer_requests?return_offers=true → returns offers inline.
  static Future<List<FlightOffer>> searchFlights({
    required String origin,
    required String destination,
    required DateTime date,
    int adults = 1,
  }) async {
    final dateStr = DateFormat('yyyy-MM-dd').format(date);
    final body = jsonEncode({
      'data': {
        'slices': [
          {
            'origin': origin,
            'destination': destination,
            'departure_date': dateStr,
          }
        ],
        'passengers': List.generate(adults, (_) => {'type': 'adult'}),
        'cabin_class': 'economy',
      }
    });

    final res = await http.post(
      Uri.parse(
          '${AppConfig.duffelBaseUrl}/air/offer_requests?return_offers=true'),
      headers: _headers,
      body: body,
    );
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('Duffel flight search failed: '
          '${res.statusCode} ${res.body}');
    }

    final data = jsonDecode(res.body)['data'] as Map<String, dynamic>;
    final offers = (data['offers'] as List?) ?? [];

    final result = <FlightOffer>[];
    for (var i = 0; i < offers.length && i < 20; i++) {
      final o = offers[i] as Map<String, dynamic>;
      final slice = (o['slices'] as List).first as Map<String, dynamic>;
      final segs = slice['segments'] as List;
      final firstSeg = segs.first as Map<String, dynamic>;
      final lastSeg = segs.last as Map<String, dynamic>;
      final base = double.tryParse(o['total_amount']?.toString() ?? '0') ?? 0;

      final owner = o['owner'] as Map<String, dynamic>?;
      final airline = owner?['name'] as String? ??
          (firstSeg['marketing_carrier']?['name'] as String?) ??
          'Airline';
      final airlineCode = owner?['iata_code'] as String? ?? '';

      result.add(FlightOffer(
        id: (o['id'] ?? 'D-$i').toString(),
        airline: airline,
        airlineCode: airlineCode,
        origin: firstSeg['origin']?['iata_code'] as String? ?? origin,
        destination:
            lastSeg['destination']?['iata_code'] as String? ?? destination,
        departure: DateTime.parse(firstSeg['departing_at'] as String),
        arrival: DateTime.parse(lastSeg['arriving_at'] as String),
        stops: segs.length - 1,
        durationLabel: _isoDuration(slice['duration'] as String?),
        basePrice: base,
        finalPrice: Pricing.flightPrice(base),
        currency: o['total_currency'] as String? ?? 'USD',
        cabin: 'ECONOMY',
      ));
    }
    return result;
  }

  /// Convert ISO-8601 duration like "PT4H30M" to "4h 30m".
  static String _isoDuration(String? iso) {
    if (iso == null) return '';
    final h = RegExp(r'(\d+)H').firstMatch(iso)?.group(1) ?? '0';
    final m = RegExp(r'(\d+)M').firstMatch(iso)?.group(1) ?? '0';
    return '${h}h ${m}m';
  }
}
