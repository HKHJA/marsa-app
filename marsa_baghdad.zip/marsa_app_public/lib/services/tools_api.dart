import 'dart:convert';
import 'dart:math' as math;
import 'package:http/http.dart' as http;

/// Backend-free travel utilities using free, keyless public APIs.
/// Currency: open.er-api.com • Weather: open-meteo.com • Prayer: aladhan.com
class ToolsApi {
  // ---- Currency -----------------------------------------------------------
  static Map<String, double>? _rates; // relative to USD
  static DateTime? _ratesAt;

  static const currencies = [
    'USD', 'IQD', 'EUR', 'TRY', 'AED', 'SAR', 'GBP', 'JOD', 'QAR', 'EGP', 'KWD'
  ];

  /// Returns USD-based rates, cached for the session.
  static Future<Map<String, double>> rates() async {
    if (_rates != null &&
        _ratesAt != null &&
        DateTime.now().difference(_ratesAt!).inHours < 6) {
      return _rates!;
    }
    final res = await http
        .get(Uri.parse('https://open.er-api.com/v6/latest/USD'))
        .timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) throw Exception('rates ${res.statusCode}');
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    final r = (body['rates'] as Map).map(
        (k, v) => MapEntry('$k', (v as num).toDouble()));
    _rates = r;
    _ratesAt = DateTime.now();
    return r;
  }

  static double convert(
      Map<String, double> rates, double amount, String from, String to) {
    final rf = rates[from] ?? 1;
    final rt = rates[to] ?? 1;
    if (rf == 0) return 0;
    return amount / rf * rt;
  }

  // ---- Weather ------------------------------------------------------------
  static Future<WeatherData> weather(double lat, double lon) async {
    final uri = Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon'
        '&current=temperature_2m,weather_code,relative_humidity_2m,wind_speed_10m'
        '&daily=weather_code,temperature_2m_max,temperature_2m_min'
        '&forecast_days=4&timezone=auto');
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) throw Exception('weather ${res.statusCode}');
    final b = jsonDecode(res.body) as Map<String, dynamic>;
    final cur = b['current'] as Map<String, dynamic>;
    final daily = b['daily'] as Map<String, dynamic>;
    final days = <WeatherDay>[];
    final times = (daily['time'] as List).cast<String>();
    final codes = (daily['weather_code'] as List);
    final maxs = (daily['temperature_2m_max'] as List);
    final mins = (daily['temperature_2m_min'] as List);
    for (var i = 0; i < times.length; i++) {
      days.add(WeatherDay(
        date: times[i],
        code: (codes[i] as num).toInt(),
        max: (maxs[i] as num).toDouble(),
        min: (mins[i] as num).toDouble(),
      ));
    }
    return WeatherData(
      temp: (cur['temperature_2m'] as num).toDouble(),
      code: (cur['weather_code'] as num).toInt(),
      humidity: (cur['relative_humidity_2m'] as num?)?.toDouble() ?? 0,
      wind: (cur['wind_speed_10m'] as num?)?.toDouble() ?? 0,
      days: days,
    );
  }

  // ---- Prayer times -------------------------------------------------------
  /// method: Aladhan calculation method id (3 = MWL default).
  static Future<Map<String, String>> prayerTimes(String city, String country,
      {int method = 3}) async {
    final uri = Uri.parse(
        'https://api.aladhan.com/v1/timingsByCity?city=${Uri.encodeComponent(city)}'
        '&country=${Uri.encodeComponent(country)}&method=$method');
    final res = await http.get(uri).timeout(const Duration(seconds: 12));
    if (res.statusCode != 200) throw Exception('prayer ${res.statusCode}');
    final b = jsonDecode(res.body) as Map<String, dynamic>;
    final t = (b['data']?['timings'] as Map).cast<String, dynamic>();
    String hm(String k) {
      final v = '${t[k] ?? ''}';
      return v.split(' ').first; // strip "(+03)" suffixes
    }

    return {
      'Fajr': hm('Fajr'),
      'Sunrise': hm('Sunrise'),
      'Dhuhr': hm('Dhuhr'),
      'Asr': hm('Asr'),
      'Maghrib': hm('Maghrib'),
      'Isha': hm('Isha'),
    };
  }

  // ---- Qibla --------------------------------------------------------------
  /// Great-circle initial bearing from (lat,lon) to the Kaaba, in degrees.
  static double qiblaBearing(double lat, double lon) {
    const kLat = 21.4225, kLon = 39.8262;
    final phi1 = _rad(lat), phi2 = _rad(kLat);
    final dLon = _rad(kLon - lon);
    final y = math.sin(dLon) * math.cos(phi2);
    final x = math.cos(phi1) * math.sin(phi2) -
        math.sin(phi1) * math.cos(phi2) * math.cos(dLon);
    var deg = _deg(math.atan2(y, x));
    return (deg + 360) % 360;
  }

  static double _rad(double d) => d * math.pi / 180;
  static double _deg(double r) => r * 180 / math.pi;
}

class WeatherData {
  final double temp;
  final int code;
  final double humidity;
  final double wind;
  final List<WeatherDay> days;
  WeatherData({
    required this.temp,
    required this.code,
    required this.humidity,
    required this.wind,
    required this.days,
  });
}

class WeatherDay {
  final String date;
  final int code;
  final double max;
  final double min;
  WeatherDay(
      {required this.date,
      required this.code,
      required this.max,
      required this.min});
}

/// WMO weather-code → an icon + a translatable label key.
class WeatherCode {
  static ({String icon, String key}) of(int c) {
    if (c == 0) return (icon: '☀️', key: 'wx_clear');
    if (c <= 2) return (icon: '🌤️', key: 'wx_partly');
    if (c == 3) return (icon: '☁️', key: 'wx_cloudy');
    if (c >= 45 && c <= 48) return (icon: '🌫️', key: 'wx_fog');
    if (c >= 51 && c <= 57) return (icon: '🌦️', key: 'wx_drizzle');
    if (c >= 61 && c <= 67) return (icon: '🌧️', key: 'wx_rain');
    if (c >= 71 && c <= 77) return (icon: '❄️', key: 'wx_snow');
    if (c >= 80 && c <= 82) return (icon: '🌧️', key: 'wx_showers');
    if (c >= 95) return (icon: '⛈️', key: 'wx_storm');
    return (icon: '🌡️', key: 'wx_clear');
  }
}
