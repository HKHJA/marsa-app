import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';
import '../l10n/l10n.dart';

/// Real-time flight status via AirLabs (https://airlabs.co).
/// Single-flight lookup by IATA flight number, e.g. "FZ215".
/// Free tier, HTTPS. Booking still happens over WhatsApp — this is an
/// info-only convenience screen. Returns a [FlightStatusResult] that always
/// carries a user-facing Arabic message so the UI never has to guess.
class AirLabsService {
  static const _base = 'https://airlabs.co/api/v9/flight';

  // Common carriers → readable names (Arabic-friendly Latin names).
  static const Map<String, String> _airlineNames = {
    'FZ': 'flydubai', 'EK': 'Emirates', 'TK': 'Turkish Airlines',
    'QR': 'Qatar Airways', 'GF': 'Gulf Air', 'MS': 'EgyptAir',
    'RJ': 'Royal Jordanian', 'ME': 'MEA', 'W6': 'Wizz Air', 'PC': 'Pegasus',
    'VF': 'Pegasus', 'IA': 'Iraqi Airways', 'IF': 'Fly Baghdad',
    'SV': 'Saudia', 'XY': 'flynas', 'J9': 'Jazeera Airways',
    'KU': 'Kuwait Airways', 'WY': 'Oman Air', 'G9': 'Air Arabia',
    'EY': 'Etihad', '6E': 'IndiGo', 'LH': 'Lufthansa', 'BA': 'British Airways',
    'AF': 'Air France',
  };

  static Future<FlightStatusResult> byFlight(String flightIata) async {
    final code =
        flightIata.trim().toUpperCase().replaceAll(RegExp(r'\s+'), '');
    if (code.isEmpty) {
      return FlightStatusResult.err(tr('al_enter_flight'));
    }
    if (!AppConfig.airlabsEnabled) {
      return FlightStatusResult.err(tr('al_soon'));
    }
    final uri = Uri.parse(_base).replace(queryParameters: {
      'flight_iata': code,
      'api_key': AppConfig.airlabsApiKey,
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) {
        return FlightStatusResult.err(tr('al_fetch_fail'));
      }
      final body = jsonDecode(res.body);
      if (body is! Map) {
        return FlightStatusResult.err(tr('al_no_data'));
      }
      // AirLabs returns {error:{...}} when nothing is found.
      if (body['error'] != null) {
        return FlightStatusResult.err(
            tr('al_no_live'));
      }
      final r = (body['response'] as Map?)?.cast<String, dynamic>();
      if (r == null || r.isEmpty) {
        return FlightStatusResult.err(tr('al_no_data'));
      }
      final airline = '${r['airline_iata'] ?? ''}';
      return FlightStatusResult.ok(FlightStatus(
        flightIata: '${r['flight_iata'] ?? code}',
        airlineName: _airlineNames[airline] ??
            (airline.isEmpty ? tr('al_airline') : airline),
        depIata: '${r['dep_iata'] ?? ''}',
        arrIata: '${r['arr_iata'] ?? ''}',
        depTime: '${r['dep_time'] ?? ''}',
        depActual: '${r['dep_actual'] ?? r['dep_estimated'] ?? ''}',
        arrTime: '${r['arr_time'] ?? ''}',
        arrActual: '${r['arr_estimated'] ?? ''}',
        status: '${r['status'] ?? ''}',
        delayedMin: _int(r['delayed']),
        depTerminal: '${r['dep_terminal'] ?? ''}',
        depGate: '${r['dep_gate'] ?? ''}',
      ));
    } catch (_) {
      return FlightStatusResult.err(tr('al_conn_fail'));
    }
  }

  static int _int(dynamic v) =>
      v == null ? 0 : (v is num ? v.toInt() : int.tryParse('$v') ?? 0);
}

class FlightStatusResult {
  final bool success;
  final String message; // always user-facing Arabic
  final FlightStatus? data;
  const FlightStatusResult._(this.success, this.message, this.data);
  factory FlightStatusResult.ok(FlightStatus d) =>
      FlightStatusResult._(true, '', d);
  factory FlightStatusResult.err(String m) =>
      FlightStatusResult._(false, m, null);
}

class FlightStatus {
  final String flightIata;
  final String airlineName;
  final String depIata;
  final String arrIata;
  final String depTime;
  final String depActual;
  final String arrTime;
  final String arrActual;
  final String status;
  final int delayedMin;
  final String depTerminal;
  final String depGate;

  const FlightStatus({
    required this.flightIata,
    required this.airlineName,
    required this.depIata,
    required this.arrIata,
    required this.depTime,
    required this.depActual,
    required this.arrTime,
    required this.arrActual,
    required this.status,
    required this.delayedMin,
    required this.depTerminal,
    required this.depGate,
  });

  /// Arabic label + a color hint for the status chip.
  String get statusAr {
    switch (status.toLowerCase()) {
      case 'scheduled':
        return tr('st_scheduled');
      case 'en-route':
      case 'active':
        return tr('st_enroute');
      case 'landed':
        return tr('st_landed');
      case 'cancelled':
      case 'canceled':
        return tr('st_cancelled');
      case 'incident':
        return tr('st_incident');
      case 'diverted':
        return tr('st_diverted');
      default:
        return status.isEmpty ? tr('st_unknown') : status;
    }
  }

  bool get isDelayed => delayedMin > 0;
}
