import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

/// Real-time flight status via AirLabs (https://airlabs.co).
/// Single-flight lookup by IATA flight number, e.g. "FZ215".
/// Free tier, HTTPS. Booking still happens over WhatsApp — this is an
/// info-only convenience screen. Returns a [FlightStatusResult] that always
/// carries a user-facing Arabic message so the UI never has to guess.
class AirLabsService {
  static const _base = 'https://airlabs.co/api/v9/flight';

  // Common carriers → readable names (Arabic-friendly Latin names).
  static const Map<String, String> _airlineNames = {
    'FZ': 'flydubai', 'EK': 'Emirates', 'TK': 'Turkish Airlines',
    'QR': 'Qatar Airways', 'GF': 'Gulf Air', 'MS': 'EgyptAir',
    'RJ': 'Royal Jordanian', 'ME': 'MEA', 'W6': 'Wizz Air', 'PC': 'Pegasus',
    'VF': 'Pegasus', 'IA': 'Iraqi Airways', 'IF': 'Fly Baghdad',
    'SV': 'Saudia', 'XY': 'flynas', 'J9': 'Jazeera Airways',
    'KU': 'Kuwait Airways', 'WY': 'Oman Air', 'G9': 'Air Arabia',
    'EY': 'Etihad', '6E': 'IndiGo', 'LH': 'Lufthansa', 'BA': 'British Airways',
    'AF': 'Air France',
  };

  static Future<FlightStatusResult> byFlight(String flightIata) async {
    final code =
        flightIata.trim().toUpperCase().replaceAll(RegExp(r'\s+'), '');
    if (code.isEmpty) {
      return FlightStatusResult.err('أدخل رقم الرحلة (مثال: FZ215).');
    }
    if (!AppConfig.airlabsEnabled) {
      return FlightStatusResult.err('ميزة تتبّع الرحلات ستُفعّل قريباً.');
    }
    final uri = Uri.parse(_base).replace(queryParameters: {
      'flight_iata': code,
      'api_key': AppConfig.airlabsApiKey,
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) {
        return FlightStatusResult.err('تعذّر جلب حالة الرحلة، حاول لاحقاً.');
      }
      final body = jsonDecode(res.body);
      if (body is! Map) {
        return FlightStatusResult.err('لا توجد بيانات لهذه الرحلة حالياً.');
      }
      // AirLabs returns {error:{...}} when nothing is found.
      if (body['error'] != null) {
        return FlightStatusResult.err(
            'لا توجد بيانات مباشرة لهذه الرحلة الآن. تأكد من رقم الرحلة أو جرّب قرب موعد الإقلاع.');
      }
      final r = (body['response'] as Map?)?.cast<String, dynamic>();
      if (r == null || r.isEmpty) {
        return FlightStatusResult.err('لا توجد بيانات لهذه الرحلة حالياً.');
      }
      final airline = '${r['airline_iata'] ?? ''}';
      return FlightStatusResult.ok(FlightStatus(
        flightIata: '${r['flight_iata'] ?? code}',
        airlineName: _airlineNames[airline] ??
            (airline.isEmpty ? 'شركة الطيران' : airline),
        depIata: '${r['dep_iata'] ?? ''}',
        arrIata: '${r['arr_iata'] ?? ''}',
        depTime: '${r['dep_time'] ?? ''}',
        depActual: '${r['dep_actual'] ?? r['dep_estimated'] ?? ''}',
        arrTime: '${r['arr_time'] ?? ''}',
        arrActual: '${r['arr_estimated'] ?? ''}',
        status: '${r['status'] ?? ''}',
        delayedMin: _int(r['delayed']),
        depTerminal: '${r['dep_terminal'] ?? ''}',
        depGate: '${r['dep_gate'] ?? ''}',
      ));
    } catch (_) {
      return FlightStatusResult.err('تعذّر الاتصال، تحقّق من الإنترنت.');
    }
  }

  static int _int(dynamic v) =>
      v == null ? 0 : (v is num ? v.toInt() : int.tryParse('$v') ?? 0);
}

class FlightStatusResult {
  final bool success;
  final String message; // always user-facing Arabic
  final FlightStatus? data;
  const FlightStatusResult._(this.success, this.message, this.data);
  factory FlightStatusResult.ok(FlightStatus d) =>
      FlightStatusResult._(true, '', d);
  factory FlightStatusResult.err(String m) =>
      FlightStatusResult._(false, m, null);
}

class FlightStatus {
  final String flightIata;
  final String airlineName;
  final String depIata;
  final String arrIata;
  final String depTime;
  final String depActual;
  final String arrTime;
  final String arrActual;
  final String status;
  final int delayedMin;
  final String depTerminal;
  final String depGate;

  const FlightStatus({
    required this.flightIata,
    required this.airlineName,
    required this.depIata,
    required this.arrIata,
    required this.depTime,
    required this.depActual,
    required this.arrTime,
    required this.arrActual,
    required this.status,
    required this.delayedMin,
    required this.depTerminal,
    required this.depGate,
  });

  /// Arabic label + a color hint for the status chip.
  String get statusAr {
    switch (status.toLowerCase()) {
      case 'scheduled':
        return 'مجدولة';
      case 'en-route':
      case 'active':
        return 'في الجو';
      case 'landed':
        return 'هبطت';
      case 'cancelled':
      case 'canceled':
        return 'ملغاة';
      case 'incident':
        return 'حالة طارئة';
      case 'diverted':
        return 'محوّلة';
      default:
        return status.isEmpty ? 'غير معروف' : status;
    }
  }

  bool get isDelayed => delayedMin > 0;
}
