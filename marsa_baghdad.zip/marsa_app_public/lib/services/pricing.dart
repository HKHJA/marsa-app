import '../config/app_config.dart';

/// Central place that turns a supplier price into the customer-facing price
/// by applying the markup configured in [AppConfig]. Change the numbers there,
/// not here.
class Pricing {
  /// Final flight price = base * (1 + percent) + fixed, rounded up to a clean
  /// whole number so the customer never sees ugly decimals.
  static double flightPrice(double base) {
    final marked =
        base * (1 + AppConfig.flightMarkupPercent / 100) +
            AppConfig.flightMarkupFixed;
    return _roundUp(marked);
  }

  /// Final hotel TOTAL for [nights] given a per-night supplier rate.
  static double hotelTotal(double basePerNight, int nights) {
    final total = basePerNight * nights;
    final marked =
        total * (1 + AppConfig.hotelMarkupPercent / 100) +
            AppConfig.hotelMarkupFixed;
    return _roundUp(marked);
  }

  /// Round up to the nearest whole currency unit.
  static double _roundUp(double v) => v.ceilToDouble();

  static String format(double v) =>
      '${AppConfig.currencySymbol}${v.toStringAsFixed(0)}';
}
