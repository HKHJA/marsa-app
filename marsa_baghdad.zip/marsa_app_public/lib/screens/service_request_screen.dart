import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../models/service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/form_fields.dart';

class ServiceRequestScreen extends StatefulWidget {
  final ServiceItem service;
  const ServiceRequestScreen({super.key, required this.service});

  @override
  State<ServiceRequestScreen> createState() => _ServiceRequestScreenState();
}

class _ServiceRequestScreenState extends State<ServiceRequestScreen> {
  late String? choice;
  final _details = TextEditingController();

  @override
  void initState() {
    super.initState();
    choice = widget.service.fieldOptions?.first;
  }

  @override
  void dispose() {
    _details.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.service;
    return Scaffold(
      appBar: AppBar(title: Text('${s.emoji} ${s.titleAr}')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (s.hint != null)
            Container(
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.only(bottom: 18),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E6),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(s.hint!,
                  style: const TextStyle(
                      color: Color(0xFF8A6D1F), fontSize: 13, height: 1.6)),
            ),
          if (s.fieldOptions != null) ...[
            dropdownField(
              s.fieldLabel ?? 'اختر',
              choice!,
              s.fieldOptions!
                  .map((o) => DropdownMenuItem(value: o, child: Text(o)))
                  .toList(),
              (v) => setState(() => choice = v),
            ),
            const SizedBox(height: 16),
          ],
          fieldShell(
            'تفاصيل إضافية (اختياري)',
            TextField(
              controller: _details,
              maxLines: 4,
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: 'اكتب أي تفاصيل تساعدنا في خدمتك...',
              ),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF25D366),
              minimumSize: const Size.fromHeight(52),
            ),
            icon: const Icon(Icons.chat),
            label: const Text('إرسال الطلب عبر واتساب',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            onPressed: () => WhatsAppService.requestService(
              s,
              choice: s.fieldOptions != null ? choice : null,
              details: _details.text,
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text('سيتواصل معك فريق ${AppConfig.appNameAr} بأفضل عرض',
                style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}
