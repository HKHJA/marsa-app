import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../models/service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/form_fields.dart';

class ServiceRequestScreen extends StatefulWidget {
  final ServiceItem service;
  const ServiceRequestScreen({super.key, required this.service});

  @override
  State<ServiceRequestScreen> createState() => _ServiceRequestScreenState();
}

class _ServiceRequestScreenState extends State<ServiceRequestScreen> {
  late String? choice;
  final _details = TextEditingController();

  @override
  void initState() {
    super.initState();
    choice = widget.service.fieldOptions?.first;
  }

  @override
  void dispose() {
    _details.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.service;
    return Scaffold(
      appBar: AppBar(title: Text('${s.emoji} ${s.title}')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          if (s.hint != null)
            Container(
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.only(bottom: 18),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E6),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(s.hintTr!,
                  style: const TextStyle(
                      color: Color(0xFF8A6D1F), fontSize: 13, height: 1.6)),
            ),
          if (s.fieldOptions != null) ...[
            dropdownField(
              s.fieldLabelTr,
              choice!,
              s.fieldOptions!
                  .map((o) => DropdownMenuItem(value: o, child: Text(coName(o))))
                  .toList(),
              (v) => setState(() => choice = v),
            ),
            const SizedBox(height: 16),
          ],
          fieldShell(
            tr('sr_details_label'),
            TextField(
              controller: _details,
              maxLines: 4,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: tr('sr_details_hint'),
              ),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF25D366),
              minimumSize: const Size.fromHeight(52),
            ),
            icon: const Icon(Icons.chat),
            label: Text(tr('sr_send'),
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            onPressed: () => WhatsAppService.requestService(
              s,
              choice: s.fieldOptions != null ? choice : null,
              details: _details.text,
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(tr('sr_followup'),
                style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}
