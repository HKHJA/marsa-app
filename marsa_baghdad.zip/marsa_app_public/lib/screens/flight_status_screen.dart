import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../services/airlabs_service.dart';
import '../widgets/form_fields.dart';

/// "حالة الرحلة" — customer types a flight number (e.g. FZ215) and sees its
/// live status. Info-only; booking/enquiries still go through WhatsApp.
class FlightStatusScreen extends StatefulWidget {
  const FlightStatusScreen({super.key});
  @override
  State<FlightStatusScreen> createState() => _FlightStatusScreenState();
}

class _FlightStatusScreenState extends State<FlightStatusScreen> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  FlightStatusResult? _result;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _track() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _loading = true;
      _result = null;
    });
    final r = await AirLabsService.byFlight(_ctrl.text);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _result = r;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حالة الرحلة')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          fieldShell(
            'رقم الرحلة',
            TextField(
              controller: _ctrl,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: 'مثال: FZ215',
              ),
              onSubmitted: (_) => _track(),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'أدخل رمز شركة الطيران ورقم الرحلة معاً بدون مسافة.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.radar),
            label: const Text('تتبّع الرحلة',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            onPressed: _loading ? null : _track,
          ),
          const SizedBox(height: 24),
          if (_result != null && !_result!.success)
            _message(_result!.message),
          if (_result != null && _result!.success)
            _StatusCard(data: _result!.data!),
        ],
      ),
    );
  }

  Widget _message(String text) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3D6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE0A82E)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Color(0xFF7A5C12)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(text,
                style: const TextStyle(
                    color: Color(0xFF7A5C12), height: 1.5)),
          ),
        ],
      ),
    );
  }
}

class _StatusCard extends StatelessWidget {
  final FlightStatus data;
  const _StatusCard({required this.data});

  Color get _statusColor {
    switch (data.status.toLowerCase()) {
      case 'landed':
        return const Color(0xFF2E7D32);
      case 'en-route':
      case 'active':
        return AppConfig.brandPrimary;
      case 'cancelled':
      case 'canceled':
      case 'incident':
        return const Color(0xFFC62828);
      default:
        return const Color(0xFF7A5C12);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppConfig.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(data.flightIata,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w800)),
                  Text(data.airlineName,
                      style: const TextStyle(color: Colors.black54)),
                ],
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(data.statusAr,
                    style: TextStyle(
                        color: _statusColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 13)),
              ),
            ],
          ),
          const Divider(height: 26),
          Row(
            children: [
              Expanded(
                  child: _endpoint(
                      'المغادرة', data.depIata, data.depTime,
                      data.depActual, data.depTerminal, data.depGate)),
              const Icon(Icons.flight_takeoff,
                  color: AppConfig.brandPrimary),
              Expanded(
                  child: _endpoint('الوصول', data.arrIata, data.arrTime,
                      data.arrActual, '', '')),
            ],
          ),
          if (data.isDelayed) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFFDECEA),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.schedule,
                      color: Color(0xFFC62828), size: 18),
                  const SizedBox(width: 8),
                  Text('تأخير حوالي ${data.delayedMin} دقيقة',
                      style: const TextStyle(
                          color: Color(0xFFC62828),
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          const Text(
            'المعلومات إرشادية ومصدرها بيانات الطيران المباشرة. للتأكيد النهائي راجع شركة الطيران أو المطار.',
            style: TextStyle(fontSize: 11, color: Colors.grey, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _endpoint(String label, String iata, String sched, String actual,
      String terminal, String gate) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        const SizedBox(height: 4),
        Text(iata.isEmpty ? '—' : iata,
            style:
                const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        if (sched.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(_time(sched),
              style: const TextStyle(fontSize: 12, color: Colors.black87)),
        ],
        if (actual.isNotEmpty && actual != sched)
          Text('الفعلي ${_time(actual)}',
              style: const TextStyle(
                  fontSize: 11, color: AppConfig.brandDark)),
        if (terminal.isNotEmpty)
          Text('صالة $terminal${gate.isNotEmpty ? ' • بوابة $gate' : ''}',
              style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ],
    );
  }

  // AirLabs times look like "2026-08-15 10:30" — show just HH:mm when possible.
  String _time(String s) {
    final parts = s.split(' ');
    return parts.length > 1 ? parts[1] : s;
  }
}
