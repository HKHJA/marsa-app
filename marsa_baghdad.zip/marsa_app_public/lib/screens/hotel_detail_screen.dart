import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../models/hotel_offer.dart';
import '../services/whatsapp_service.dart';
import '../widgets/brand.dart';
import '../widgets/money.dart';

/// Rich hotel detail page shown before the WhatsApp booking: photo gallery,
/// amenities, a map link and a price breakdown.
class HotelDetailScreen extends StatelessWidget {
  final HotelOffer offer;
  const HotelDetailScreen({super.key, required this.offer});

  static const _amenities = [
    ('am_wifi', Icons.wifi),
    ('am_breakfast', Icons.free_breakfast),
    ('am_ac', Icons.ac_unit),
    ('am_pool', Icons.pool),
    ('am_parking', Icons.local_parking),
    ('am_reception', Icons.room_service),
  ];

  Future<void> _openMap() async {
    final q = Uri.encodeComponent('${offer.name} ${offer.city}');
    final uri =
        Uri.parse('https://www.google.com/maps/search/?api=1&query=$q');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final imgs = <String?>[
      if (offer.thumbnail != null && offer.thumbnail!.isNotEmpty)
        offer.thumbnail,
      'assets/tiles/hotels.jpg',
    ];
    return Scaffold(
      backgroundColor: AppConfig.bg,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            backgroundColor: AppConfig.navy,
            flexibleSpace: FlexibleSpaceBar(
              background: _Gallery(images: imgs, rating: offer.rating),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(offer.name,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      RatingStars(rating: offer.rating),
                      const SizedBox(width: 8),
                      Text(offer.rating.toStringAsFixed(1),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppConfig.inkMuted)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  InkWell(
                    onTap: _openMap,
                    child: Row(
                      children: [
                        const Icon(Icons.place,
                            size: 16, color: AppConfig.brandPrimary),
                        const SizedBox(width: 4),
                        Text('${offer.city} • ${tr('hd_map')}',
                            style: const TextStyle(
                                color: AppConfig.brandPrimary,
                                fontWeight: FontWeight.w600,
                                fontSize: 13)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(tr('hd_amenities'),
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final a in _amenities) _chip(a.$1, a.$2),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Text(tr('hd_about'),
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(tr('hd_about_body'),
                      style: const TextStyle(
                          color: AppConfig.inkMuted, height: 1.7, fontSize: 13.5)),
                  const SizedBox(height: 18),
                  _priceBox(),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomSheet: _bookingBar(context),
    );
  }

  Widget _chip(String key, IconData icon) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppConfig.tintCyan,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: AppConfig.brandAccent),
            const SizedBox(width: 6),
            Text(tr(key),
                style: const TextStyle(
                    fontSize: 12.5,
                    color: AppConfig.brandAccent,
                    fontWeight: FontWeight.w600)),
          ],
        ),
      );

  Widget _priceBox() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppConfig.line),
        ),
        child: Column(
          children: [
            _row('${Money.fmt(offer.finalPerNight)} · ${tr('per_night')}',
                '${offer.nights} ${tr('nights_word')}'),
            const Divider(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(tr('total'),
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 15)),
                Text(Money.fmt(offer.finalTotal),
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 20,
                        color: AppConfig.navy)),
              ],
            ),
          ],
        ),
      );

  Widget _row(String a, String b) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(a, style: const TextStyle(color: AppConfig.inkMuted)),
          Text(b, style: const TextStyle(color: AppConfig.inkMuted)),
        ],
      );

  Widget _bookingBar(BuildContext context) => Container(
        color: AppConfig.surface,
        padding: EdgeInsets.fromLTRB(
            16, 10, 16, 10 + MediaQuery.of(context).padding.bottom),
        child: Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF25D366),
                  minimumSize: const Size.fromHeight(50),
                ),
                icon: const Icon(Icons.chat),
                label: Text(tr('book_whatsapp_full'),
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15)),
                onPressed: () => WhatsAppService.bookHotel(offer),
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              style: IconButton.styleFrom(
                backgroundColor: AppConfig.tintCyan,
                minimumSize: const Size(50, 50),
              ),
              icon: const Icon(Icons.share, color: AppConfig.brandPrimary),
              onPressed: () => Share.share(
                '${offer.name} — ${offer.city}\n'
                '${offer.nights} ليالٍ: ${Money.fmt(offer.finalTotal)}\n'
                'عبر ${AppConfig.appNameAr} — للحجز واتساب: '
                'https://wa.me/${AppConfig.whatsappNumber}',
              ),
            ),
          ],
        ),
      );
}

class _Gallery extends StatefulWidget {
  final List<String?> images;
  final double rating;
  const _Gallery({required this.images, required this.rating});
  @override
  State<_Gallery> createState() => _GalleryState();
}

class _GalleryState extends State<_Gallery> {
  int _i = 0;
  final _c = PageController();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        PageView.builder(
          controller: _c,
          itemCount: widget.images.length,
          onPageChanged: (i) => setState(() => _i = i),
          itemBuilder: (context, i) {
            final src = widget.images[i];
            if (src != null && src.startsWith('http')) {
              return Image.network(src,
                  fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback());
            }
            if (src != null) {
              return Image.asset(src,
                  fit: BoxFit.cover, errorBuilder: (_, __, ___) => _fallback());
            }
            return _fallback();
          },
        ),
        // gradient scrim for legibility
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.transparent, Colors.black26],
            ),
          ),
        ),
        if (widget.images.length > 1)
          Positioned(
            bottom: 10,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                widget.images.length,
                (i) => AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: _i == i ? 18 : 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: _i == i ? Colors.white : Colors.white70,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _fallback() => Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppConfig.navy, AppConfig.brandPrimary],
          ),
        ),
        child: Center(
          child: Icon(Icons.apartment,
              color: Colors.white.withOpacity(0.85), size: 54),
        ),
      );
}
