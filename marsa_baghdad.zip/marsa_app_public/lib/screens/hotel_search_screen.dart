import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../widgets/search_ui.dart';
import 'hotel_results_screen.dart';

class HotelSearchScreen extends StatefulWidget {
  const HotelSearchScreen({super.key});
  @override
  State<HotelSearchScreen> createState() => _HotelSearchScreenState();
}

class _HotelSearchScreenState extends State<HotelSearchScreen> {
  String city = 'DXB';
  DateTime checkIn = DateTime.now().add(const Duration(days: 5));
  int nights = 3;
  int guests = 2;

  String _label(String code) {
    final c = AppConfig.hotelCities.firstWhere((x) => x['code'] == code,
        orElse: () => {'code': code, 'city': code, 'ar': code});
    final name = L10n.locale.value == 'en' ? c['city'] : c['ar'];
    return '$name ($code)';
  }

  void _pickCity() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppConfig.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.symmetric(vertical: 8),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
              child: Text(tr('h_city'),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            for (final c in AppConfig.hotelCities)
              ListTile(
                leading:
                    const Icon(Icons.location_city, color: AppConfig.brandPrimary),
                title: Text(
                    '${L10n.locale.value == 'en' ? c['city'] : c['ar']} (${c['code']})'),
                onTap: () {
                  setState(() => city = c['code']!);
                  Navigator.pop(context);
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickCheckIn() async {
    final picked = await pickDate(context, checkIn);
    if (picked != null) setState(() => checkIn = picked);
  }

  @override
  Widget build(BuildContext context) {
    return SearchHero(
      title: tr('hs_title'),
      subtitle: tr('hs_hero_sub'),
      icon: Icons.hotel,
      children: [
        LocationCard(
          label: tr('h_city'),
          value: _label(city),
          icon: Icons.location_city,
          onTap: _pickCity,
        ),
        const SizedBox(height: 12),
        PillField(
          label: tr('h_checkin'),
          value: shortDate(checkIn),
          icon: Icons.calendar_today,
          onTap: _pickCheckIn,
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: PillField(
                label: tr('h_nights'),
                value: '',
                icon: Icons.nightlight_round,
                trailing: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('$nights',
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w700)),
                    MiniStepper(
                      value: nights,
                      onChanged: (v) => setState(() => nights = v),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: PillField(
                label: tr('h_guests'),
                value: '',
                icon: Icons.people,
                trailing: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('$guests',
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w700)),
                    MiniStepper(
                      value: guests,
                      onChanged: (v) => setState(() => guests = v),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        GradientButton(
          label: tr('h_search_hotels'),
          icon: Icons.search,
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => HotelResultsScreen(
                city: city,
                checkIn: checkIn,
                nights: nights,
                guests: guests,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
