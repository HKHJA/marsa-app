import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../widgets/form_fields.dart';
import 'hotel_results_screen.dart';

class HotelSearchScreen extends StatefulWidget {
  const HotelSearchScreen({super.key});
  @override
  State<HotelSearchScreen> createState() => _HotelSearchScreenState();
}

class _HotelSearchScreenState extends State<HotelSearchScreen> {
  String city = 'DXB';
  DateTime checkIn = DateTime.now().add(const Duration(days: 5));
  int nights = 3;
  int guests = 2;

  @override
  Widget build(BuildContext context) {
    final cityItems = AppConfig.hotelCities
        .map((c) => DropdownMenuItem(
              value: c['code'],
              child: Text('${L10n.locale.value == 'en' ? c['city'] : c['ar']} (${c['code']})'),
            ))
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(tr('hs_title'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          dropdownField(tr('h_city'), city, cityItems,
              (v) => setState(() => city = v)),
          const SizedBox(height: 14),
          dateField(tr('h_checkin'), checkIn, (d) => setState(() => checkIn = d)),
          const SizedBox(height: 14),
          counterField(tr('h_nights'), nights, (v) => setState(() => nights = v),
              min: 1),
          const SizedBox(height: 14),
          counterField(tr('h_guests'), guests, (v) => setState(() => guests = v)),
          const SizedBox(height: 24),
          searchButton(
            tr('h_search_hotels'),
            () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HotelResultsScreen(
                  city: city,
                  checkIn: checkIn,
                  nights: nights,
                  guests: guests,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
