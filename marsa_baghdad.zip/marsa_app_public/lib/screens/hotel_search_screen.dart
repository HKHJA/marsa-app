import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../widgets/form_fields.dart';
import 'hotel_results_screen.dart';

class HotelSearchScreen extends StatefulWidget {
  const HotelSearchScreen({super.key});
  @override
  State<HotelSearchScreen> createState() => _HotelSearchScreenState();
}

class _HotelSearchScreenState extends State<HotelSearchScreen> {
  String city = 'DXB';
  DateTime checkIn = DateTime.now().add(const Duration(days: 5));
  int nights = 3;
  int guests = 2;

  @override
  Widget build(BuildContext context) {
    final cityItems = AppConfig.hotelCities
        .map((c) => DropdownMenuItem(
              value: c['code'],
              child: Text('${c['ar']} (${c['code']})'),
            ))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('حجز فنادق')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          dropdownField('المدينة', city, cityItems,
              (v) => setState(() => city = v)),
          const SizedBox(height: 14),
          dateField('تاريخ الوصول', checkIn, (d) => setState(() => checkIn = d)),
          const SizedBox(height: 14),
          counterField('عدد الليالي', nights, (v) => setState(() => nights = v),
              min: 1),
          const SizedBox(height: 14),
          counterField('عدد الضيوف', guests, (v) => setState(() => guests = v)),
          const SizedBox(height: 24),
          searchButton(
            'ابحث عن الفنادق',
            () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => HotelResultsScreen(
                  city: city,
                  checkIn: checkIn,
                  nights: nights,
                  guests: guests,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
