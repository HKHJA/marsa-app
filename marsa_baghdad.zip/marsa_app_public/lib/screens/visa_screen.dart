import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../config/app_config.dart';
import '../config/services_catalog.dart';
import '../config/visa_requirements.dart';
import '../l10n/l10n.dart';
import '../models/service.dart';
import '../services/supabase_service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/search_ui.dart';

/// Upgraded visa flow: pick a country, see the exact documents required,
/// tick what you have, attach passport/photo images, and send it all to the
/// agency on WhatsApp. Logged to My Trips for tracking.
class VisaScreen extends StatefulWidget {
  final ServiceItem service;
  const VisaScreen({super.key, required this.service});

  @override
  State<VisaScreen> createState() => _VisaScreenState();
}

class _VisaScreenState extends State<VisaScreen> {
  late String country;
  final Set<String> _ready = {};
  final List<XFile> _photos = [];
  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    country = ServicesCatalog.visaCountries.first;
  }

  List<String> get _reqs => VisaRequirements.forCountry(country);

  Future<void> _pick() async {
    try {
      final imgs = await _picker.pickMultiImage(imageQuality: 70);
      if (imgs.isNotEmpty) setState(() => _photos.addAll(imgs));
    } catch (_) {}
  }

  Future<void> _submit() async {
    final b = StringBuffer();
    b.writeln('مرحبًا ${AppConfig.appNameAr} 👋');
    b.writeln('أرغب بتقديم طلب تأشيرة (فيزا):');
    b.writeln('🌍 الدولة: $country');
    if (_ready.isNotEmpty) {
      b.writeln('\nالمستندات الجاهزة لديّ:');
      for (final r in _reqs.where(_ready.contains)) {
        b.writeln('✅ ${tr(r)}');
      }
    }
    if (_photos.isNotEmpty) {
      b.writeln('\n📎 مرفق ${_photos.length} صورة مستند.');
    }
    b.writeln('\nالرجاء إبلاغي بالأوراق المتبقية والرسوم ومدة الإنجاز. شكرًا.');
    final msg = b.toString();

    await WhatsAppService.logVisa(country, _photos.length);

    if (_photos.isNotEmpty) {
      // Share the document photos + message so the customer can send them to
      // the agency's WhatsApp in one step.
      await Share.shareXFiles(_photos, text: msg);
    } else {
      final uri = Uri.parse(
          'https://wa.me/${SupabaseCatalog.whatsapp}?text=${Uri.encodeComponent(msg)}');
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
    if (mounted) Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.service;
    final countryItems = ServicesCatalog.visaCountries
        .map((c) => DropdownMenuItem(value: c, child: Text(coName(c))))
        .toList();
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text('${s.emoji} ${s.title}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Country
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr('fl_country'),
                    style: const TextStyle(
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                        color: AppConfig.inkMuted)),
                const SizedBox(height: 4),
                DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: country,
                    items: countryItems,
                    onChanged: (v) => setState(() {
                      country = v ?? country;
                      _ready.clear();
                    }),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Requirements checklist
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tr('visa_req_title'),
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: AppConfig.ink)),
                const SizedBox(height: 4),
                Text(tr('visa_req_hint'),
                    style: const TextStyle(
                        fontSize: 12, color: AppConfig.inkMuted, height: 1.5)),
                const SizedBox(height: 8),
                for (final r in _reqs)
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    controlAffinity: ListTileControlAffinity.leading,
                    activeColor: AppConfig.brandPrimary,
                    value: _ready.contains(r),
                    onChanged: (v) => setState(() {
                      if (v == true) {
                        _ready.add(r);
                      } else {
                        _ready.remove(r);
                      }
                    }),
                    title: Text(tr(r),
                        style: const TextStyle(
                            fontSize: 14, color: AppConfig.ink)),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // Attach photos
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.attach_file,
                        size: 18, color: AppConfig.brandPrimary),
                    const SizedBox(width: 6),
                    Text(tr('visa_attach'),
                        style: const TextStyle(
                            fontSize: 14, fontWeight: FontWeight.w700)),
                    const Spacer(),
                    if (_photos.isNotEmpty)
                      Text('${_photos.length} ${tr('visa_attached')}',
                          style: const TextStyle(
                              fontSize: 12, color: AppConfig.brandAccent)),
                  ],
                ),
                if (_photos.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 76,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _photos.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (context, i) => Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Image.file(File(_photos[i].path),
                                width: 76, height: 76, fit: BoxFit.cover),
                          ),
                          Positioned(
                            top: 2,
                            right: 2,
                            child: GestureDetector(
                              onTap: () =>
                                  setState(() => _photos.removeAt(i)),
                              child: Container(
                                decoration: const BoxDecoration(
                                    color: Colors.black54,
                                    shape: BoxShape.circle),
                                child: const Icon(Icons.close,
                                    size: 16, color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppConfig.brandPrimary,
                    side: const BorderSide(color: AppConfig.brandPrimary),
                    minimumSize: const Size.fromHeight(44),
                  ),
                  icon: const Icon(Icons.add_photo_alternate_outlined),
                  label: Text(tr('visa_attach'),
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  onPressed: _pick,
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(tr('visa_note'),
                style: const TextStyle(
                    fontSize: 11.5, color: AppConfig.inkMuted, height: 1.5)),
          ),
          const SizedBox(height: 16),
          GradientButton(
            label: tr('visa_send'),
            icon: Icons.send,
            onPressed: _submit,
          ),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppConfig.line),
        ),
        child: child,
      );
}
