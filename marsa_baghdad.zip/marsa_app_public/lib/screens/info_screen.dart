import 'package:flutter/material.dart';
import '../config/app_config.dart';

/// Simple content page used for About / Terms / Privacy.
class InfoScreen extends StatelessWidget {
  final String title;
  final String body;
  const InfoScreen({super.key, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(body,
              style: const TextStyle(
                  fontSize: 15, height: 2.0, color: AppConfig.ink)),
        ],
      ),
    );
  }
}
