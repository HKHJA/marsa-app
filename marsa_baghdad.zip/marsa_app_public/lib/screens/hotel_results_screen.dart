import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../config/app_config.dart';
import '../models/hotel_offer.dart';
import '../services/travel_service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/brand.dart';
import '../widgets/money.dart';

class HotelResultsScreen extends StatefulWidget {
  final String city;
  final DateTime checkIn;
  final int nights;
  final int guests;
  const HotelResultsScreen({
    super.key,
    required this.city,
    required this.checkIn,
    required this.nights,
    required this.guests,
  });

  @override
  State<HotelResultsScreen> createState() => _HotelResultsScreenState();
}

class _HotelResultsScreenState extends State<HotelResultsScreen> {
  late Future<List<HotelOffer>> _future;

  @override
  void initState() {
    super.initState();
    _future = TravelService.searchHotels(
      cityCode: widget.city,
      checkIn: widget.checkIn,
      nights: widget.nights,
      adults: widget.guests,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('فنادق ${widget.city}')),
      body: FutureBuilder<List<HotelOffer>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Text('تعذّر جلب الأسعار\n${snap.error}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.grey)),
              ),
            );
          }
          final offers = snap.data ?? [];
          if (offers.isEmpty) {
            return const Center(child: Text('لا توجد فنادق متاحة'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: offers.length,
            itemBuilder: (context, i) => _HotelCard(offer: offers[i]),
          );
        },
      ),
    );
  }
}

class _HotelCard extends StatelessWidget {
  final HotelOffer offer;
  const _HotelCard({required this.offer});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 0,
      color: AppConfig.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppConfig.line),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 54,
                  height: 54,
                  decoration: BoxDecoration(
                    color: AppConfig.brandPrimary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.apartment,
                      color: AppConfig.brandPrimary),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(offer.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 15)),
                      const SizedBox(height: 4),
                      RatingStars(rating: offer.rating),
                      const SizedBox(height: 2),
                      Text(offer.board,
                          style: const TextStyle(
                              fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${offer.nights} ليالٍ',
                    style: const TextStyle(color: Colors.grey)),
                PriceTag(
                  price: Money.fmt(offer.finalTotal),
                  note: 'الإجمالي',
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF25D366),
                      minimumSize: const Size.fromHeight(46),
                    ),
                    icon: const Icon(Icons.chat),
                    label: const Text('احجز عبر واتساب',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    onPressed: () => WhatsAppService.bookHotel(offer),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  style: IconButton.styleFrom(
                    backgroundColor: AppConfig.tintCyan,
                    minimumSize: const Size(46, 46),
                  ),
                  icon: const Icon(Icons.share, color: AppConfig.brandPrimary),
                  onPressed: () => Share.share(
                    '${offer.name} — ${offer.city}\n'
                    '${offer.nights} ليالٍ: ${Money.fmt(offer.finalTotal)}\n'
                    'عبر ${AppConfig.appNameAr} — للحجز واتساب: '
                    'https://wa.me/${AppConfig.whatsappNumber}',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
