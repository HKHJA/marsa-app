import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../models/hotel_offer.dart';
import '../services/travel_service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/brand.dart';
import '../widgets/money.dart';
import '../widgets/search_ui.dart';
import 'hotel_detail_screen.dart';

class HotelResultsScreen extends StatefulWidget {
  final String city;
  final DateTime checkIn;
  final int nights;
  final int guests;
  const HotelResultsScreen({
    super.key,
    required this.city,
    required this.checkIn,
    required this.nights,
    required this.guests,
  });

  @override
  State<HotelResultsScreen> createState() => _HotelResultsScreenState();
}

class _HotelResultsScreenState extends State<HotelResultsScreen> {
  late Future<List<HotelOffer>> _future;
  int _sort = 0; // 0 cheapest, 1 top rated

  @override
  void initState() {
    super.initState();
    _future = TravelService.searchHotels(
      cityCode: widget.city,
      checkIn: widget.checkIn,
      nights: widget.nights,
      adults: widget.guests,
    );
  }

  List<HotelOffer> _sorted(List<HotelOffer> offers) {
    final list = [...offers];
    if (_sort == 1) {
      list.sort((a, b) => b.rating.compareTo(a.rating));
    } else {
      list.sort((a, b) => a.finalTotal.compareTo(b.finalTotal));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${tr('h_hotels_in')} ${widget.city}',
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text('${widget.nights} ${tr('nights_word')} • ${widget.guests}',
                style: const TextStyle(fontSize: 11.5, color: Colors.white70)),
          ],
        ),
      ),
      body: FutureBuilder<List<HotelOffer>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Padding(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Text('${tr('fetch_fail')}\n${snap.error}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.grey)),
              ),
            );
          }
          final offers = _sorted(snap.data ?? []);
          if (offers.isEmpty) {
            return Center(child: Text(tr('h_none')));
          }
          return Column(
            children: [
              const SizedBox(height: 12),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16, right: 4),
                    child: Text('${offers.length} ${tr('results_count')}',
                        style: const TextStyle(
                            color: AppConfig.inkMuted,
                            fontWeight: FontWeight.w600,
                            fontSize: 12.5)),
                  ),
                  Expanded(
                    child: SortPills(
                      labels: [tr('sort_cheapest'), tr('sort_toprated')],
                      selected: _sort,
                      onChanged: (i) => setState(() => _sort = i),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
                  itemCount: offers.length,
                  itemBuilder: (context, i) => _HotelCard(offer: offers[i]),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _HotelCard extends StatelessWidget {
  final HotelOffer offer;
  const _HotelCard({required this.offer});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => HotelDetailScreen(offer: offer)),
      ),
      child: Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppConfig.line),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Banner: hotel photo if available, else a gradient with an icon.
          SizedBox(
            height: 120,
            width: double.infinity,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (offer.thumbnail != null && offer.thumbnail!.isNotEmpty)
                  Image.network(offer.thumbnail!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const _Banner())
                else
                  const _Banner(),
                // Rating chip
                Positioned(
                  top: 10,
                  right: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 9, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.55),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.star,
                            color: Color(0xFFFFC107), size: 14),
                        const SizedBox(width: 3),
                        Text(offer.rating.toStringAsFixed(1),
                            style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(offer.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 4),
                RatingStars(rating: offer.rating),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.restaurant,
                        size: 13, color: AppConfig.inkMuted),
                    const SizedBox(width: 4),
                    Text(offer.board,
                        style: const TextStyle(
                            fontSize: 12, color: AppConfig.inkMuted)),
                  ],
                ),
                const Divider(height: 22),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            '${Money.fmt(offer.finalPerNight)} · ${tr('per_night')}',
                            style: const TextStyle(
                                fontSize: 11.5, color: AppConfig.inkMuted)),
                        const SizedBox(height: 2),
                        Text('${offer.nights} ${tr('nights_word')}',
                            style: const TextStyle(
                                fontSize: 12, color: Colors.grey)),
                      ],
                    ),
                    PriceTag(
                      price: Money.fmt(offer.finalTotal),
                      note: tr('total'),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          minimumSize: const Size.fromHeight(46),
                        ),
                        icon: const Icon(Icons.chat),
                        label: Text(tr('book_whatsapp_full'),
                            style:
                                const TextStyle(fontWeight: FontWeight.bold)),
                        onPressed: () => WhatsAppService.bookHotel(offer),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      style: IconButton.styleFrom(
                        backgroundColor: AppConfig.tintCyan,
                        minimumSize: const Size(46, 46),
                      ),
                      icon: const Icon(Icons.share,
                          color: AppConfig.brandPrimary),
                      onPressed: () => Share.share(
                        '${offer.name} — ${offer.city}\n'
                        '${offer.nights} ليالٍ: ${Money.fmt(offer.finalTotal)}\n'
                        'عبر ${AppConfig.appNameAr} — للحجز واتساب: '
                        'https://wa.me/${AppConfig.whatsappNumber}',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      ),
    );
  }
}

/// Gradient placeholder banner used when a hotel has no photo.
class _Banner extends StatelessWidget {
  const _Banner();
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppConfig.navy, AppConfig.brandPrimary],
        ),
      ),
      child: Center(
        child: Icon(Icons.apartment,
            color: Colors.white.withOpacity(0.85), size: 46),
      ),
    );
  }
}
