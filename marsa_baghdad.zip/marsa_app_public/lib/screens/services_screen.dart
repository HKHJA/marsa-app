import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../config/services_catalog.dart';
import '../models/service.dart';
import '../services/supabase_service.dart';
import '../widgets/money.dart';
import 'flight_search_screen.dart';
import 'flight_status_screen.dart';
import 'hotel_search_screen.dart';
import 'service_request_screen.dart';

/// All services as a clean list (the "خدمات" tile + drawer entry).
class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});

  void _open(BuildContext context, ServiceItem s) {
    Widget page;
    switch (s.type) {
      case 'flights':
        page = const FlightSearchScreen();
        break;
      case 'hotels':
        page = const HotelSearchScreen();
        break;
      case 'flightstatus':
        page = const FlightStatusScreen();
        break;
      default:
        page = ServiceRequestScreen(service: s);
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final items = ServicesCatalog.items
        .where((s) => SupabaseCatalog.serviceEnabled(s.id))
        .toList();
    return Scaffold(
      appBar: AppBar(title: Text(tr('our_services'))),
      body: ValueListenableBuilder<bool>(
        valueListenable: Money.useIqd,
        builder: (context, _, __) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, i) {
            final s = items[i];
            final price = SupabaseCatalog.servicePrice(s.id);
            final note = price == null
                ? s.sub
                : '${tr('starts_from')} ${Money.fmt(double.tryParse(price) ?? 0)}';
            return InkWell(
              onTap: () => _open(context, s),
              borderRadius: BorderRadius.circular(14),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppConfig.surface,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppConfig.line),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppConfig.tintCyan,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(s.emoji,
                          style: const TextStyle(fontSize: 24)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(s.title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15,
                                      color: AppConfig.ink)),
                              if (s.badge != null) ...[
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: AppConfig.tintCyan,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(s.badgeTr!,
                                      style: const TextStyle(
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                          color: AppConfig.navy)),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text(note,
                              style: TextStyle(
                                  fontSize: 12.5,
                                  color: price != null
                                      ? AppConfig.brandAccent
                                      : AppConfig.inkMuted,
                                  fontWeight: price != null
                                      ? FontWeight.w700
                                      : FontWeight.w400)),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_left, color: AppConfig.inkMuted),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
