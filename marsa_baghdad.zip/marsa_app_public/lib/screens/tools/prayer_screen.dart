import 'package:flutter/material.dart';
import '../../config/app_config.dart';
import '../../config/tool_cities.dart';
import '../../l10n/l10n.dart';
import '../../services/tools_api.dart';

class PrayerScreen extends StatefulWidget {
  const PrayerScreen({super.key});
  @override
  State<PrayerScreen> createState() => _PrayerScreenState();
}

class _PrayerScreenState extends State<PrayerScreen> {
  ToolCity city = ToolCities.all.first;
  int method = 3;
  Map<String, String>? _times;
  bool _loading = true;
  String? _error;

  static const _methods = [
    (3, 'pm_mwl'),
    (4, 'pm_makkah'),
    (5, 'pm_egypt'),
    (0, 'pm_jafari'),
  ];

  static const _order = [
    ('Fajr', 'pr_fajr', Icons.nightlight_round),
    ('Sunrise', 'pr_sunrise', Icons.wb_twilight),
    ('Dhuhr', 'pr_dhuhr', Icons.wb_sunny),
    ('Asr', 'pr_asr', Icons.wb_sunny_outlined),
    ('Maghrib', 'pr_maghrib', Icons.wb_twilight),
    ('Isha', 'pr_isha', Icons.dark_mode),
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final t = await ToolsApi.prayerTimes(city.en, city.country,
          method: method);
      setState(() {
        _times = t;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _error = tr('fetch_fail');
        _loading = false;
      });
    }
  }

  String _cityName(ToolCity c) => L10n.locale.value == 'en' ? c.en : c.ar;

  @override
  Widget build(BuildContext context) {
    final qibla = ToolsApi.qiblaBearing(city.lat, city.lon);
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_prayer'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                flex: 3,
                child: _box(
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      isExpanded: true,
                      value: ToolCities.all.indexOf(city),
                      items: [
                        for (var i = 0; i < ToolCities.all.length; i++)
                          DropdownMenuItem(
                              value: i,
                              child: Text(_cityName(ToolCities.all[i]))),
                      ],
                      onChanged: (v) {
                        if (v != null) {
                          setState(() => city = ToolCities.all[v]);
                          _load();
                        }
                      },
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: _box(
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      isExpanded: true,
                      value: method,
                      items: [
                        for (final m in _methods)
                          DropdownMenuItem(
                              value: m.$1, child: Text(tr(m.$2))),
                      ],
                      onChanged: (v) {
                        if (v != null) {
                          setState(() => method = v);
                          _load();
                        }
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          // Qibla
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppConfig.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppConfig.line),
            ),
            child: Row(
              children: [
                Transform.rotate(
                  angle: qibla * 3.1415926535 / 180,
                  child: const Icon(Icons.navigation,
                      color: AppConfig.brandPrimary, size: 40),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('pr_qibla'),
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 15)),
                      const SizedBox(height: 2),
                      Text('${qibla.round()}° ${tr('pr_from_north')}',
                          style: const TextStyle(
                              color: AppConfig.inkMuted, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          if (_loading)
            const Padding(
              padding: EdgeInsets.only(top: 40),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 30),
              child: Center(
                child: Column(
                  children: [
                    Text(_error!,
                        style: const TextStyle(color: Colors.grey)),
                    const SizedBox(height: 12),
                    FilledButton(
                        onPressed: _load, child: Text(tr('retry'))),
                  ],
                ),
              ),
            )
          else
            for (final p in _order) _timeRow(p.$2, p.$3, _times?[p.$1] ?? '—'),
          const SizedBox(height: 10),
          Center(
            child: Text(tr('pr_note'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: AppConfig.inkMuted, fontSize: 11.5)),
          ),
        ],
      ),
    );
  }

  Widget _timeRow(String key, IconData icon, String value) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppConfig.line),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppConfig.brandAccent, size: 20),
            const SizedBox(width: 12),
            Expanded(
              child: Text(tr(key),
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 15)),
            ),
            Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 16,
                    color: AppConfig.navy)),
          ],
        ),
      );

  Widget _box({required Widget child}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppConfig.line),
        ),
        child: child,
      );
}
