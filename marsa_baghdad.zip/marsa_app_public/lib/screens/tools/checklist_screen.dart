import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../config/app_config.dart';
import '../../l10n/l10n.dart';

/// A local, editable travel packing checklist. Progress + custom items persist
/// on the device via SharedPreferences. No backend, works fully offline.
class ChecklistScreen extends StatefulWidget {
  const ChecklistScreen({super.key});
  @override
  State<ChecklistScreen> createState() => _ChecklistScreenState();
}

class _ChecklistScreenState extends State<ChecklistScreen> {
  static const _prefKey = 'checklist_v1';

  // categoryKey -> preset item ids (also their l10n keys)
  static const Map<String, List<String>> _preset = {
    'clc_documents': [
      'cli_passport',
      'cli_visa',
      'cli_tickets',
      'cli_id',
      'cli_insurance',
      'cli_voucher',
    ],
    'clc_money': ['cli_cash', 'cli_cards'],
    'clc_electronics': [
      'cli_phone',
      'cli_charger',
      'cli_powerbank',
      'cli_adapter',
    ],
    'clc_clothing': ['cli_clothes', 'cli_shoes', 'cli_jacket'],
    'clc_health': ['cli_meds', 'cli_toothbrush', 'cli_sunscreen'],
  };

  final Set<String> _checked = {};
  final Map<String, List<_Item>> _custom = {}; // category -> custom items

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_prefKey);
    if (raw == null) return;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      _checked
        ..clear()
        ..addAll((m['checked'] as List? ?? []).map((e) => '$e'));
      _custom.clear();
      final c = m['custom'] as Map<String, dynamic>? ?? {};
      c.forEach((cat, items) {
        _custom[cat] = (items as List)
            .map((e) => _Item('${e['id']}', '${e['text']}'))
            .toList();
      });
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _persist() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _prefKey,
        jsonEncode({
          'checked': _checked.toList(),
          'custom': _custom.map((k, v) =>
              MapEntry(k, v.map((e) => {'id': e.id, 'text': e.text}).toList())),
        }));
  }

  void _toggle(String id) {
    setState(() {
      if (_checked.contains(id)) {
        _checked.remove(id);
      } else {
        _checked.add(id);
      }
    });
    _persist();
  }

  Future<void> _addCustom(String category) async {
    final ctrl = TextEditingController();
    final text = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppConfig.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (c) => Padding(
        padding: EdgeInsets.fromLTRB(
            16, 16, 16, MediaQuery.of(c).viewInsets.bottom + 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(tr('cl_add_item'),
                style: const TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              autofocus: true,
              decoration: InputDecoration(
                hintText: tr('cl_add_hint'),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              onSubmitted: (v) => Navigator.pop(c, v),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(c, ctrl.text),
                child: Text(tr('cl_add_btn')),
              ),
            ),
          ],
        ),
      ),
    );
    if (text != null && text.trim().isNotEmpty) {
      final id = 'c_${DateTime.now().millisecondsSinceEpoch}';
      setState(() {
        _custom.putIfAbsent(category, () => []).add(_Item(id, text.trim()));
      });
      _persist();
    }
  }

  void _removeCustom(String category, String id) {
    setState(() {
      _custom[category]?.removeWhere((e) => e.id == id);
      _checked.remove(id);
    });
    _persist();
  }

  int get _total =>
      _preset.values.fold(0, (a, b) => a + b.length) +
      _custom.values.fold(0, (a, b) => a + b.length);

  @override
  Widget build(BuildContext context) {
    final done = _checked.length;
    final total = _total;
    final pct = total == 0 ? 0.0 : done / total;
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_checklist'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Progress
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [AppConfig.navy, AppConfig.brandPrimary]),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(tr('cl_progress'),
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700)),
                    Text('$done / $total',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 16)),
                  ],
                ),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: pct,
                    minHeight: 8,
                    backgroundColor: Colors.white24,
                    valueColor:
                        const AlwaysStoppedAnimation(Colors.white),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          for (final cat in _preset.keys) _category(cat),
        ],
      ),
    );
  }

  Widget _category(String cat) {
    final items = [
      ..._preset[cat]!.map((id) => _Item(id, tr(id))),
      ...(_custom[cat] ?? []),
    ];
    final customIds = (_custom[cat] ?? []).map((e) => e.id).toSet();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(2, 16, 2, 8),
          child: Row(
            children: [
              Text(tr(cat),
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      color: AppConfig.ink)),
              const Spacer(),
              TextButton.icon(
                onPressed: () => _addCustom(cat),
                icon: const Icon(Icons.add, size: 18),
                label: Text(tr('cl_add_item')),
              ),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: AppConfig.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppConfig.line),
          ),
          child: Column(
            children: [
              for (final item in items)
                _row(item, cat, customIds.contains(item.id)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _row(_Item item, String cat, bool isCustom) {
    final on = _checked.contains(item.id);
    return InkWell(
      onTap: () => _toggle(item.id),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Row(
          children: [
            Checkbox(
              value: on,
              activeColor: AppConfig.brandPrimary,
              onChanged: (_) => _toggle(item.id),
            ),
            Expanded(
              child: Text(item.text,
                  style: TextStyle(
                      fontSize: 14.5,
                      decoration: on ? TextDecoration.lineThrough : null,
                      color: on ? AppConfig.inkMuted : AppConfig.ink)),
            ),
            if (isCustom)
              IconButton(
                icon: const Icon(Icons.close,
                    size: 18, color: AppConfig.inkMuted),
                onPressed: () => _removeCustom(cat, item.id),
              ),
          ],
        ),
      ),
    );
  }
}

class _Item {
  final String id;
  final String text;
  _Item(this.id, this.text);
}
