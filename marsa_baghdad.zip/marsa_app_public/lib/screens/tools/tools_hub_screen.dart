import 'package:flutter/material.dart';
import '../../config/app_config.dart';
import '../../l10n/l10n.dart';
import 'currency_screen.dart';
import 'weather_screen.dart';
import 'prayer_screen.dart';
import 'checklist_screen.dart';
import 'emergency_screen.dart';
import 'baggage_screen.dart';
import 'flight_calc_screen.dart';
import 'world_clock_screen.dart';

/// "Travel Tools" — a hub of self-contained utilities that work with no
/// WhatsApp, no payment and no login: currency, weather, prayer times & qibla,
/// packing checklist and live flight status.
class ToolsHubScreen extends StatelessWidget {
  const ToolsHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = <_Tool>[
      _Tool('tool_currency', 'tool_currency_sub', Icons.currency_exchange,
          const [Color(0xFF1FA97E), Color(0xFF117A54)], const CurrencyScreen()),
      _Tool('tool_weather', 'tool_weather_sub', Icons.wb_sunny,
          const [Color(0xFFE8912A), Color(0xFFC06E15)], const WeatherScreen()),
      _Tool('tool_prayer', 'tool_prayer_sub', Icons.mosque,
          const [Color(0xFF17A2C4), Color(0xFF0E6F8C)], const PrayerScreen()),
      _Tool('tool_checklist', 'tool_checklist_sub', Icons.checklist,
          const [Color(0xFF7A4F9E), Color(0xFF573A76)], const ChecklistScreen()),
      _Tool('tool_distance', 'tool_distance_sub', Icons.straighten,
          const [Color(0xFF0E9CC4), Color(0xFF0A6E8C)],
          const FlightCalcScreen()),
      _Tool('tool_worldclock', 'tool_worldclock_sub', Icons.schedule,
          const [Color(0xFF1B5E9B), Color(0xFF13406B)],
          const WorldClockScreen()),
      _Tool('tool_baggage', 'tool_baggage_sub', Icons.luggage,
          const [Color(0xFFC0304A), Color(0xFF8E1E33)],
          const BaggageScreen()),
      _Tool('tool_emergency', 'tool_emergency_sub', Icons.emergency,
          const [Color(0xFFE8912A), Color(0xFFC06E15)],
          const EmergencyScreen()),
    ];
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tools_title'))),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.98,
        children: [for (final t in tools) _card(context, t)],
      ),
    );
  }

  Widget _card(BuildContext context, _Tool t) {
    return GestureDetector(
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => t.page)),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: t.colors,
          ),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(t.icon, color: Colors.white, size: 24),
            ),
            const Spacer(),
            Text(tr(t.titleKey),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(tr(t.subKey),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class _Tool {
  final String titleKey;
  final String subKey;
  final IconData icon;
  final List<Color> colors;
  final Widget page;
  _Tool(this.titleKey, this.subKey, this.icon, this.colors, this.page);
}
