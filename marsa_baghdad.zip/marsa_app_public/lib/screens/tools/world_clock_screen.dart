import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../config/app_config.dart';
import '../../config/tool_cities.dart';
import '../../l10n/l10n.dart';

/// Live local time for destination cities. Offsets are applied client-side;
/// DST is approximated (EU-style) for the few cities that observe it.
class WorldClockScreen extends StatefulWidget {
  const WorldClockScreen({super.key});
  @override
  State<WorldClockScreen> createState() => _WorldClockScreenState();
}

class _WorldClockScreenState extends State<WorldClockScreen> {
  Timer? _timer;

  // base (standard) UTC offset in hours, and whether the city observes EU DST.
  static const Map<String, (double, bool)> _tz = {
    'Baghdad': (3.0, false),
    'Basra': (3.0, false),
    'Erbil': (3.0, false),
    'Najaf': (3.0, false),
    'Karbala': (3.0, false),
    'Dubai': (4.0, false),
    'Istanbul': (3.0, false),
    'Cairo': (2.0, true),
    'Beirut': (2.0, true),
    'Amman': (3.0, false),
    'Doha': (3.0, false),
    'Jeddah': (3.0, false),
    'Makkah': (3.0, false),
    'Madinah': (3.0, false),
    'London': (0.0, true),
  };

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(
        const Duration(seconds: 15), (_) => mounted ? setState(() {}) : null);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  double _offset(String en) {
    final t = _tz[en] ?? (3.0, false);
    final month = DateTime.now().toUtc().month;
    final summer = month >= 4 && month <= 9; // approximate EU DST window
    return t.$1 + (t.$2 && summer ? 1 : 0);
  }

  String _name(ToolCity c) => L10n.locale.value == 'en' ? c.en : c.ar;

  @override
  Widget build(BuildContext context) {
    final utc = DateTime.now().toUtc();
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_worldclock'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final c in ToolCities.all) _row(c, utc),
          const SizedBox(height: 10),
          Text(tr('wc_note'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppConfig.inkMuted, fontSize: 11.5, height: 1.5)),
        ],
      ),
    );
  }

  Widget _row(ToolCity c, DateTime utc) {
    final off = _offset(c.en);
    final local = utc.add(
        Duration(minutes: (off * 60).round()));
    final time = DateFormat('HH:mm').format(local);
    final day = DateFormat('EEE, dd MMM').format(local);
    final sign = off >= 0 ? '+' : '';
    final gmt =
        'GMT$sign${off % 1 == 0 ? off.toInt().toString() : off.toString()}';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppConfig.line),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_name(c),
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 2),
                Text('$day • $gmt',
                    style: const TextStyle(
                        fontSize: 11.5, color: AppConfig.inkMuted)),
              ],
            ),
          ),
          Text(time,
              style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 22,
                  color: AppConfig.navy)),
        ],
      ),
    );
  }
}
