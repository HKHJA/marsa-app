import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../config/app_config.dart';
import '../../config/tool_cities.dart';
import '../../l10n/l10n.dart';
import '../../services/tools_api.dart';

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});
  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  ToolCity city = ToolCities.all.first;
  WeatherData? _data;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await ToolsApi.weather(city.lat, city.lon);
      setState(() {
        _data = d;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _error = tr('fetch_fail');
        _loading = false;
      });
    }
  }

  String _cityName(ToolCity c) => L10n.locale.value == 'en' ? c.en : c.ar;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_weather'))),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              decoration: BoxDecoration(
                color: AppConfig.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppConfig.line),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<int>(
                  isExpanded: true,
                  value: ToolCities.all.indexOf(city),
                  items: [
                    for (var i = 0; i < ToolCities.all.length; i++)
                      DropdownMenuItem(
                          value: i, child: Text(_cityName(ToolCities.all[i]))),
                  ],
                  onChanged: (v) {
                    if (v != null) {
                      setState(() => city = ToolCities.all[v]);
                      _load();
                    }
                  },
                ),
              ),
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _error != null
                    ? _errorView()
                    : _content(),
          ),
        ],
      ),
    );
  }

  Widget _content() {
    final d = _data!;
    final wc = WeatherCode.of(d.code);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppConfig.navy, AppConfig.brandPrimary],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: [
              Text(wc.icon, style: const TextStyle(fontSize: 54)),
              const SizedBox(height: 4),
              Text('${d.temp.round()}°C',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 46,
                      fontWeight: FontWeight.w900)),
              Text(tr(wc.key),
                  style: const TextStyle(color: Colors.white, fontSize: 16)),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _stat(Icons.water_drop, '${d.humidity.round()}%',
                      tr('wx_humidity')),
                  _stat(Icons.air, '${d.wind.round()} km/h', tr('wx_wind')),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Text(tr('wx_forecast'),
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        for (final day in d.days) _dayRow(day),
      ],
    );
  }

  Widget _stat(IconData i, String v, String label) => Column(
        children: [
          Icon(i, color: Colors.white70, size: 20),
          const SizedBox(height: 4),
          Text(v,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold)),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ],
      );

  Widget _dayRow(WeatherDay day) {
    final wc = WeatherCode.of(day.code);
    String label;
    try {
      label = DateFormat('EEE, dd MMM').format(DateTime.parse(day.date));
    } catch (_) {
      label = day.date;
    }
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppConfig.line),
      ),
      child: Row(
        children: [
          Text(wc.icon, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 12),
          Expanded(
            child: Text(label,
                style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
          Text('${day.max.round()}°',
              style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(width: 6),
          Text('${day.min.round()}°',
              style: const TextStyle(color: AppConfig.inkMuted)),
        ],
      ),
    );
  }

  Widget _errorView() => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off, color: Colors.grey, size: 40),
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 12),
            FilledButton(onPressed: _load, child: Text(tr('retry'))),
          ],
        ),
      );
}
