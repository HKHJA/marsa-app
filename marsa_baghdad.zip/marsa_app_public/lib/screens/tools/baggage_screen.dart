import 'package:flutter/material.dart';
import '../../config/app_config.dart';
import '../../config/baggage_data.dart';
import '../../l10n/l10n.dart';

class BaggageScreen extends StatelessWidget {
  const BaggageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_baggage'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final a in BaggageData.all) _card(a),
          const SizedBox(height: 8),
          Text(tr('bg_note'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppConfig.inkMuted, fontSize: 11.5, height: 1.5)),
        ],
      ),
    );
  }

  Widget _card(BaggageAirline a) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppConfig.line),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppConfig.tintCyan,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.flight, color: AppConfig.brandPrimary),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(a.name,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(
                          child: _pill(Icons.work_outline, tr('bg_cabin'),
                              a.cabin)),
                      const SizedBox(width: 8),
                      Expanded(
                          child: _pill(Icons.luggage, tr('bg_checked'),
                              a.checked)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  Widget _pill(IconData icon, String label, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: AppConfig.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppConfig.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 13, color: AppConfig.inkMuted),
                const SizedBox(width: 4),
                Text(label,
                    style: const TextStyle(
                        fontSize: 10.5, color: AppConfig.inkMuted)),
              ],
            ),
            const SizedBox(height: 2),
            Text(value,
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 14)),
          ],
        ),
      );
}
