import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../config/app_config.dart';
import '../../config/tool_cities.dart';
import '../../l10n/l10n.dart';

class FlightCalcScreen extends StatefulWidget {
  const FlightCalcScreen({super.key});
  @override
  State<FlightCalcScreen> createState() => _FlightCalcScreenState();
}

class _FlightCalcScreenState extends State<FlightCalcScreen> {
  int from = 0;
  int to = 5; // Dubai by default

  double _distanceKm(ToolCity a, ToolCity b) {
    const r = 6371.0;
    final dLat = _rad(b.lat - a.lat);
    final dLon = _rad(b.lon - a.lon);
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_rad(a.lat)) *
            math.cos(_rad(b.lat)) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    return r * 2 * math.atan2(math.sqrt(h), math.sqrt(1 - h));
  }

  double _rad(double d) => d * math.pi / 180;

  String _cityName(ToolCity c) => L10n.locale.value == 'en' ? c.en : c.ar;

  @override
  Widget build(BuildContext context) {
    final a = ToolCities.all[from];
    final b = ToolCities.all[to];
    final same = from == to;
    final km = same ? 0.0 : _distanceKm(a, b);
    // Estimated flight time: cruise ~800 km/h + ~35 min taxi/climb/descent.
    final totalMin = same ? 0 : (km / 800 * 60 + 35).round();
    final h = totalMin ~/ 60;
    final m = totalMin % 60;

    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_distance'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(child: _picker(tr('f_from'), from, (v) => setState(() => from = v))),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Material(
                  color: AppConfig.navy,
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () => setState(() {
                      final t = from;
                      from = to;
                      to = t;
                    }),
                    child: const Padding(
                      padding: EdgeInsets.all(8),
                      child: Icon(Icons.swap_horiz,
                          color: Colors.white, size: 22),
                    ),
                  ),
                ),
              ),
              Expanded(child: _picker(tr('f_to'), to, (v) => setState(() => to = v))),
            ],
          ),
          const SizedBox(height: 18),
          if (same)
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Text(tr('f_diff_cities'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red)),
            )
          else
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [AppConfig.navy, AppConfig.brandPrimary]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                          child: Text(_cityName(a),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold))),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Icon(Icons.flight, color: Colors.white70,
                            size: 18),
                      ),
                      Flexible(
                          child: Text(_cityName(b),
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold))),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _stat('${_fmtKm(km)} ${tr('dc_km')}', tr('dc_distance')),
                      Container(width: 1, height: 44, color: Colors.white24),
                      _stat('${h}h ${m}m', tr('dc_duration')),
                    ],
                  ),
                ],
              ),
            ),
          const SizedBox(height: 12),
          Text(tr('dc_note'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppConfig.inkMuted, fontSize: 11.5, height: 1.5)),
        ],
      ),
    );
  }

  String _fmtKm(double v) {
    final s = v.round().toString();
    final buf = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  Widget _stat(String value, String label) => Column(
        children: [
          Text(value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ],
      );

  Widget _picker(String label, int value, ValueChanged<int> onCh) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppConfig.line),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 11.5,
                    color: AppConfig.inkMuted,
                    fontWeight: FontWeight.w600)),
            DropdownButtonHideUnderline(
              child: DropdownButton<int>(
                isExpanded: true,
                value: value,
                items: [
                  for (var i = 0; i < ToolCities.all.length; i++)
                    DropdownMenuItem(
                        value: i, child: Text(_cityName(ToolCities.all[i]))),
                ],
                onChanged: (v) => v == null ? null : onCh(v),
              ),
            ),
          ],
        ),
      );
}
