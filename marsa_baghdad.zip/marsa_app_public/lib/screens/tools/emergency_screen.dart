import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../config/app_config.dart';
import '../../config/emergency_data.dart';
import '../../l10n/l10n.dart';

class EmergencyScreen extends StatefulWidget {
  const EmergencyScreen({super.key});
  @override
  State<EmergencyScreen> createState() => _EmergencyScreenState();
}

class _EmergencyScreenState extends State<EmergencyScreen> {
  int _i = 0;

  Future<void> _call(String number) async {
    final uri = Uri.parse('tel:$number');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  String _name(EmergencyCountry c) => L10n.locale.value == 'en' ? c.en : c.ar;

  @override
  Widget build(BuildContext context) {
    final c = EmergencyData.all[_i];
    final items = <(String, IconData, String?)>[
      (tr('em_general'), Icons.emergency, c.general),
      (tr('em_police'), Icons.local_police, c.police),
      (tr('em_ambulance'), Icons.local_hospital, c.ambulance),
      (tr('em_fire'), Icons.local_fire_department, c.fire),
    ];
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_emergency'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: AppConfig.surface,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppConfig.line),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<int>(
                isExpanded: true,
                value: _i,
                items: [
                  for (var i = 0; i < EmergencyData.all.length; i++)
                    DropdownMenuItem(
                        value: i, child: Text(_name(EmergencyData.all[i]))),
                ],
                onChanged: (v) => setState(() => _i = v ?? 0),
              ),
            ),
          ),
          const SizedBox(height: 12),
          for (final it in items)
            if (it.$3 != null) _row(it.$1, it.$2, it.$3!),
          const SizedBox(height: 12),
          Text(tr('em_note'),
              textAlign: TextAlign.center,
              style: const TextStyle(
                  color: AppConfig.inkMuted, fontSize: 11.5, height: 1.5)),
        ],
      ),
    );
  }

  Widget _row(String label, IconData icon, String number) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppConfig.line),
        ),
        child: ListTile(
          leading: Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0xFFFDECEA),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: const Color(0xFFC62828)),
          ),
          title: Text(label,
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(number,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: AppConfig.navy)),
          trailing: FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: AppConfig.tGreen,
              minimumSize: const Size(0, 40),
            ),
            icon: const Icon(Icons.call, size: 16),
            label: Text(tr('em_call')),
            onPressed: () => _call(number),
          ),
        ),
      );
}
