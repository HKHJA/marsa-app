import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../config/app_config.dart';
import '../../l10n/l10n.dart';
import '../../services/tools_api.dart';

class CurrencyScreen extends StatefulWidget {
  const CurrencyScreen({super.key});
  @override
  State<CurrencyScreen> createState() => _CurrencyScreenState();
}

class _CurrencyScreenState extends State<CurrencyScreen> {
  final _amount = TextEditingController(text: '100');
  String from = 'USD';
  String to = 'IQD';
  Map<String, double>? _rates;
  String? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
    _amount.addListener(() => setState(() {}));
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await ToolsApi.rates();
      setState(() {
        _rates = r;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _error = tr('fetch_fail');
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final amt = double.tryParse(_amount.text) ?? 0;
    final result =
        _rates == null ? 0.0 : ToolsApi.convert(_rates!, amt, from, to);
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(title: Text(tr('tool_currency'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _errorView()
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tr('cur_amount'),
                              style: const TextStyle(
                                  fontSize: 12.5,
                                  color: AppConfig.inkMuted,
                                  fontWeight: FontWeight.w600)),
                          TextField(
                            controller: _amount,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            inputFormatters: [
                              FilteringTextInputFormatter.allow(
                                  RegExp(r'[0-9.]'))
                            ],
                            style: const TextStyle(
                                fontSize: 26, fontWeight: FontWeight.w800),
                            decoration: const InputDecoration(
                                border: InputBorder.none),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(child: _picker(tr('cur_from'), from,
                            (v) => setState(() => from = v))),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: Material(
                            color: AppConfig.navy,
                            shape: const CircleBorder(),
                            child: InkWell(
                              customBorder: const CircleBorder(),
                              onTap: () => setState(() {
                                final t = from;
                                from = to;
                                to = t;
                              }),
                              child: const Padding(
                                padding: EdgeInsets.all(8),
                                child: Icon(Icons.swap_horiz,
                                    color: Colors.white, size: 22),
                              ),
                            ),
                          ),
                        ),
                        Expanded(child: _picker(tr('cur_to'), to,
                            (v) => setState(() => to = v))),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [AppConfig.navy, AppConfig.brandPrimary],
                        ),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Column(
                        children: [
                          Text('${_fmt(amt)} $from',
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 14)),
                          const SizedBox(height: 6),
                          Text('${_fmt(result)} $to',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 30,
                                  fontWeight: FontWeight.w900)),
                          const SizedBox(height: 8),
                          Text(
                              '1 $from = ${_fmt(ToolsApi.convert(_rates!, 1, from, to))} $to',
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 12.5)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: Text(tr('cur_note'),
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: AppConfig.inkMuted, fontSize: 11.5)),
                    ),
                  ],
                ),
    );
  }

  String _fmt(double v) {
    if (v >= 1000) {
      final s = v.round().toString();
      final buf = StringBuffer();
      for (var i = 0; i < s.length; i++) {
        if (i > 0 && (s.length - i) % 3 == 0) buf.write(',');
        buf.write(s[i]);
      }
      return buf.toString();
    }
    return v.toStringAsFixed(2);
  }

  Widget _picker(String label, String value, ValueChanged<String> onCh) => _card(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(
                    fontSize: 12.5,
                    color: AppConfig.inkMuted,
                    fontWeight: FontWeight.w600)),
            DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                isExpanded: true,
                value: value,
                items: ToolsApi.currencies
                    .map((c) =>
                        DropdownMenuItem(value: c, child: Text(c)))
                    .toList(),
                onChanged: (v) => v == null ? null : onCh(v),
              ),
            ),
          ],
        ),
      );

  Widget _card({required Widget child}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppConfig.line),
        ),
        child: child,
      );

  Widget _errorView() => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off, color: Colors.grey, size: 40),
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 12),
            FilledButton(onPressed: _load, child: Text(tr('retry'))),
          ],
        ),
      );
}
