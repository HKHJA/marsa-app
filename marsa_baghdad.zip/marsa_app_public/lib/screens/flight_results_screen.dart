import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../models/flight_offer.dart';
import '../services/travel_service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/brand.dart';
import '../widgets/money.dart';
import '../widgets/search_ui.dart';

class FlightResultsScreen extends StatefulWidget {
  final String origin;
  final String destination;
  final DateTime date;
  final int adults;
  final DateTime? returnDate;
  const FlightResultsScreen({
    super.key,
    required this.origin,
    required this.destination,
    required this.date,
    required this.adults,
    this.returnDate,
  });

  @override
  State<FlightResultsScreen> createState() => _FlightResultsScreenState();
}

class _FlightResultsScreenState extends State<FlightResultsScreen> {
  late Future<List<FlightOffer>> _future;
  int _sort = 0; // 0 cheapest, 1 fastest, 2 direct-first

  @override
  void initState() {
    super.initState();
    _future = TravelService.searchFlights(
      origin: widget.origin,
      destination: widget.destination,
      date: widget.date,
      adults: widget.adults,
    );
  }

  List<FlightOffer> _sorted(List<FlightOffer> offers) {
    final list = [...offers];
    switch (_sort) {
      case 1:
        list.sort((a, b) => a.arrival
            .difference(a.departure)
            .compareTo(b.arrival.difference(b.departure)));
        break;
      case 2:
        list.sort((a, b) {
          if (a.stops != b.stops) return a.stops.compareTo(b.stops);
          return a.finalPrice.compareTo(b.finalPrice);
        });
        break;
      default:
        list.sort((a, b) => a.finalPrice.compareTo(b.finalPrice));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final d = DateFormat('dd MMM').format(widget.date);
    return Scaffold(
      backgroundColor: AppConfig.bg,
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${widget.origin} → ${widget.destination}',
                style:
                    const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            Text('$d • ${widget.adults} ${tr('f_passengers')}',
                style: const TextStyle(fontSize: 11.5, color: Colors.white70)),
          ],
        ),
      ),
      body: FutureBuilder<List<FlightOffer>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return _error(snap.error.toString());
          }
          final offers = _sorted(snap.data ?? []);
          if (offers.isEmpty) {
            return _empty();
          }
          return Column(
            children: [
              const SizedBox(height: 12),
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 16, right: 4),
                    child: Text('${offers.length} ${tr('results_count')}',
                        style: const TextStyle(
                            color: AppConfig.inkMuted,
                            fontWeight: FontWeight.w600,
                            fontSize: 12.5)),
                  ),
                  Expanded(
                    child: SortPills(
                      labels: [
                        tr('sort_cheapest'),
                        tr('sort_fastest'),
                        tr('sort_direct'),
                      ],
                      selected: _sort,
                      onChanged: (i) => setState(() => _sort = i),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
                  itemCount: offers.length,
                  itemBuilder: (context, i) => _FlightCard(
                      offer: offers[i], returnDate: widget.returnDate),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _empty() {
    final dd = DateFormat('dd MMM yyyy').format(widget.date);
    final msg = 'مرحبًا ${AppConfig.appNameAr} 👋\n'
        'أبحث عن رحلة:\n'
        '${widget.origin} → ${widget.destination}\n'
        '📅 $dd • ${widget.adults} مسافر\n\n'
        'الرجاء تزويدي بأفضل سعر متاح. شكرًا.';
    return Padding(
      padding: const EdgeInsets.all(28),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.flight_takeoff, size: 48, color: Colors.grey),
            const SizedBox(height: 14),
            Text(tr('fr_no_direct'),
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 6),
            Text(tr('fr_contact'),
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 18),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF25D366),
                minimumSize: const Size(230, 48),
              ),
              icon: const Icon(Icons.chat),
              label: Text(tr('fr_ask_whatsapp'),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              onPressed: () => WhatsAppService.custom(msg),
            ),
          ],
        ),
      ),
    );
  }

  Widget _error(String msg) => Padding(
        padding: const EdgeInsets.all(24),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 40),
              const SizedBox(height: 12),
              Text(tr('fetch_fail'),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        ),
      );
}

class _FlightCard extends StatelessWidget {
  final FlightOffer offer;
  final DateTime? returnDate;
  const _FlightCard({required this.offer, this.returnDate});

  @override
  Widget build(BuildContext context) {
    final t = DateFormat('HH:mm');
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppConfig.line),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppConfig.brandPrimary.withOpacity(0.1),
                  child: const Icon(Icons.flight,
                      color: AppConfig.brandPrimary, size: 20),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(offer.airline,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 15)),
                      Text(DateFormat('EEE، dd MMM').format(offer.departure),
                          style: const TextStyle(
                              fontSize: 11, color: Colors.grey)),
                    ],
                  ),
                ),
                PriceTag(
                  price: Money.fmt(offer.finalPrice),
                  note: tr('per_person'),
                ),
              ],
            ),
            const Divider(height: 22),
            Row(
              children: [
                _leg(t.format(offer.departure), offer.origin),
                Expanded(
                  child: Column(
                    children: [
                      Text(offer.durationLabel,
                          style: const TextStyle(
                              fontSize: 11, color: Colors.grey)),
                      const _DashLine(),
                      Text(
                          offer.stops == 0
                              ? tr('sort_direct')
                              : offer.stopsLabel,
                          style: TextStyle(
                              fontSize: 11,
                              color: offer.stops == 0
                                  ? AppConfig.tGreen
                                  : Colors.grey,
                              fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                _leg(t.format(offer.arrival), offer.destination),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF25D366),
                      minimumSize: const Size.fromHeight(46),
                    ),
                    icon: const Icon(Icons.chat),
                    label: Text(tr('book_whatsapp_full'),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    onPressed: () => WhatsAppService.bookFlight(offer,
                        returnDate: returnDate),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  style: IconButton.styleFrom(
                    backgroundColor: AppConfig.tintCyan,
                    minimumSize: const Size(46, 46),
                  ),
                  icon: const Icon(Icons.share, color: AppConfig.brandPrimary),
                  onPressed: () => Share.share(
                    '${offer.airline}: ${offer.origin} → ${offer.destination}\n'
                    'السعر: ${Money.fmt(offer.finalPrice)}\n'
                    'عبر ${AppConfig.appNameAr} — للحجز واتساب: '
                    'https://wa.me/${AppConfig.whatsappNumber}',
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _leg(String time, String code) => Column(
        children: [
          Text(time,
              style:
                  const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          Text(code, style: const TextStyle(color: Colors.grey)),
        ],
      );
}

/// A dashed route line with a small plane icon in the middle.
class _DashLine extends StatelessWidget {
  const _DashLine();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(child: _dashes()),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 4),
            child: Icon(Icons.flight, size: 15, color: AppConfig.brandPrimary),
          ),
          Expanded(child: _dashes()),
        ],
      ),
    );
  }

  Widget _dashes() => LayoutBuilder(
        builder: (context, c) {
          final count = (c.maxWidth / 6).floor().clamp(1, 30);
          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(
              count,
              (_) => Container(
                width: 3,
                height: 1.4,
                color: AppConfig.line,
              ),
            ),
          );
        },
      );
}
