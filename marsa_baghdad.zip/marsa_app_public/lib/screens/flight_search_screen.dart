import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../widgets/search_ui.dart';
import 'flight_results_screen.dart';

class FlightSearchScreen extends StatefulWidget {
  const FlightSearchScreen({super.key});
  @override
  State<FlightSearchScreen> createState() => _FlightSearchScreenState();
}

class _FlightSearchScreenState extends State<FlightSearchScreen> {
  String origin = 'BGW';
  String destination = 'DXB';
  DateTime date = DateTime.now().add(const Duration(days: 3));
  DateTime returnDate = DateTime.now().add(const Duration(days: 10));
  int adults = 1;
  int trip = 0; // 0 = one-way, 1 = round-trip

  String _label(String code) {
    final a = AppConfig.airports.firstWhere((x) => x['code'] == code,
        orElse: () => {'code': code, 'city': code, 'ar': code});
    final name = L10n.locale.value == 'en' ? a['city'] : a['ar'];
    return '$name ($code)';
  }

  void _pickAirport(bool isOrigin) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppConfig.surface,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.symmetric(vertical: 8),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
              child: Text(isOrigin ? tr('f_from') : tr('f_to'),
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            for (final a in AppConfig.airports)
              ListTile(
                leading: const Icon(Icons.flight_takeoff,
                    color: AppConfig.brandPrimary),
                title: Text(
                    '${L10n.locale.value == 'en' ? a['city'] : a['ar']} (${a['code']})'),
                onTap: () {
                  setState(() {
                    if (isOrigin) {
                      origin = a['code']!;
                    } else {
                      destination = a['code']!;
                    }
                  });
                  Navigator.pop(context);
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickDate(bool isReturn) async {
    final picked = await pickDate(context, isReturn ? returnDate : date,
        first: isReturn ? date : DateTime.now());
    if (picked != null) {
      setState(() {
        if (isReturn) {
          returnDate = picked;
        } else {
          date = picked;
          if (returnDate.isBefore(date)) {
            returnDate = date.add(const Duration(days: 3));
          }
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final same = origin == destination;
    return SearchHero(
      title: tr('fs_title'),
      subtitle: tr('fs_hero_sub'),
      icon: Icons.flight,
      children: [
        SegmentTabs(
          labels: [tr('trip_oneway'), tr('trip_round')],
          selected: trip,
          onChanged: (i) => setState(() => trip = i),
        ),
        const SizedBox(height: 16),
        FromToSwap(
          onSwap: () => setState(() {
            final t = origin;
            origin = destination;
            destination = t;
          }),
          from: LocationCard(
            label: tr('f_from'),
            value: _label(origin),
            icon: Icons.flight_takeoff,
            onTap: () => _pickAirport(true),
          ),
          to: LocationCard(
            label: tr('f_to'),
            value: _label(destination),
            icon: Icons.flight_land,
            onTap: () => _pickAirport(false),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: PillField(
                label: tr('f_depart_date'),
                value: shortDate(date),
                icon: Icons.calendar_today,
                onTap: () => _pickDate(false),
              ),
            ),
            if (trip == 1) ...[
              const SizedBox(width: 10),
              Expanded(
                child: PillField(
                  label: tr('f_return_date'),
                  value: shortDate(returnDate),
                  icon: Icons.event_repeat,
                  onTap: () => _pickDate(true),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 12),
        PillField(
          label: tr('f_passengers'),
          value: '',
          icon: Icons.person,
          trailing: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('$adults',
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w700)),
              MiniStepper(
                value: adults,
                onChanged: (v) => setState(() => adults = v),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        GradientButton(
          label: tr('f_search_flights'),
          icon: Icons.search,
          onPressed: same
              ? null
              : () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => FlightResultsScreen(
                        origin: origin,
                        destination: destination,
                        date: date,
                        adults: adults,
                        returnDate: trip == 1 ? returnDate : null,
                      ),
                    ),
                  ),
        ),
        if (same)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Text(tr('f_diff_cities'),
                style: const TextStyle(color: Colors.red, fontSize: 12)),
          ),
      ],
    );
  }
}
