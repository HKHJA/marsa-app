import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../widgets/form_fields.dart';
import 'flight_results_screen.dart';

class FlightSearchScreen extends StatefulWidget {
  const FlightSearchScreen({super.key});
  @override
  State<FlightSearchScreen> createState() => _FlightSearchScreenState();
}

class _FlightSearchScreenState extends State<FlightSearchScreen> {
  String origin = 'BGW';
  String destination = 'DXB';
  DateTime date = DateTime.now().add(const Duration(days: 3));
  int adults = 1;

  List<DropdownMenuItem<String>> get _airportItems => AppConfig.airports
      .map((a) => DropdownMenuItem(
            value: a['code'],
            child: Text('${a['ar']} (${a['code']})'),
          ))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حجز طيران')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          dropdownField('من', origin, _airportItems,
              (v) => setState(() => origin = v)),
          const SizedBox(height: 14),
          dropdownField('إلى', destination, _airportItems,
              (v) => setState(() => destination = v)),
          const SizedBox(height: 14),
          dateField('تاريخ المغادرة', date, (d) => setState(() => date = d)),
          const SizedBox(height: 14),
          counterField('المسافرون', adults, (v) => setState(() => adults = v)),
          const SizedBox(height: 24),
          searchButton(
            'ابحث عن الرحلات',
            origin == destination
                ? null
                : () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => FlightResultsScreen(
                          origin: origin,
                          destination: destination,
                          date: date,
                          adults: adults,
                        ),
                      ),
                    ),
          ),
          if (origin == destination)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('اختر مدينتين مختلفتين',
                  style: TextStyle(color: Colors.red, fontSize: 12)),
            ),
        ],
      ),
    );
  }
}
