import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../widgets/form_fields.dart';
import 'flight_results_screen.dart';

class FlightSearchScreen extends StatefulWidget {
  const FlightSearchScreen({super.key});
  @override
  State<FlightSearchScreen> createState() => _FlightSearchScreenState();
}

class _FlightSearchScreenState extends State<FlightSearchScreen> {
  String origin = 'BGW';
  String destination = 'DXB';
  DateTime date = DateTime.now().add(const Duration(days: 3));
  int adults = 1;

  List<DropdownMenuItem<String>> get _airportItems => AppConfig.airports
      .map((a) => DropdownMenuItem(
            value: a['code'],
            child: Text('${L10n.locale.value == 'en' ? a['city'] : a['ar']} (${a['code']})'),
          ))
      .toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('fs_title'))),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          dropdownField(tr('f_from'), origin, _airportItems,
              (v) => setState(() => origin = v)),
          const SizedBox(height: 14),
          dropdownField(tr('f_to'), destination, _airportItems,
              (v) => setState(() => destination = v)),
          const SizedBox(height: 14),
          dateField(tr('f_depart_date'), date, (d) => setState(() => date = d)),
          const SizedBox(height: 14),
          counterField(tr('f_passengers'), adults, (v) => setState(() => adults = v)),
          const SizedBox(height: 24),
          searchButton(
            tr('f_search_flights'),
            origin == destination
                ? null
                : () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => FlightResultsScreen(
                          origin: origin,
                          destination: destination,
                          date: date,
                          adults: adults,
                        ),
                      ),
                    ),
          ),
          if (origin == destination)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(tr('f_diff_cities'),
                  style: const TextStyle(color: Colors.red, fontSize: 12)),
            ),
        ],
      ),
    );
  }
}
