import 'package:flutter/material.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../config/services_catalog.dart';
import '../models/service.dart';
import '../services/supabase_service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/app_drawer.dart';
import '../widgets/money.dart';
import 'birthday_screen.dart';
import 'bookings_screen.dart';
import 'flight_search_screen.dart';
import 'flight_status_screen.dart';
import 'hotel_search_screen.dart';
import 'offers_screen.dart';
import 'services_screen.dart';
import 'visa_screen.dart';

/// App shell: navy app bar + side drawer + bottom navigation.
/// Tab 0 = Home (category tiles, offers, reviews), Tab 1 = My Bookings.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  int _tab = 0;
  bool _greeted = false;
  bool _pushAsked = false;
  bool _pushGranted = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initPushObserver();
    SupabaseCatalog.load().whenComplete(() {
      if (!mounted) return;
      setState(() {});
      _maybeGreet();
    });
  }

  void _initPushObserver() {
    if (!AppConfig.oneSignalEnabled) return;
    try {
      _pushGranted = OneSignal.Notifications.permission;
      OneSignal.Notifications.addPermissionObserver((granted) {
        if (mounted) setState(() => _pushGranted = granted);
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      SupabaseCatalog.load(force: true).whenComplete(() {
        if (mounted) setState(() {});
      });
    }
  }

  void _maybeGreet() {
    if (_greeted) return;
    _greeted = true;
    if (SupabaseCatalog.birthdayEnabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (_) => const BirthdayScreen()))
            .then((_) => _requestPush());
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) => _requestPush());
    }
  }

  void _requestPush() {
    if (_pushAsked || !AppConfig.oneSignalEnabled) return;
    _pushAsked = true;
    Future.delayed(const Duration(milliseconds: 600), () {
      try {
        OneSignal.Notifications.requestPermission(true);
      } catch (_) {}
    });
  }

  Future<void> _askPush() async {
    try {
      await OneSignal.Notifications.requestPermission(true);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        title: Text(_tab == 0 ? tr('appName') : tr('nav_bookings')),
        actions: [
          if (AppConfig.oneSignalEnabled)
            IconButton(
              onPressed: _askPush,
              icon: Icon(_pushGranted
                  ? Icons.notifications_none_rounded
                  : Icons.notifications_active_rounded),
            ),
        ],
      ),
      body: IndexedStack(
        index: _tab,
        children: [
          _HomeTab(pushGranted: _pushGranted, onEnablePush: _askPush),
          const BookingsScreen(),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        items: [
          BottomNavigationBarItem(
              icon: const Icon(Icons.home_rounded), label: tr('nav_home')),
          BottomNavigationBarItem(
              icon: const Icon(Icons.confirmation_num_outlined),
              label: tr('nav_bookings')),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Home tab content
// ---------------------------------------------------------------------------
class _HomeTab extends StatelessWidget {
  final bool pushGranted;
  final Future<void> Function() onEnablePush;
  const _HomeTab({required this.pushGranted, required this.onEnablePush});

  ServiceItem _svc(String id) =>
      ServicesCatalog.items.firstWhere((s) => s.id == id);

  void _go(BuildContext c, Widget page) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    final deals = SupabaseCatalog.deals;
    final reviews = SupabaseCatalog.reviews;

    final tiles = <Widget>[
      _CatTile(
        label: tr('cat_flights'),
        icon: Icons.flight,
        gradient: const [Color(0xFF2E7CC0), Color(0xFF13406B)],
        image: 'assets/tiles/flights.jpg',
        onTap: () => _go(context, const FlightSearchScreen()),
      ),
      _CatTile(
        label: tr('cat_hotels'),
        icon: Icons.hotel,
        gradient: const [Color(0xFFD6455E), Color(0xFF8E1E33)],
        image: 'assets/tiles/hotels.jpg',
        onTap: () => _go(context, const HotelSearchScreen()),
      ),
      _CatTile(
        label: tr('cat_offers'),
        icon: Icons.card_giftcard,
        gradient: const [Color(0xFF28C08F), Color(0xFF117A54)],
        image: 'assets/tiles/offers.jpg',
        onTap: () => _go(context, const OffersScreen()),
      ),
      _CatTile(
        label: tr('cat_visa'),
        icon: Icons.description_outlined,
        gradient: const [Color(0xFF2BB6D6), Color(0xFF0E6F8C)],
        image: 'assets/tiles/visa.jpg',
        onTap: () => _go(context, VisaScreen(service: _svc('visa'))),
      ),
      _CatTile(
        label: tr('cat_status'),
        icon: Icons.radar,
        gradient: const [Color(0xFF9163B8), Color(0xFF573A76)],
        image: 'assets/tiles/status.jpg',
        onTap: () => _go(context, const FlightStatusScreen()),
      ),
      _CatTile(
        label: tr('cat_services'),
        icon: Icons.grid_view_rounded,
        gradient: const [Color(0xFFF0A53F), Color(0xFFC06E15)],
        image: 'assets/tiles/services.jpg',
        onTap: () => _go(context, const ServicesScreen()),
      ),
    ];

    return ValueListenableBuilder<bool>(
      valueListenable: Money.useIqd,
      builder: (context, _, __) => ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          if (SupabaseCatalog.announcementEnabled &&
              SupabaseCatalog.announcementText.isNotEmpty)
            _announcementBanner(),
          if (AppConfig.oneSignalEnabled && !pushGranted) _pushBanner(),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.55,
            children: tiles,
          ),
          if (deals.isNotEmpty) ...[
            _SectionTitle(tr('sec_offers')),
            _DealsRow(deals: deals),
          ],
          const SizedBox(height: 16),
          _DiscoverBanner(onTap: () => _go(context, const OffersScreen())),
          if (reviews.isNotEmpty) ...[
            _SectionTitle(tr('sec_reviews')),
            ...reviews.map((r) => _ReviewCard(review: r)),
          ],
        ],
      ),
    );
  }

  Widget _pushBanner() => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: GestureDetector(
          onTap: onEnablePush,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: AppConfig.tintCyan,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppConfig.brandPrimary),
            ),
            child: Row(
              children: [
                const Icon(Icons.notifications_active,
                    color: AppConfig.brandPrimary, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(tr('push_enable_msg'),
                      style: const TextStyle(
                          color: AppConfig.navy,
                          fontWeight: FontWeight.w700)),
                ),
                Text(tr('push_enable_btn'),
                    style: const TextStyle(
                        color: AppConfig.brandPrimary,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ),
      );

  Widget _announcementBanner() => Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF3D6),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE0A82E)),
          ),
          child: Row(
            children: [
              const Text('📢', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(SupabaseCatalog.announcementText,
                    style: const TextStyle(
                        color: Color(0xFF7A5C12),
                        height: 1.5,
                        fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        ),
      );
}

// ---------------------------------------------------------------------------
// Category tile
// ---------------------------------------------------------------------------
class _CatTile extends StatelessWidget {
  final String label;
  final IconData icon;
  final List<Color> gradient;
  final String image;
  final VoidCallback onTap;
  const _CatTile({
    required this.label,
    required this.icon,
    required this.gradient,
    required this.image,
    required this.onTap,
  });

  // On-brand gradient shown while the photo loads or if it fails.
  Widget _fallback() => DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradient,
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    const shadow = [Shadow(blurRadius: 6, color: Colors.black54)];
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          fit: StackFit.expand,
          children: [
            // real photo (bundled asset)
            Image.asset(
              image,
              fit: BoxFit.cover,
              errorBuilder: (c, e, s) => _fallback(),
            ),
            // light neutral scrim so the PHOTO stays the star, with just
            // enough darkening top & bottom to keep the white text readable.
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.32),
                    Colors.black.withOpacity(0.10),
                    Colors.black.withOpacity(0.52),
                  ],
                  stops: const [0.0, 0.42, 1.0],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Align(
                alignment: AlignmentDirectional.topStart,
                child: Text(label,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                        shadows: shadow)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Align(
                alignment: AlignmentDirectional.bottomStart,
                child: Icon(icon, color: Colors.white, size: 28, shadows: shadow),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 18, 2, 8),
        child: Text(text,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w800,
                color: AppConfig.ink)),
      );
}

// ---------------------------------------------------------------------------
// Discover banner -> Offers
// ---------------------------------------------------------------------------
class _DiscoverBanner extends StatelessWidget {
  final VoidCallback onTap;
  const _DiscoverBanner({required this.onTap});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 120,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(
            colors: [AppConfig.brandPrimary, AppConfig.navy],
            begin: Alignment.centerRight,
            end: Alignment.centerLeft,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(tr('discover_title'),
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text(tr('discover_sub'),
                style: const TextStyle(color: Colors.white70, fontSize: 13)),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Deals carousel
// ---------------------------------------------------------------------------
class _DealsRow extends StatelessWidget {
  final List<Map<String, dynamic>> deals;
  const _DealsRow({required this.deals});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 140,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.zero,
        itemCount: deals.length,
        itemBuilder: (context, i) {
          final d = deals[i];
          final title = '${d['title'] ?? ''}';
          final sub = '${d['subtitle'] ?? ''}';
          final priceRaw = d['price'];
          final priceNum = priceRaw is num
              ? priceRaw.toDouble()
              : double.tryParse('${priceRaw ?? ''}');
          final msg =
              'مرحبًا ${AppConfig.appNameAr} 👋\nمهتم بهذا العرض:\n\n🔥 $title\n$sub${priceNum != null ? '\n💵 ${Money.fmt(priceNum)}' : ''}\n\nالرجاء التفاصيل. شكرًا.';
          return Container(
            width: 230,
            margin: const EdgeInsetsDirectional.only(end: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppConfig.navy,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 16)),
                const SizedBox(height: 4),
                Expanded(
                  child: Text(sub,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white70, fontSize: 13)),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (priceNum != null)
                      Text(Money.fmt(priceNum),
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 18)),
                    FilledButton(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: AppConfig.navy,
                        elevation: 0,
                        padding:
                            const EdgeInsets.symmetric(horizontal: 12),
                        minimumSize: const Size(0, 34),
                      ),
                      onPressed: () => WhatsAppService.custom(msg),
                      child: Text(tr('book'),
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 13)),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Review card
// ---------------------------------------------------------------------------
class _ReviewCard extends StatelessWidget {
  final Map<String, dynamic> review;
  const _ReviewCard({required this.review});
  @override
  Widget build(BuildContext context) {
    final stars =
        (review['stars'] is num) ? (review['stars'] as num).toInt() : 5;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppConfig.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('${review['name'] ?? ''}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('★' * stars + '☆' * (5 - stars),
                  style: const TextStyle(
                      color: Color(0xFFE0A82E), fontSize: 13)),
            ],
          ),
          const SizedBox(height: 4),
          Text('${review['text'] ?? ''}',
              style: const TextStyle(color: Colors.black87, height: 1.6)),
        ],
      ),
    );
  }
}
