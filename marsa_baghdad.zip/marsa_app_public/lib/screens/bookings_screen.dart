import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../services/whatsapp_service.dart';

/// "My Bookings" tab. Booking is finalized over WhatsApp with the agency, so
/// this screen guides the customer to their WhatsApp conversation where their
/// confirmed bookings and tickets live.
class BookingsScreen extends StatelessWidget {
  const BookingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: AppConfig.tintCyan,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.confirmation_num_outlined,
                  size: 44, color: AppConfig.navy),
            ),
            const SizedBox(height: 20),
            const Text('حجوزاتك معنا',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: AppConfig.ink)),
            const SizedBox(height: 8),
            const Text(
              'يتم تأكيد الحجوزات وإرسال التذاكر عبر واتساب مباشرة مع فريق مرسى بغداد. تواصل معنا لمتابعة حجزك أو لعمل حجز جديد.',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: AppConfig.inkMuted, height: 1.7, fontSize: 14),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: AppConfig.whatsapp,
                foregroundColor: Colors.white,
                minimumSize: const Size(240, 50),
              ),
              icon: const Icon(Icons.chat),
              label: const Text('تواصل معنا على واتساب',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              onPressed: () => WhatsAppService.custom(
                  'مرحبًا ${AppConfig.appNameAr} 👋\nأود متابعة حجوزاتي / عمل حجز جديد. شكرًا.'),
            ),
          ],
        ),
      ),
    );
  }
}
