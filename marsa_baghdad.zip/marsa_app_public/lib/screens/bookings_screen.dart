import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../models/trip.dart';
import '../services/trip_store.dart';
import '../services/whatsapp_service.dart';

/// "My Trips" — a local, on-device history of every booking/request the
/// customer sent, with a status they can track and follow up on WhatsApp.
class BookingsScreen extends StatelessWidget {
  const BookingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<List<Trip>>(
      valueListenable: TripStore.trips,
      builder: (context, trips, _) {
        if (trips.isEmpty) return const _Empty();
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: trips.length,
          itemBuilder: (context, i) => _TripCard(trip: trips[i]),
        );
      },
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty();
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: AppConfig.tintCyan,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.luggage_outlined,
                  size: 44, color: AppConfig.navy),
            ),
            const SizedBox(height: 20),
            Text(tr('trips_empty'),
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: AppConfig.ink)),
            const SizedBox(height: 8),
            Text(tr('trips_empty_sub'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: AppConfig.inkMuted, height: 1.7, fontSize: 14)),
          ],
        ),
      ),
    );
  }
}

class _TripCard extends StatelessWidget {
  final Trip trip;
  const _TripCard({required this.trip});

  static const _typeIcon = {
    'flight': Icons.flight,
    'hotel': Icons.hotel,
    'service': Icons.room_service,
    'deal': Icons.local_offer,
    'visa': Icons.description,
  };

  String _typeLabel() {
    switch (trip.type) {
      case 'flight':
        return tr('trip_type_flight');
      case 'hotel':
        return tr('trip_type_hotel');
      case 'deal':
        return tr('trip_type_deal');
      case 'visa':
        return tr('trip_type_visa');
      default:
        return tr('trip_type_service');
    }
  }

  ({String label, Color color}) _status() {
    switch (trip.status) {
      case 'confirmed':
        return (label: tr('trip_status_confirmed'), color: AppConfig.tGreen);
      case 'done':
        return (label: tr('trip_status_done'), color: AppConfig.brandAccent);
      case 'cancelled':
        return (label: tr('trip_status_cancelled'), color: AppConfig.tCrimson);
      default:
        return (label: tr('trip_status_sent'), color: AppConfig.tOrange);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _status();
    final date = DateFormat('dd MMM yyyy • HH:mm')
        .format(DateTime.fromMillisecondsSinceEpoch(trip.createdAt));
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppConfig.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppConfig.line),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppConfig.tintCyan,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(_typeIcon[trip.type] ?? Icons.receipt_long,
                      color: AppConfig.brandPrimary, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(trip.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: AppConfig.ink)),
                      if (trip.subtitle.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(trip.subtitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 12.5, color: AppConfig.inkMuted)),
                      ],
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: s.color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(s.label,
                      style: TextStyle(
                          color: s.color,
                          fontWeight: FontWeight.bold,
                          fontSize: 11.5)),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Flexible(
                  child: Text('${_typeLabel()} • $date',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 11, color: AppConfig.inkMuted)),
                ),
                const Spacer(),
                if (trip.price.isNotEmpty)
                  Text(trip.price,
                      style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14,
                          color: AppConfig.navy)),
              ],
            ),
            const Divider(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppConfig.whatsapp,
                      side: const BorderSide(color: AppConfig.whatsapp),
                      minimumSize: const Size.fromHeight(42),
                    ),
                    icon: const Icon(Icons.chat, size: 18),
                    label: Text(tr('trip_reopen'),
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 12.5)),
                    onPressed: () => WhatsAppService.custom(
                      'مرحبًا ${AppConfig.appNameAr} 👋\n'
                      'بخصوص طلبي: ${trip.title}\n'
                      '${trip.subtitle}\n\nالرجاء المتابعة. شكرًا.',
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert, color: AppConfig.inkMuted),
                  onSelected: (v) {
                    if (v == 'delete') {
                      TripStore.remove(trip.id);
                    } else {
                      TripStore.setStatus(trip.id, v);
                    }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(
                        value: 'confirmed',
                        child: Text(tr('trip_mark_confirmed'))),
                    PopupMenuItem(
                        value: 'done', child: Text(tr('trip_mark_done'))),
                    PopupMenuItem(
                        value: 'delete',
                        child: Text(tr('trip_delete'),
                            style:
                                const TextStyle(color: AppConfig.tCrimson))),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
