import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../l10n/l10n.dart';
import '../config/services_catalog.dart';
import '../services/supabase_service.dart';
import '../services/whatsapp_service.dart';
import '../widgets/money.dart';
import 'service_request_screen.dart';

/// Offers & packages: dashboard deals + tour/umrah packages.
class OffersScreen extends StatelessWidget {
  const OffersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final deals = SupabaseCatalog.deals;
    final packages = ServicesCatalog.items
        .where((s) =>
            (s.id == 'umrah' || s.id == 'tours' || s.id == 'car') &&
            SupabaseCatalog.serviceEnabled(s.id))
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(tr('offers_title'))),
      body: ValueListenableBuilder<bool>(
        valueListenable: Money.useIqd,
        builder: (context, _, __) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (deals.isEmpty && packages.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 60),
                child: Center(
                  child: Text(tr('no_offers'),
                      style: const TextStyle(color: AppConfig.inkMuted)),
                ),
              ),
            for (final d in deals) _dealCard(d),
            if (packages.isNotEmpty) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(2, 12, 2, 8),
                child: Text(tr('our_packages'),
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: AppConfig.ink)),
              ),
              for (final p in packages)
                _packageTile(context, p.emoji, p.title, p.sub,
                    () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                ServiceRequestScreen(service: p)))),
            ],
          ],
        ),
      ),
    );
  }

  Widget _dealCard(Map<String, dynamic> d) {
    final title = '${d['title'] ?? ''}';
    final sub = '${d['subtitle'] ?? ''}';
    final priceRaw = d['price'];
    final priceNum = priceRaw is num
        ? priceRaw.toDouble()
        : double.tryParse('${priceRaw ?? ''}');
    final msg =
        'مرحبًا ${AppConfig.appNameAr} 👋\nمهتم بهذا العرض:\n\n🔥 $title\n$sub${priceNum != null ? '\n💵 ${Money.fmt(priceNum)}' : ''}\n\nالرجاء التفاصيل. شكرًا.';
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppConfig.navy,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 18)),
          if (sub.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(sub,
                style: const TextStyle(color: Colors.white70, fontSize: 14)),
          ],
          const SizedBox(height: 14),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              if (priceNum != null)
                Text(Money.fmt(priceNum),
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 20))
              else
                const SizedBox.shrink(),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: AppConfig.whatsapp,
                  foregroundColor: Colors.white,
                  elevation: 0,
                  minimumSize: const Size(0, 44),
                ),
                icon: const Icon(Icons.chat, size: 18),
                label: Text(tr('book_whatsapp'),
                    style: TextStyle(fontWeight: FontWeight.bold)),
                onPressed: () => WhatsAppService.custom(msg),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _packageTile(BuildContext context, String emoji, String title,
      String sub, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppConfig.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppConfig.line),
        ),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppConfig.tintCyan,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(emoji, style: const TextStyle(fontSize: 24)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: AppConfig.ink)),
                  const SizedBox(height: 3),
                  Text(sub,
                      style: const TextStyle(
                          fontSize: 12.5, color: AppConfig.inkMuted)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left, color: AppConfig.inkMuted),
          ],
        ),
      ),
    );
  }
}
