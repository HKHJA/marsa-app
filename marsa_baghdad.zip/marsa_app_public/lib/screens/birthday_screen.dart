import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../services/supabase_service.dart';

/// A one-time-feel welcome / birthday greeting. Its text and on/off state are
/// controlled from the admin dashboard, so it can be a birthday message today
/// and a seasonal welcome later.
class BirthdayScreen extends StatelessWidget {
  const BirthdayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        // Flat solid brand backdrop for the welcome screen.
        decoration: const BoxDecoration(color: AppConfig.brandDark),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(),
                Image.asset('assets/logo_white.png',
                    height: 120, fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => const SizedBox()),
                const SizedBox(height: 30),
                Text(
                  SupabaseCatalog.birthdayTitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 16),
                Text(
                  SupabaseCatalog.birthdayMessage,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 17, height: 1.9),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: AppConfig.brandPrimary,
                      minimumSize: const Size.fromHeight(54),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('ابدأ رحلتك ✨',
                        style: TextStyle(
                            fontSize: 17, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
