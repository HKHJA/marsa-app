import '../models/service.dart';

/// The full list of services shown on the home screen.
/// Add, remove, or reorder freely — the UI adapts automatically.
class ServicesCatalog {
  static const List<String> visaCountries = [
    'تركيا', 'الإمارات', 'دول شنغن (أوروبا)', 'مصر', 'جورجيا', 'أذربيجان',
    'ماليزيا', 'تايلاند', 'بريطانيا', 'أمريكا', 'كندا', 'أرمينيا',
  ];
  static const List<String> tourDestinations = [
    'تركيا', 'دبي', 'جورجيا', 'أذربيجان', 'مصر', 'ماليزيا', 'تايلاند',
    'المالديف', 'أرمينيا',
  ];

  static const List<ServiceItem> items = [
    ServiceItem(
      id: 'flights', emoji: '✈️', titleAr: 'حجز طيران', subAr: 'أفضل الأسعار',
      type: 'flights', badge: 'الأكثر طلباً',
    ),
    ServiceItem(
      id: 'hotels', emoji: '🏨', titleAr: 'حجز فنادق', subAr: 'حول العالم',
      type: 'hotels',
    ),
    ServiceItem(
      id: 'flightstatus', emoji: '🛫', titleAr: 'حالة الرحلة',
      subAr: 'تتبّع رحلتك مباشرة', type: 'flightstatus', badge: 'جديد',
    ),
    ServiceItem(
      id: 'visa', emoji: '🛂', titleAr: 'تأشيرات (فيزا)', subAr: 'لمختلف الدول',
      type: 'request', fieldLabel: 'الدولة المطلوبة', fieldOptions: visaCountries,
      hint: 'أرسل لنا الدولة وسنبلغك بالأوراق المطلوبة والرسوم ومدة الإنجاز.',
    ),
    ServiceItem(
      id: 'idp', emoji: '🪪', titleAr: 'إجازة سوق دولية', subAr: 'إصدار وتجديد',
      type: 'request',
      hint: 'إجازة السوق الدولية تُستخرج للقيادة خارج العراق. أرسل طلبك وسنزوّدك بالتفاصيل.',
    ),
    ServiceItem(
      id: 'ins', emoji: '🛡️', titleAr: 'تأمين سفر وصحي', subAr: 'لكل الوجهات',
      type: 'request',
      hint: 'تأمين يغطي الحالات الطارئة أثناء السفر ومطلوب لبعض الفيزا (مثل شنغن).',
    ),
    ServiceItem(
      id: 'umrah', emoji: '🕋', titleAr: 'عمرة وحج', subAr: 'باقات كاملة',
      type: 'request',
      hint: 'باقات عمرة وحج تشمل التذاكر والفنادق والتنقلات. حدد التاريخ وعدد الأشخاص.',
    ),
    ServiceItem(
      id: 'tours', emoji: '🌍', titleAr: 'باقات سياحية', subAr: 'رحلات منظمة',
      type: 'request', fieldLabel: 'الوجهة', fieldOptions: tourDestinations,
    ),
    ServiceItem(
      id: 'transfer', emoji: '🚐', titleAr: 'استقبال بالمطار', subAr: 'توصيل ونقل',
      type: 'request',
    ),
    ServiceItem(
      id: 'car', emoji: '🚙', titleAr: 'تأجير سيارات', subAr: 'داخل وخارج العراق',
      type: 'request',
    ),
    ServiceItem(
      id: 'esim', emoji: '📶', titleAr: 'شريحة إنترنت eSIM', subAr: 'نت أثناء السفر',
      type: 'request',
    ),
    ServiceItem(
      id: 'docs', emoji: '📄', titleAr: 'ترجمة وتصديق', subAr: 'وثائق ومستندات',
      type: 'request',
    ),
    ServiceItem(
      id: 'contact', emoji: '💬', titleAr: 'استفسار عام', subAr: 'تواصل معنا',
      type: 'request',
    ),
  ];
}
