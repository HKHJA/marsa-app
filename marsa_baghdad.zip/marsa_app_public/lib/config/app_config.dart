/// ============================================================================
///  MARSA BAGHDAD - APP CONFIGURATION
///  مرسى بغداد للسفر والسياحة
///
///  This is the ONLY file you normally need to edit.
///  Everything the business owner controls lives here.
/// ============================================================================
library;

import 'package:flutter/material.dart';

class AppConfig {
  // ---------------------------------------------------------------------------
  // 1) BRANDING
  // ---------------------------------------------------------------------------
  static const String appNameEn = 'Marsa Baghdad';
  static const String appNameAr = 'مرسى بغداد';
  static const String taglineEn = 'Travel & Tourism';
  static const String taglineAr = 'للسفر والسياحة';

  // Professional palette: navy structure (headers/buttons) + cyan accent.
  static const Color navy = Color(0xFF0C4E66); // headers / app bar / primary btn
  static const Color navy2 = Color(0xFF0A5E7A); // deeper navy
  static const Color brandPrimary = Color(0xFF0E9CC4); // MB cyan accent
  static const Color brandAccent = Color(0xFF0A6E8C); // deep teal accent
  static const Color brandDark = Color(0xFF0A5E7A); // solid header color

  // Neutral design tokens — flat surfaces, hairline borders, calm text.
  static const Color bg = Color(0xFFF1F4F6); // app background
  static const Color surface = Color(0xFFFFFFFF); // cards / sheets
  static const Color line = Color(0xFFE6ECEF); // 1px hairline borders
  static const Color ink = Color(0xFF15242E); // primary text
  static const Color inkMuted = Color(0xFF6A7883); // secondary text
  static const Color tintCyan = Color(0xFFE8F6FA); // subtle brand tint fills
  static const Color whatsapp = Color(0xFF25D366); // WhatsApp green

  // Colorful category-tile colors (home grid).
  static const Color tBlue = Color(0xFF1B5E9B);
  static const Color tCrimson = Color(0xFFC0304A);
  static const Color tGreen = Color(0xFF1FA97E);
  static const Color tCyan = Color(0xFF17A2C4);
  static const Color tPurple = Color(0xFF7A4F9E);
  static const Color tOrange = Color(0xFFE8912A);

  // ---------------------------------------------------------------------------
  // 2) WHATSAPP  ← PASTE HER NUMBER HERE (international format, no + or spaces)
  //    Example for Iraq: 9647801234567
  // ---------------------------------------------------------------------------
  static const String whatsappNumber = '9647733337378'; // Marsa Baghdad

  // Social pages (leave empty to hide the button). Paste full URLs.
  static const String facebookUrl = 'https://www.facebook.com/MBaghdad.Agency/';
  static const String instagramUrl = 'https://www.instagram.com/mbaghdad.agency/';

  // ---------------------------------------------------------------------------
  // 3) PROFIT / MARKUP
  //    The final price shown to the customer = supplier price + markup.
  //    You can use a percentage, a fixed amount, or both (they add up).
  // ---------------------------------------------------------------------------
  static const double flightMarkupPercent = 8.0; // +8% on flights
  static const double flightMarkupFixed = 15.0; // +15 USD flat per flight
  static const double hotelMarkupPercent = 12.0; // +12% on hotels
  static const double hotelMarkupFixed = 0.0;

  static const String currency = 'USD';
  static const String currencySymbol = '\$';

  // ---------------------------------------------------------------------------
  // 4) DATA SOURCE
  //    true  = realistic demo data (runs instantly, great for the gift/demo).
  //    false = live flight prices from Duffel (paste your token below first).
  // ---------------------------------------------------------------------------
  static const bool useMockData = true;

  // Duffel API — create a free account at duffel.com, then Settings → Access
  // tokens. Use a TEST token (starts with "duffel_test_") while trying it out,
  // switch to a live token when ready. Only search/pricing is used — booking
  // still happens over WhatsApp.
  static const String duffelToken = 'YOUR_DUFFEL_TEST_TOKEN';
  static const String duffelBaseUrl = 'https://api.duffel.com';
  static const String duffelVersion = 'v2';

  // ---------------------------------------------------------------------------
  // 4d) TRAVELPAYOUTS — international flight & hotel prices (cached/indicative,
  //     free). Local Iraqi carriers stay on dashboard prices; this fills in
  //     international routes and hotels. Token: app.travelpayouts.com → Profile
  //     → API token. The marker is your affiliate id (optional).
  // ---------------------------------------------------------------------------
  static const String travelpayoutsToken = 'YOUR_TP_TOKEN';
  static const String travelpayoutsMarker = '754331';
  static bool get travelpayoutsEnabled =>
      travelpayoutsToken.isNotEmpty && !travelpayoutsToken.startsWith('YOUR_');

  // ---------------------------------------------------------------------------
  // 4e) AIRLABS — real-time flight status / tracking (free tier ~1000/month,
  //     HTTPS). Sign up at airlabs.co → Dashboard → API Key, paste it below.
  //     Used only for the "Flight Status" screen; if empty, that screen shows
  //     a friendly "coming soon" message and nothing else is affected.
  // ---------------------------------------------------------------------------
  static const String airlabsApiKey = 'YOUR_AIRLABS_KEY';
  static bool get airlabsEnabled =>
      airlabsApiKey.isNotEmpty && !airlabsApiKey.startsWith('YOUR_');

  // ---------------------------------------------------------------------------
  // 4f) LITEAPI (Nuitée) — international hotel prices (replaces the closed
  //     Hotellook feed). Free self-serve signup at liteapi.travel. Use the
  //     PRODUCTION key (prod_...) for real prices; sandbox (sand_...) returns
  //     test data only. If empty, hotels fall back to the dashboard list.
  //     Booking still happens over WhatsApp; markup is applied as usual.
  // ---------------------------------------------------------------------------
  static const String liteApiKey = 'YOUR_LITEAPI_KEY';
  static bool get liteApiEnabled =>
      liteApiKey.isNotEmpty && !liteApiKey.startsWith('YOUR_');

  // ---------------------------------------------------------------------------
  // 4g) ONESIGNAL — push notifications. App ID from dashboard.onesignal.com
  //     (Marsa Baghdad App). The app initializes this on launch, asks the user
  //     for notification permission, and registers as a subscriber so the
  //     dashboard "send" button reaches every phone.
  // ---------------------------------------------------------------------------
  static const String oneSignalAppId = '1975bdb1-ddb0-4c8d-b18f-80e1124b8e70';
  static bool get oneSignalEnabled =>
      oneSignalAppId.isNotEmpty && !oneSignalAppId.startsWith('YOUR_');

  // ---------------------------------------------------------------------------
  // 4b) SUPABASE — shared price/catalog backend the admin dashboard writes to.
  //     The app READS local flights, hotels, services, and settings from here,
  //     so the owner's dashboard edits appear in the app automatically.
  //     These are public keys (safe to ship); writes are protected by RLS.
  // ---------------------------------------------------------------------------
  static const String supabaseUrl = 'https://knimfthyttlyttzymdke.supabase.co';
  static const String supabaseKey = 'sb_publishable_nixngfur47d9UyHqEG7DCw_e99qezPM';

  // ---------------------------------------------------------------------------
  // 5) POPULAR ROUTES / CITIES (used to prefill the pickers)
  // ---------------------------------------------------------------------------
  static const List<Map<String, String>> airports = [
    {'code': 'BGW', 'city': 'Baghdad', 'ar': 'بغداد'},
    {'code': 'BSR', 'city': 'Basra', 'ar': 'البصرة'},
    {'code': 'EBL', 'city': 'Erbil', 'ar': 'أربيل'},
    {'code': 'NJF', 'city': 'Najaf', 'ar': 'النجف'},
    {'code': 'DXB', 'city': 'Dubai', 'ar': 'دبي'},
    {'code': 'IST', 'city': 'Istanbul', 'ar': 'اسطنبول'},
    {'code': 'CAI', 'city': 'Cairo', 'ar': 'القاهرة'},
    {'code': 'BEY', 'city': 'Beirut', 'ar': 'بيروت'},
    {'code': 'AMM', 'city': 'Amman', 'ar': 'عمّان'},
    {'code': 'DOH', 'city': 'Doha', 'ar': 'الدوحة'},
    {'code': 'JED', 'city': 'Jeddah', 'ar': 'جدة'},
    {'code': 'LHR', 'city': 'London', 'ar': 'لندن'},
  ];

  static const List<Map<String, String>> hotelCities = [
    {'code': 'DXB', 'city': 'Dubai', 'ar': 'دبي'},
    {'code': 'IST', 'city': 'Istanbul', 'ar': 'اسطنبول'},
    {'code': 'CAI', 'city': 'Cairo', 'ar': 'القاهرة'},
    {'code': 'BEY', 'city': 'Beirut', 'ar': 'بيروت'},
    {'code': 'MKC', 'city': 'Makkah', 'ar': 'مكة'},
    {'code': 'AMM', 'city': 'Amman', 'ar': 'عمّان'},
  ];
}
