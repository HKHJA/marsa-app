/// Typical economy-class baggage allowances by airline. These vary by fare
/// and route, so the screen shows a "confirm with the airline" note.
class BaggageAirline {
  final String name;
  final String cabin; // e.g. "7 kg"
  final String checked; // e.g. "30 kg"
  const BaggageAirline(this.name, this.cabin, this.checked);
}

class BaggageData {
  static const List<BaggageAirline> all = [
    BaggageAirline('Iraqi Airways', '7 kg', '30 kg'),
    BaggageAirline('Fly Baghdad', '7 kg', '30 kg'),
    BaggageAirline('flydubai', '7 kg', '20–30 kg'),
    BaggageAirline('Turkish Airlines', '8 kg', '30 kg'),
    BaggageAirline('Qatar Airways', '7 kg', '30 kg'),
    BaggageAirline('Emirates', '7 kg', '30–35 kg'),
    BaggageAirline('Royal Jordanian', '7 kg', '23–30 kg'),
    BaggageAirline('Middle East Airlines', '8 kg', '23–30 kg'),
    BaggageAirline('Pegasus', '8 kg', '15–20 kg'),
    BaggageAirline('Saudia', '7 kg', '25–30 kg'),
    BaggageAirline('Gulf Air', '7 kg', '30 kg'),
    BaggageAirline('Kuwait Airways', '7 kg', '30 kg'),
  ];
}
