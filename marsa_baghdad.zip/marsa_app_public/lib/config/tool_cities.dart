/// Curated destination cities for the travel tools (weather / prayer times).
/// Each carries coordinates and the country name Aladhan expects.
class ToolCity {
  final String ar;
  final String en;
  final String country; // English country name for Aladhan
  final double lat;
  final double lon;
  const ToolCity(this.ar, this.en, this.country, this.lat, this.lon);
}

class ToolCities {
  static const List<ToolCity> all = [
    ToolCity('بغداد', 'Baghdad', 'Iraq', 33.3152, 44.3661),
    ToolCity('البصرة', 'Basra', 'Iraq', 30.5085, 47.7804),
    ToolCity('أربيل', 'Erbil', 'Iraq', 36.1901, 44.0091),
    ToolCity('النجف', 'Najaf', 'Iraq', 32.0000, 44.3350),
    ToolCity('كربلاء', 'Karbala', 'Iraq', 32.6160, 44.0249),
    ToolCity('دبي', 'Dubai', 'United Arab Emirates', 25.2048, 55.2708),
    ToolCity('اسطنبول', 'Istanbul', 'Turkey', 41.0082, 28.9784),
    ToolCity('القاهرة', 'Cairo', 'Egypt', 30.0444, 31.2357),
    ToolCity('بيروت', 'Beirut', 'Lebanon', 33.8938, 35.5018),
    ToolCity('عمّان', 'Amman', 'Jordan', 31.9539, 35.9106),
    ToolCity('الدوحة', 'Doha', 'Qatar', 25.2854, 51.5310),
    ToolCity('جدة', 'Jeddah', 'Saudi Arabia', 21.4858, 39.1925),
    ToolCity('مكة', 'Makkah', 'Saudi Arabia', 21.3891, 39.8579),
    ToolCity('المدينة', 'Madinah', 'Saudi Arabia', 24.5247, 39.5692),
    ToolCity('لندن', 'London', 'United Kingdom', 51.5074, -0.1278),
  ];
}
