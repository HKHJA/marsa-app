/// Per-country visa document requirements. Keys are the Arabic country names
/// used in [ServicesCatalog.visaCountries]; values are l10n requirement keys
/// rendered on the visa screen. A sensible default covers unlisted countries.
class VisaRequirements {
  static const List<String> _default = [
    'req_passport',
    'req_photo',
    'req_bank',
    'req_hotel',
    'req_flight',
  ];

  static const Map<String, List<String>> _byCountry = {
    'دول شنغن (أوروبا)': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_hotel',
      'req_flight',
      'req_insurance',
      'req_employment',
    ],
    'بريطانيا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_hotel',
      'req_flight',
      'req_employment',
    ],
    'أمريكا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_employment',
      'req_invitation',
    ],
    'كندا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_employment',
      'req_invitation',
    ],
    'تركيا': ['req_passport', 'req_photo', 'req_hotel', 'req_flight'],
    'الإمارات': ['req_passport', 'req_photo', 'req_flight'],
    'مصر': ['req_passport', 'req_photo'],
    'جورجيا': ['req_passport', 'req_photo', 'req_hotel'],
    'أذربيجان': ['req_passport', 'req_photo'],
    'ماليزيا': ['req_passport', 'req_photo', 'req_hotel', 'req_flight'],
    'تايلاند': ['req_passport', 'req_photo', 'req_bank', 'req_flight'],
    'أرمينيا': ['req_passport', 'req_photo'],
  };

  static List<String> forCountry(String country) =>
      _byCountry[country] ?? _default;
}
