/// Per-country visa info for Iraqi passport holders: the visa status (does an
/// Iraqi need a visa?) and the documents typically required. Status data is
/// indicative (based on public sources) and confirmed by the agency on request.
class VisaRequirements {
  // Visa status for a normal Iraqi passport. Values:
  //   'free' (visa-free) | 'onarrival' | 'evisa' | 'required'
  static const Map<String, String> visaStatus = {
    'تركيا': 'required',
    'الإمارات': 'required',
    'دول شنغن (أوروبا)': 'required',
    'مصر': 'evisa',
    'جورجيا': 'required',
    'أذربيجان': 'required',
    'ماليزيا': 'free',
    'تايلاند': 'evisa',
    'بريطانيا': 'required',
    'أمريكا': 'required',
    'كندا': 'required',
    'أرمينيا': 'evisa',
    'دبي': 'required',
    'المالديف': 'onarrival',
  };

  static String statusOf(String country) => visaStatus[country] ?? 'required';

  static const List<String> _default = [
    'req_passport',
    'req_photo',
    'req_bank',
    'req_hotel',
    'req_flight',
  ];

  static const Map<String, List<String>> _byCountry = {
    'دول شنغن (أوروبا)': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_hotel',
      'req_flight',
      'req_insurance',
      'req_employment',
    ],
    'بريطانيا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_hotel',
      'req_flight',
      'req_employment',
    ],
    'أمريكا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_employment',
      'req_invitation',
    ],
    'كندا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_employment',
      'req_invitation',
    ],
    // Turkey: Iraqis need a pre-arranged visa; bank statement + insurance count.
    'تركيا': [
      'req_passport',
      'req_photo',
      'req_bank',
      'req_hotel',
      'req_flight',
      'req_insurance',
    ],
    'الإمارات': ['req_passport', 'req_photo', 'req_flight'],
    'مصر': ['req_passport', 'req_photo'],
    'جورجيا': ['req_passport', 'req_photo', 'req_bank', 'req_hotel'],
    'أذربيجان': ['req_passport', 'req_photo'],
    'ماليزيا': ['req_passport', 'req_photo'],
    'تايلاند': ['req_passport', 'req_photo', 'req_bank', 'req_flight'],
    'أرمينيا': ['req_passport', 'req_photo'],
  };

  static List<String> forCountry(String country) =>
      _byCountry[country] ?? _default;
}
