/// Emergency phone numbers by country (police / ambulance / fire / general).
/// Stable public-safety facts; the screen shows a "verify locally" note.
class EmergencyCountry {
  final String ar;
  final String en;
  final String? general;
  final String? police;
  final String? ambulance;
  final String? fire;
  const EmergencyCountry(
      this.ar, this.en, this.general, this.police, this.ambulance, this.fire);
}

class EmergencyData {
  static const List<EmergencyCountry> all = [
    EmergencyCountry('العراق', 'Iraq', null, '104', '122', '115'),
    EmergencyCountry('الإمارات', 'UAE', '112', '999', '998', '997'),
    EmergencyCountry('تركيا', 'Turkey', '112', '155', '112', '110'),
    EmergencyCountry('مصر', 'Egypt', null, '122', '123', '180'),
    EmergencyCountry('لبنان', 'Lebanon', '112', '112', '140', '175'),
    EmergencyCountry('الأردن', 'Jordan', '911', '911', '911', '911'),
    EmergencyCountry('قطر', 'Qatar', '999', '999', '999', '999'),
    EmergencyCountry(
        'السعودية', 'Saudi Arabia', '911', '999', '997', '998'),
    EmergencyCountry('بريطانيا', 'United Kingdom', '999', '999', '999', '999'),
  ];
}
