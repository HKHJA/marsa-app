#!/usr/bin/env python3
"""Patch the generated AndroidManifest.xml for Marsa Baghdad:
- add INTERNET permission (needed for Amadeus + WhatsApp links)
- add <queries> so Android 11+ can open WhatsApp / browser
- set the Arabic app name
Runs in CI after `flutter create`.
"""
import re, pathlib

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
xml = p.read_text(encoding="utf-8")

# 1) INTERNET + POST_NOTIFICATIONS permissions (after the opening <manifest>)
if "android.permission.INTERNET" not in xml:
    xml = re.sub(
        r"(<manifest[^>]*>)",
        r'\1\n    <uses-permission android:name="android.permission.INTERNET"/>\n'
        r'    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n'
        r'    <queries>\n'
        r'        <intent>\n'
        r'            <action android:name="android.intent.action.VIEW" />\n'
        r'            <data android:scheme="https" />\n'
        r'        </intent>\n'
        r'    </queries>',
        xml, count=1,
    )

# 2) App display name (Arabic)
xml = re.sub(r'android:label="[^"]*"', 'android:label="مرسى بغداد"', xml, count=1)

p.write_text(xml, encoding="utf-8")
print("AndroidManifest.xml patched:")
print(xml)
